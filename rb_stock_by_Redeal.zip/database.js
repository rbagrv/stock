import { config } from './config.js';

class DatabaseService {
  constructor() {
    this.dbName = 'anbarDB';
    this.dbVersion = 6;
    this.db = null;
    this.isOnline = navigator.onLine;
    this.API_URL = config.API_URL;
    this.isAuthenticated = true;

    this.stores = [
      'products', 'categories', 'customers', 'suppliers', 'sales',
      'purchases', 'operations', 'productions', 'accounts',
      'transactions', 'users', 'sync', 'settings'
    ];

    window.addEventListener('online', this.handleOnlineStatusChange.bind(this));
    window.addEventListener('offline', this.handleOnlineStatusChange.bind(this));
  }

  async initDB() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        console.error('Your browser doesn\'t support IndexedDB');
        return reject('IndexedDB not supported');
      }
      if (this.db) {
        return resolve(this.db);
      }

      console.log(`Opening database ${this.dbName} version ${this.dbVersion}`);
      const request = indexedDB.open(this.dbName, this.dbVersion);

      request.onerror = (event) => {
        console.error('Database error:', event.target.error);
        reject(event.target.error);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        const transaction = event.target.transaction;

        console.log(`Running onupgradeneeded for version ${this.dbVersion}...`);

        const storeConfigs = {
          products: { keyPath: 'id', autoIncrement: false },
          categories: { keyPath: 'id', autoIncrement: false },
          customers: { keyPath: 'id', autoIncrement: false },
          suppliers: { keyPath: 'id', autoIncrement: false },
          sales: { keyPath: 'id', autoIncrement: false },
          purchases: { keyPath: 'id', autoIncrement: false },
          operations: { keyPath: 'id', autoIncrement: false },
          productions: { keyPath: 'id', autoIncrement: false },
          accounts: { keyPath: 'code' },
          transactions: { keyPath: 'id', autoIncrement: false },
          users: { keyPath: 'id', autoIncrement: false },
          sync: { keyPath: 'id', autoIncrement: false },
          settings: { keyPath: 'category' }
        };

        const indexes = {
          products: [
            { name: 'code', keyPath: 'code', options: { unique: true } },
            { name: 'name', keyPath: 'name' },
            { name: 'barcode', keyPath: 'barcode' }
          ],
          categories: [ { name: 'name', keyPath: 'name', options: { unique: true } } ],
          customers: [ { name: 'name', keyPath: 'name' }, { name: 'phone', keyPath: 'phone' } ],
          suppliers: [ { name: 'company', keyPath: 'company' }, { name: 'phone', keyPath: 'phone' } ],
          sales: [ { name: 'date', keyPath: 'date' }, { name: 'code', keyPath: 'code', options: { unique: true } }, { name: 'customerId', keyPath: 'customerId' } ],
          purchases: [ { name: 'date', keyPath: 'date' }, { name: 'code', keyPath: 'code', options: { unique: true } }, { name: 'supplierId', keyPath: 'supplierId'} ],
          operations: [ { name: 'date', keyPath: 'date' }, { name: 'type', keyPath: 'type' }, { name: 'referenceId', keyPath: 'referenceId'}, { name: 'productId', keyPath: 'productId'} ],
          productions: [ { name: 'startDate', keyPath: 'startDate' }, { name: 'status', keyPath: 'status'}, { name: 'name', keyPath: 'name' } ],
          accounts: [ { name: 'name', keyPath: 'name' }, { name: 'type', keyPath: 'type' }, { name: 'parentId', keyPath: 'parentId'} ],
          transactions: [ { name: 'date', keyPath: 'date' }, { name: 'type', keyPath: 'type' }, { name: 'accountId', keyPath: 'accountId' }, { name: 'customerId', keyPath: 'customerId' }, { name: 'fromAccountId', keyPath: 'fromAccountId' }, { name: 'toAccountId', keyPath: 'toAccountId' } ],
          users: [ { name: 'username', keyPath: 'username', options: { unique: true } } ],
          sync: [ { name: 'timestamp', keyPath: 'timestamp' } ],
          settings: []
        };

        this.stores.forEach(storeName => {
          let store;
          if (!db.objectStoreNames.contains(storeName)) {
            console.log(`Creating store: ${storeName}`);
            store = db.createObjectStore(storeName, storeConfigs[storeName]);
          } else {
            console.log(`Store ${storeName} exists, getting transaction.`);
            store = transaction.objectStore(storeName);
            const newIndexNames = indexes[storeName]?.map(idx => idx.name) || [];
            Array.from(store.indexNames).forEach(indexName => {
              if (!newIndexNames.includes(indexName)) {
                console.log(`Deleting old/unused index ${indexName} from ${storeName}`);
                try { store.deleteIndex(indexName); } catch (e) { console.warn(`Could not delete index ${indexName} from ${storeName}: ${e.message}`); }
              }
            });
          }

          if (indexes[storeName]) {
            indexes[storeName].forEach(index => {
              if (!store.indexNames.contains(index.name)) {
                console.log(`Creating index '${index.name}' for store '${storeName}'`);
                try { store.createIndex(index.name, index.keyPath, index.options || {}); } catch (e) { console.error(`Error creating index ${index.name} for ${storeName}: ${e.message}`); }
              } else {
                console.log(`Index '${index.name}' already exists on store '${storeName}'`);
              }
            });
          }
        });

        console.log("onupgradeneeded finished.");
      };

      request.onsuccess = (event) => {
        this.db = event.target.result;
        console.log(`Database ${this.dbName} v${this.dbVersion} initialized successfully (Auth Bypassed).`);
        this.db.onversionchange = () => {
          this.db.close();
          console.warn("Database version change detected, closing connection. Please reload.");
          alert("Database has been updated. Please reload the page.");
        };
        this.db.onclose = () => {
          console.log("Database connection closed.");
          this.db = null;
        };
        if (this.isOnline) {
          this.syncWithServer();
        }
        resolve(this.db);
      };

      request.onblocked = () => {
        console.warn("Database open request blocked. Please close other tabs/windows using this app.");
        alert("An older version of the app is open in another tab. Please close it and reload this page.");
      };
    });
  }

  async ensureDB() {
    if (!this.db) {
       console.log("DB not initialized, attempting to init...");
       try {
           await this.initDB();
       } catch (error) {
           console.error("Failed to initialize DB in ensureDB:", error);
           throw new Error("Database connection could not be established.");
       }
    }
     if (!this.db) {
         throw new Error("Database connection could not be established after init attempt.");
     }
  }

  handleOnlineStatusChange() {
    const wasOnline = this.isOnline;
    this.isOnline = navigator.onLine;

    if (!wasOnline && this.isOnline) {
      console.log('Device is back online. Starting sync...');
      this.syncWithServer();
    } else if (wasOnline && !this.isOnline) {
      console.log('Device is offline. Changes will be stored locally.');
    }
  }

  async adjustStockAndLog(transaction, productId, quantityChange, operationType, referenceId, referenceType, userId = null) {
    if (isNaN(quantityChange) || quantityChange === 0) {
      console.warn(`Skipping stock adjustment for product ${productId}: Invalid quantity change ${quantityChange}`);
      return Promise.resolve(null);
    }

    const productsStore = transaction.objectStore('products');
    const operationsStore = transaction.objectStore('operations');

    return new Promise((resolve, reject) => {
      const getRequest = productsStore.get(productId);

      getRequest.onsuccess = () => {
        const product = getRequest.result;
        if (!product) {
          console.error(`Product with ID ${productId} not found for stock adjustment.`);
          resolve(null);
          return;
        }

        const oldQuantity = parseFloat(product.quantity) || 0;
        const newQuantity = oldQuantity + parseFloat(quantityChange);

        console.log(`Adjusting stock for ${product.name} (${productId}): ${oldQuantity} -> ${newQuantity} (Change: ${quantityChange}) due to ${operationType} ${referenceType} #${referenceId}`);

        const updatedProduct = { ...product, quantity: newQuantity };
        const putRequest = productsStore.put(updatedProduct);

        putRequest.onerror = (e) => {
          console.error(`Error updating stock for product ${productId}:`, e.target.error);
          resolve(null);
        };

        putRequest.onsuccess = () => {
          const operationId = `op_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
          const logEntry = {
            id: operationId,
            type: operationType,
            date: new Date().toISOString(),
            productId: productId,
            productName: product.name,
            quantity: parseFloat(quantityChange),
            unit: product.unit || '',
            description: `${operationType} - Məhsul: ${product.name}, Miqdar: ${quantityChange}, Yeni Stok: ${newQuantity}`,
            referenceId: referenceId,
            referenceType: referenceType,
            userId: userId || null,
            userName: null
          };

          const logRequest = operationsStore.add(logEntry);
          logRequest.onerror = (e) => {
            console.error("Error adding stock adjustment operation log:", e.target.error);
            resolve(updatedProduct);
          };
          logRequest.onsuccess = () => {
            resolve(updatedProduct);
          };
        };
      };
      getRequest.onerror = (e) => {
        console.error(`Error fetching product ${productId} for stock adjustment:`, e.target.error);
        resolve(null);
      };
    });
  }

  async fetchFromServer(storeName) {
    await this.ensureDB();
    if (!this.isOnline) {
      console.warn(`Cannot fetch ${storeName} from server: offline.`);
      return null;
    }

    try {
      const url = `${this.API_URL}/${storeName}?t=${Date.now()}`;
      const response = await fetch(url);

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Server error fetching ${storeName}: ${response.status} ${response.statusText}`, errorText);
        throw new Error(`Server error: ${response.status} ${response.statusText}`);
      }
      const data = await response.json();
      console.log(`Fetched ${data?.length ?? 0} items for ${storeName} from server.`);
      return data;
    } catch (error) {
      console.error(`Error fetching ${storeName} from server:`, error);
      return null;
    }
  }

  async _sendToServerCore(method, storeName, data, syncOpId = null) {
    if (!this.isOnline) throw new Error(`_sendToServerCore (${syncOpId ? `sync op ${syncOpId}` : 'direct call'}) called while offline`);

    try {
      const keyName = storeName === 'accounts' ? 'code' : 'id';
      const dataKey = data[keyName];
      const originalOfflineId = (method === 'POST' && dataKey && typeof dataKey === 'string' && dataKey.startsWith('offline_')) ? dataKey : null;
      const endpointKey = (method === 'PUT' || method === 'DELETE') ? dataKey : null;

      if ((method === 'PUT' || method === 'DELETE')) {
        if (typeof endpointKey === 'string' && endpointKey.startsWith('offline_')) {
          console.error(`Attempting to sync ${method} for offline key ${endpointKey} (op: ${syncOpId}). This should not happen.`);
          throw new Error(`Cannot sync ${method} for unresolved offline key ${endpointKey}`);
        } else if (endpointKey === undefined || endpointKey === null) {
          throw new Error(`Invalid key (${endpointKey}) for ${method} sync operation ${syncOpId || '(direct call)'}`);
        }
      }

      const url = method === 'POST' ? `${this.API_URL}/${storeName}` : `${this.API_URL}/${storeName}/${endpointKey}`;

      const options = {
        method: method,
        headers: {
          'Content-Type': 'application/json',
        },
      };

      let payload = { ...data };
      delete payload._pendingSync;

      if (method !== 'DELETE') {
        if (method === 'POST' && originalOfflineId) {
          delete payload.id;
        }
        options.body = JSON.stringify(payload);
      }

      const response = await fetch(url, options);

      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = `Server error (${syncOpId ? `sync op ${syncOpId}` : 'direct call'}): ${response.status}`;
        try {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const parsedError = JSON.parse(errorText);
            if (parsedError.message) errorMessage += ` - ${parsedError.message}`;
          } else { errorMessage += ` - Non-JSON response.`; }
        } catch (e) { /* ignore parsing error */ }
        errorMessage += ` (${method} ${url})`;
        throw new Error(errorMessage);
      }

      let responseData = {};
      if (response.status !== 204) {
        responseData = await response.json();
        if (storeName === 'accounts' && !responseData.code && data.code) {
          responseData.code = data.code;
        }
        else if (method === 'POST' && keyName === 'id' && !responseData.id) {
          console.warn(`Server POST response for ${storeName} missing 'id'. Using generated ID if possible. Response:`, responseData);
        }
      } else {
        responseData = { [keyName]: endpointKey };
      }

      const confirmedKey = responseData[keyName];

      if (confirmedKey === undefined || confirmedKey === null || (typeof confirmedKey === 'string' && confirmedKey.trim() === '')) {
        console.error(`Server response for ${syncOpId || 'direct call'} missing or has invalid key '${keyName}'. Response:`, responseData);
        throw new Error(`Server response missing or has invalid key '${keyName}'`);
      }

      if (method === 'POST') {
        if (originalOfflineId) {
          await this.deleteLocalRecord(storeName, originalOfflineId);
        }
        await this.updateLocalRecord(storeName, responseData);
      } else if (method === 'PUT') {
        await this.updateLocalRecord(storeName, responseData);
      } else if (method === 'DELETE') {
        await this.deleteLocalRecord(storeName, endpointKey);
      }

      if (syncOpId) {
        await this.removeSyncOperation(syncOpId);
        console.log(`Successfully synced and removed op: ${syncOpId}`);
      }

      return responseData;
    } catch (error) {
      console.error(`Error in _sendToServerCore (${syncOpId || 'direct call'}):`, error);
      throw error;
    }
  }

  async sendToServer(method, storeName, data) {
    await this.ensureDB();
    const keyName = storeName === 'accounts' ? 'code' : 'id';

    if (!this.isOnline) {
      console.warn(`Cannot send ${method} for ${storeName}: offline. Queuing.`);
      let localData = { ...data };

      if (method === 'POST' && !localData[keyName]) {
        if (storeName === 'accounts') {
          if (!localData.code || localData.code.trim() === '') {
            console.error("Cannot queue 'add account' offline without a code.");
            throw new Error("Account code is required to add an account, even offline.");
          }
        } else {
          localData.id = `offline_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
          console.log(`Generated offline key for ${storeName}: ${localData.id}`);
        }
      }

      localData._pendingSync = true;
      const updatedLocalData = await this.updateLocalRecord(storeName, localData);
      await this.addToSyncQueue(storeName, method === 'POST' ? 'add' : (method === 'PUT' ? 'update' : 'delete'), updatedLocalData);
      return updatedLocalData;
    }

    try {
      return await this._sendToServerCore(method, storeName, data);
    } catch (error) {
      console.error(`Direct ${method} failed for ${storeName}, attempting to queue:`, error);
      let localData = { ...data, _pendingSync: true };
      if (method === 'POST' && !localData[keyName]) {
        if (storeName === 'accounts') {
          if (!localData.code) { throw new Error("Account code is required."); }
        } else {
          localData.id = `offline_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
        }
      }
      const queuedData = await this.updateLocalRecord(storeName, localData);
      await this.addToSyncQueue(storeName, method === 'POST' ? 'add' : (method === 'PUT' ? 'update' : 'delete'), queuedData);
      return queuedData;
    }
  }

  async getAll(storeName) {
    await this.ensureDB();
    let serverData = null;
    try {
      serverData = await this.fetchFromServer(storeName);
    } catch (fetchError) {
      console.error(`Failed server fetch for ${storeName}:`, fetchError);
    }

    if (serverData !== null) {
      try {
        await this.updateLocalStore(storeName, serverData);
        return serverData;
      } catch (updateError) {
        console.error(`Failed to update local store ${storeName} after server fetch:`, updateError);
        console.warn(`Returning local data for ${storeName} due to update error.`);
        return this.getAllLocal(storeName);
      }
    } else {
      console.log(`Fetching ${storeName} from local DB as fallback.`);
      return this.getAllLocal(storeName);
    }
  }

  async add(storeName, data) {
    await this.ensureDB();
    const keyName = storeName === 'accounts' ? 'code' : 'id';

    if (storeName === 'accounts' && (!data.code || data.code.trim() === '')) throw new Error('Account code is required.');
    if (storeName === 'transactions' && !data.type) throw new Error('Transaction type is required.');

    const storesForTx = new Set([storeName, 'sync']);
    if (['sales', 'purchases', 'productions', 'products'].includes(storeName)) {
      storesForTx.add('products');
      storesForTx.add('operations');
    }
    const tx = this.db.transaction(Array.from(storesForTx), 'readwrite');

    try {
      let localData = { ...data };
      if (!localData[keyName] && storeName !== 'accounts') {
        localData.id = `offline_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
      }

      const addRequest = tx.objectStore(storeName).add(localData);
      await new Promise((res, rej) => { addRequest.onsuccess = res; addRequest.onerror = rej; });
      const addedKey = localData[keyName];

      if (['categories', 'accounts', 'users', 'customers', 'suppliers'].includes(storeName)) {
        await this._logOperation(tx, storeName, 'add', localData, null, null);
      }

      await this._performStockAdjustments(tx, storeName, localData, null, 'add');

      if (!this.isOnline) {
        localData._pendingSync = true;
        await this._addToSyncQueueInternal(tx, storeName, 'add', localData);
        await tx.done;
        console.log(`Offline ADD and stock adjustments successful for ${storeName} (Key: ${addedKey})`);
        return localData;
      } else {
        await tx.done;
        console.log(`Online ADD: Local add and stock adjustments committed for ${storeName} (Key: ${addedKey})`);

        try {
          const serverResponse = await this._sendToServerCore('POST', storeName, localData);
          return serverResponse;
        } catch (serverError) {
          console.error(`Online ADD: Server failed for ${storeName} (Local Key: ${addedKey}). Queuing...`, serverError);
          localData._pendingSync = true;
          await this.addToSyncQueue(storeName, 'add', localData);
          return localData;
        }
      }
    } catch (error) {
      console.error(`ADD transaction failed for ${storeName}:`, error);
      try { tx.abort(); } catch (e) { console.error("Abort failed:", e); }
      throw error;
    }
  }

  async update(storeName, key, data) {
    await this.ensureDB();
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const updateData = { ...data, [keyName]: key };

    const storesForTx = new Set([storeName, 'sync']);
    if (['sales', 'purchases', 'productions', 'products'].includes(storeName)) {
      storesForTx.add('products');
      storesForTx.add('operations');
    }
    const tx = this.db.transaction(Array.from(storesForTx), 'readwrite');

    try {
      const oldItem = await this._getLocalRecordInternal(tx, storeName, key);
      if (!oldItem) {
        console.warn(`UPDATE: Item ${key} not found locally in ${storeName}. Cannot perform update or adjustments.`);
        try { tx.abort(); } catch (e) { console.warn("Abort failed on non-existent update:", e); }
        throw new Error(`Element tapılmadı (Key: ${key})`);
      }

      const putRequest = tx.objectStore(storeName).put(updateData);

      await new Promise((res, rej) => { putRequest.onsuccess = res; putRequest.onerror = rej; });

      if (['categories', 'accounts', 'users', 'customers', 'suppliers'].includes(storeName)) {
        await this._logOperation(tx, storeName, 'update', updateData, oldItem, null);
      }

      await this._performStockAdjustments(tx, storeName, updateData, oldItem, 'update');

      if (!this.isOnline) {
        updateData._pendingSync = true;
        await this._addToSyncQueueInternal(tx, storeName, 'update', updateData);
        await tx.done;
        console.log(`Offline UPDATE and stock adjustments successful for ${storeName} (Key: ${key})`);
        return updateData;
      } else {
        await tx.done;
        console.log(`Online UPDATE: Local update and stock adjustments committed for ${storeName} (Key: ${key})`);

        try {
          const serverResponse = await this._sendToServerCore('PUT', storeName, updateData);
          return serverResponse;
        } catch (serverError) {
          console.error(`Online UPDATE: Server failed for ${storeName} (Key: ${key}). Queuing...`, serverError);
          updateData._pendingSync = true;
          await this.addToSyncQueue(storeName, 'update', updateData);
          return updateData;
        }
      }
    } catch (error) {
      console.error(`UPDATE transaction failed for ${storeName} (Key: ${key}):`, error);
      try { tx.abort(); } catch (e) { console.error("Abort failed:", e); }
      throw error;
    }
  }

  async delete(storeName, key) {
    await this.ensureDB();
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const dataWithKey = { [keyName]: key };

    const storesForTx = new Set([storeName, 'sync', 'operations']);
    if (['sales', 'purchases', 'productions', 'products'].includes(storeName)) {
      storesForTx.add('products');
    }
    const tx = this.db.transaction(Array.from(storesForTx), 'readwrite');

    try {
      const itemToDelete = await this._getLocalRecordInternal(tx, storeName, key);
      if (!itemToDelete) {
        console.warn(`DELETE: Item ${key} not found locally in ${storeName}. Aborting local operation.`);
        try { tx.abort(); } catch (e) { console.warn("Abort failed on non-existent delete:", e); }
        if (this.isOnline) {
          console.warn(`Attempting server DELETE for potentially non-local item ${storeName} (Key: ${key})`);
          try {
            await this._sendToServerCore('DELETE', storeName, dataWithKey);
            return;
          } catch (serverError) {
            console.error(`Server DELETE failed for non-local item ${storeName} (Key: ${key}):`, serverError);
            throw serverError;
          }
        } else {
          return;
        }
      }

      const deleteRequest = tx.objectStore(storeName).delete(key);
      await new Promise((res, rej) => { deleteRequest.onsuccess = res; deleteRequest.onerror = rej; });

      if (['categories', 'accounts', 'users', 'customers', 'suppliers'].includes(storeName)) {
        await this._logOperation(tx, storeName, 'delete', null, itemToDelete, null);
      }

      await this._performStockAdjustments(tx, storeName, null, itemToDelete, 'delete');

      if (!this.isOnline) {
        itemToDelete._pendingSync = true;
        await this._addToSyncQueueInternal(tx, storeName, 'delete', itemToDelete);
        await tx.done;
        console.log(`Offline DELETE and stock adjustments successful for ${storeName} (Key: ${key})`);
        return;
      } else {
        await tx.done;
        console.log(`Online DELETE: Local delete and stock adjustments committed for ${storeName} (Key: ${key})`);

        try {
          await this._sendToServerCore('DELETE', storeName, dataWithKey);
          return;
        } catch (serverError) {
          console.error(`Online DELETE: Server failed for ${storeName} (Key: ${key}). Queuing...`, serverError);
          itemToDelete._pendingSync = true;
          await this.addToSyncQueue(storeName, 'delete', itemToDelete);
          return;
        }
      }
    } catch (error) {
      console.error(`DELETE transaction failed for ${storeName} (Key: ${key}):`, error);
      try { tx.abort(); } catch (e) { console.error("Abort failed:", e); }
      throw error;
    }
  }

  async _performStockAdjustments(transaction, storeName, newData, oldData, operationKind) {
    if (!['sales', 'purchases', 'productions'].includes(storeName)) {
      return;
    }

    const adjustments = [];
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const referenceId = newData?.[keyName] ?? oldData?.[keyName];
    const referenceType = storeName;

    const calculateItemChanges = (newItems = [], oldItems = []) => {
      const changes = new Map();
      const oldMap = new Map(oldItems.map(item => [item.productId, parseFloat(item.quantity) || 0]));
      const newMap = new Map(newItems.map(item => [item.productId, parseFloat(item.quantity) || 0]));

      newMap.forEach((newQty, productId) => {
        const oldQty = oldMap.get(productId) || 0;
        if (newQty > oldQty) {
          changes.set(productId, (changes.get(productId) || 0) + (newQty - oldQty));
        }
      });

      oldMap.forEach((oldQty, productId) => {
        const newQty = newMap.get(productId) || 0;
        if (oldQty > newQty) {
          changes.set(productId, (changes.get(productId) || 0) - (oldQty - newQty));
        }
      });
      return changes;
    };

    if (storeName === 'sales') {
      let itemChanges = new Map();
      if (operationKind === 'add') {
        (newData.items || []).forEach(item => itemChanges.set(item.productId, -(parseFloat(item.quantity) || 0)));
      } else if (operationKind === 'delete') {
        (oldData.items || []).forEach(item => itemChanges.set(item.productId, parseFloat(item.quantity) || 0));
      } else if (operationKind === 'update') {
        itemChanges = calculateItemChanges(newData.items || [], oldData.items || []);
        itemChanges.forEach((change, productId) => {
          itemChanges.set(productId, -change);
        });
      }
      itemChanges.forEach((change, productId) => {
        if (change !== 0) adjustments.push({ productId, change, operationType: `stock_adjust_sale_${operationKind}` });
      });
    } else if (storeName === 'purchases') {
      let itemChanges = new Map();
      if (operationKind === 'add') {
        (newData.items || []).forEach(item => itemChanges.set(item.productId, parseFloat(item.quantity) || 0));
      } else if (operationKind === 'delete') {
        (oldData.items || []).forEach(item => itemChanges.set(item.productId, -(parseFloat(item.quantity) || 0)));
      } else if (operationKind === 'update') {
        itemChanges = calculateItemChanges(newData.items || [], oldData.items || []);
      }
      itemChanges.forEach((change, productId) => {
        if (change !== 0) adjustments.push({ productId, change, operationType: `stock_adjust_purch_${operationKind}` });
      });
    } else if (storeName === 'productions') {
      let inputChanges = new Map();
      let outputChanges = new Map();

      if (operationKind === 'add') {
        (newData.items || []).forEach(item => inputChanges.set(item.productId, -(parseFloat(item.quantity) || 0)));
        if (newData.status === 'completed') {
          (newData.output || []).forEach(item => outputChanges.set(item.productId, parseFloat(item.quantity) || 0));
        }
      } else if (operationKind === 'delete') {
        (oldData.items || []).forEach(item => inputChanges.set(item.productId, parseFloat(item.quantity) || 0));
        if (oldData.status === 'completed') {
          (oldData.output || []).forEach(item => outputChanges.set(item.productId, -(parseFloat(item.quantity) || 0)));
        }
      } else if (operationKind === 'update') {
        const inputDiff = calculateItemChanges(newData.items || [], oldData.items || []);
        inputDiff.forEach((change, productId) => inputChanges.set(productId, -change));

        const oldOutput = (oldData?.status === 'completed') ? (oldData.output || []) : [];
        const newOutput = (newData?.status === 'completed') ? (newData.output || []) : [];
        const outputDiff = calculateItemChanges(newOutput, oldOutput);
        outputDiff.forEach((change, productId) => outputChanges.set(productId, change));
      }

      const combinedChanges = new Map();
      inputChanges.forEach((change, id) => combinedChanges.set(id, (combinedChanges.get(id) || 0) + change));
      outputChanges.forEach((change, id) => combinedChanges.set(id, (combinedChanges.get(id) || 0) + change));

      combinedChanges.forEach((change, productId) => {
        if (change !== 0) adjustments.push({ productId, change, operationType: `stock_adjust_prod_${operationKind}` });
      });
    }

    if (adjustments.length > 0) {
      console.log(`Performing ${adjustments.length} stock adjustments for ${operationKind} ${storeName} (Ref: ${referenceId})`);
      const adjustmentPromises = adjustments.map(adj =>
        this.adjustStockAndLog(transaction, adj.productId, adj.change, adj.operationType, referenceId, referenceType, null)
          .catch(err => {
            console.error(`Stock adjustment failed for product ${adj.productId} during ${adj.operationType}:`, err);
          })
      );
      await Promise.all(adjustmentPromises);
      console.log(`Finished stock adjustments for ${operationKind} ${storeName} (Ref: ${referenceId})`);
    } else {
      console.log(`No stock adjustments needed for ${operationKind} ${storeName} (Ref: ${referenceId})`);
    }
  }

  async _getLocalRecordInternal(transaction, storeName, key) {
    return new Promise((resolve, reject) => {
      try {
        const store = transaction.objectStore(storeName);
        const request = store.get(key);
        request.onsuccess = () => resolve(request.result);
        request.onerror = (e) => reject(e.target.error);
      } catch (error) { reject(error); }
    });
  }

  async _updateLocalRecordInternal(transaction, storeName, data) {
    return new Promise((resolve, reject) => {
      try {
        const store = transaction.objectStore(storeName);
        const request = store.put(data);
        request.onsuccess = () => resolve(data);
        request.onerror = (e) => reject(e.target.error);
      } catch (error) { reject(error); }
    });
  }

  async _addToSyncQueueInternal(transaction, storeName, operation, data) {
    const syncOpId = `sync_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const dataKey = data[keyName];

    if (dataKey === undefined || dataKey === null) {
      throw new Error(`Missing key for sync operation (${operation} ${storeName})`);
    }

    const syncItem = {
      id: syncOpId,
      storeName,
      operation,
      dataKey: dataKey,
      data: JSON.parse(JSON.stringify(data)),
      timestamp: Date.now()
    };

    return new Promise((resolve, reject) => {
      try {
        const store = transaction.objectStore('sync');
        const request = store.add(syncItem);
        request.onsuccess = () => resolve(syncItem);
        request.onerror = (e) => {
          console.error("Error adding to sync queue (internal):", e.target.error);
          reject(e.target.error);
        };
      } catch (error) { reject(error); }
    });
  }

  async getAllLocal(storeName) {
    await this.ensureDB();
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction(storeName, 'readonly');
        const store = transaction.objectStore(storeName);
        const request = store.getAll();
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = (e) => {
          console.error(`Error getting all local ${storeName}:`, e.target.error);
          reject(e.target.error);
        };
      } catch (error) {
        console.error(`Error in getAllLocal for ${storeName}:`, error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async updateLocalRecord(storeName, data) {
    await this.ensureDB();
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const keyName = store.keyPath;

        if (!data || !data.hasOwnProperty(keyName) || data[keyName] === null || data[keyName] === undefined || (typeof data[keyName] === 'string' && data[keyName].trim() === '')) {
          console.error(`Attempted to update local record in ${storeName} without valid key '${keyName}':`, data);
          return reject(new Error(`Missing or invalid key '${keyName}' for store ${storeName}`));
        }
        const dataToStore = JSON.parse(JSON.stringify(data));
        const request = store.put(dataToStore);

        request.onsuccess = () => resolve(dataToStore);
        request.onerror = (e) => {
          console.error(`Error updating local record in ${storeName} (key: ${data[keyName]}):`, e.target.error, dataToStore);
          reject(e.target.error);
        };
      } catch (error) {
        console.error(`Error in updateLocalRecord transaction for ${storeName}:`, error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async deleteLocalRecord(storeName, key) {
    await this.ensureDB();
    if (key === null || key === undefined || (typeof key === 'string' && key.trim() === '')) {
      console.error(`Attempted to delete local record in ${storeName} with invalid key:`, key);
      return Promise.reject(new Error(`Invalid key provided for deletion in ${storeName}`));
    }
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.delete(key);
        request.onsuccess = () => resolve();
        request.onerror = (e) => {
          console.error(`Error deleting local record ${key} from ${storeName}:`, e.target.error);
          reject(e.target.error);
        };
      } catch (error) {
        console.error(`Error in deleteLocalRecord transaction for ${storeName}:`, error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async updateLocalStore(storeName, items) {
    await this.ensureDB();
    return new Promise((resolve, reject) => {
      if (!Array.isArray(items)) {
        console.error(`updateLocalStore expected an array for ${storeName}, got:`, typeof items);
        return reject(new Error(`Invalid data format for ${storeName}`));
      }
      let transaction;
      try {
        transaction = this.db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const keyName = store.keyPath;
        let processedCount = 0;
        let errorCount = 0;
        const totalItems = items.length;

        const clearRequest = store.clear();
        clearRequest.onerror = (e) => {
          console.error(`Error clearing ${storeName} before update:`, e.target.error);
          if (transaction?.abort) transaction.abort();
          reject(e.target.error);
        };

        clearRequest.onsuccess = () => {
          console.log(`Store ${storeName} cleared.`);
          if (totalItems === 0) {
            console.log(`No items to add to ${storeName}.`);
            resolve();
            return;
          }

          const addNext = (index) => {
            if (index >= totalItems) {
              console.log(`Finished adding items to ${storeName}. Added: ${totalItems - errorCount}, Errors: ${errorCount}`);
              resolve();
              return;
            }

            const item = items[index];
            const itemKey = item ? item[keyName] : undefined;

            if (item === null || itemKey === undefined || itemKey === null || (typeof itemKey === 'string' && itemKey.trim() === '')) {
              console.warn(`Item in ${storeName} missing or has invalid key '${keyName}', skipping:`, item);
              errorCount++;
              addNext(index + 1);
              return;
            }

            try {
              const itemToAdd = JSON.parse(JSON.stringify(item));
              const addRequest = store.add(itemToAdd);

              addRequest.onsuccess = () => {
                processedCount++;
                addNext(index + 1);
              };
              addRequest.onerror = (e) => {
                errorCount++;
                console.error(`Error adding item to ${storeName} during sync (key: ${itemKey}):`, e.target.error);
                addNext(index + 1);
              };
            } catch (addError) {
              errorCount++;
              console.error(`Error calling store.add for item in ${storeName} (key: ${itemKey}):`, addError, item);
              addNext(index + 1);
            }
          };

          addNext(0);
        };

        transaction.oncomplete = () => {
        };
        transaction.onerror = (e) => {
          console.error(`Transaction error during updateLocalStore for ${storeName}:`, e.target.error);
          reject(e.target.error);
        };

      } catch (error) {
        console.error(`Error initiating updateLocalStore transaction for ${storeName}:`, error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async addToSyncQueue(storeName, operation, data) {
    await this.ensureDB();
    const syncOpId = `sync_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const dataKey = data[keyName];

    if (dataKey === undefined || dataKey === null || (typeof dataKey === 'string' && dataKey.trim() === '')) {
      console.error(`Cannot add to sync queue: Missing or invalid key '${keyName}' in data for ${storeName}`, data);
      throw new Error(`Missing or invalid key '${keyName}' for sync operation.`);
    }

    const syncItem = {
      id: syncOpId,
      storeName,
      operation,
      dataKey: dataKey,
      data: JSON.parse(JSON.stringify(data)),
      timestamp: Date.now()
    };

    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction('sync', 'readwrite');
        const store = transaction.objectStore('sync');
        const request = store.add(syncItem);
        request.onsuccess = () => {
          console.log(`Added to sync queue: ${operation} on ${storeName} (Data Key: ${dataKey}, Sync ID: ${syncOpId})`);
          resolve(syncItem);
        };
        request.onerror = (e) => {
          console.error('Error adding to sync queue:', e.target.error, syncItem);
          reject(e.target.error);
        };
      } catch (error) {
        console.error('Error in addToSyncQueue:', error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async syncWithServer() {
    await this.ensureDB();
    if (!this.isOnline) {
      console.log('Sync deferred: offline.');
      return;
    }

    console.log('Attempting sync with server...');

    let syncReadTx;
    try {
      syncReadTx = this.db.transaction('sync', 'readonly');
      const store = syncReadTx.objectStore('sync');
      const request = store.getAll();

      request.onerror = (e) => console.error('Error fetching sync queue:', e.target.error);
      request.onsuccess = async () => {
        const pendingOperations = request.result;
        if (pendingOperations.length === 0) {
          console.log('Sync queue is empty.');
          console.log("Fetching latest data after empty sync queue.");
          window.dispatchEvent(new CustomEvent('request-data-refresh'));
          return;
        }
        console.log(`Processing ${pendingOperations.length} pending operations...`);
        pendingOperations.sort((a, b) => a.timestamp - b.timestamp);

        let failedOps = 0;
        for (const op of pendingOperations) {
          if (!navigator.onLine) {
            console.log("Went offline during sync processing. Stopping.");
            break;
          }
          try {
            console.log(`Syncing: ${op.operation} on ${op.storeName} (Data Key: ${op.dataKey}, Sync ID: ${op.id})`);
            const method = op.operation === 'add' ? 'POST' : (op.operation === 'update' ? 'PUT' : 'DELETE');
            await this._sendToServerCore(method, op.storeName, op.data, op.id);
          } catch (error) {
            failedOps++;
            console.error(`Failed to sync operation ${op.id}:`, error);
          }
        }
        console.log(`Sync processing finished. Failed ops: ${failedOps}`);
        if (failedOps < pendingOperations.length || pendingOperations.length > 0) {
          console.log("Fetching latest data after sync processing.");
          window.dispatchEvent(new CustomEvent('request-data-refresh'));
        }
      };
      await syncReadTx.done;

    } catch (error) {
      console.error('Error during sync process initiation:', error);
      if (syncReadTx?.abort) {
        try { syncReadTx.abort(); } catch (abortError) { console.error("Error aborting sync read transaction:", abortError); }
      }
    }
  }

  async removeSyncOperation(syncOpId) {
    await this.ensureDB();
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction('sync', 'readwrite');
        const store = transaction.objectStore('sync');
        const request = store.delete(syncOpId);
        request.onsuccess = () => resolve();
        request.onerror = (e) => {
          console.error(`Error removing sync operation ${syncOpId}:`, e.target.error);
          reject(e.target.error);
        };
      } catch (error) {
        console.error('Error in removeSyncOperation:', error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async getSettings() {
    try {
      await this.ensureDB();
      let settings = {};

      const tx = this.db.transaction('settings', 'readonly');
      const store = tx.objectStore('settings');
      const request = store.getAll();
      
      const allSettings = await new Promise((res, rej) => {
        request.onsuccess = () => res(request.result);
        request.onerror = (e) => rej(e.target.error);
      });

      if (allSettings.length > 0) {
        allSettings.forEach(s => settings[s.category] = s.data);
        console.log("Settings loaded from IndexedDB");
      } 
      else {
        console.log("No settings in IndexedDB, attempting localStorage fallback.");
        settings = this.getSettingsFromLocalStorage();
        
        try {
          await this.saveAllSettingsToDB(settings);
        } catch (dbSaveError) {
          console.error("Failed to save settings from localStorage to IndexedDB:", dbSaveError);
        }
      }

      const defaultTaxes = { enabledTaxes: [], rates: { vat: 18 }, automation: {}, declarations: {}, deadlines: {}, integrations: {} };
      const defaultAccounts = { defaultMappings: {} };
      const defaultGeneral = { companyName: "Anbar Sistemi", currency: "AZN" };
      const defaultInvoices = { invoicePrefix: "INV-", showLogo: true };
      const defaultEmail = {};

      const categories = ['general', 'invoices', 'taxes', 'backup', 'appearance', 'accounts', 'email'];

      categories.forEach(cat => {
        if (!settings[cat]) {
          settings[cat] = cat === 'accounts' ? { ...defaultAccounts }
                        : cat === 'email' ? { ...defaultEmail }
                        : cat === 'general' ? { ...defaultGeneral }
                        : cat === 'invoices' ? { ...defaultInvoices }
                        : {};
        }

        if (cat === 'taxes') {
          settings.taxes.rates = { ...defaultTaxes.rates, ...(settings.taxes.rates || {}) };
          settings.taxes.automation = { ...defaultTaxes.automation, ...(settings.taxes.automation || {}) };
          settings.taxes.declarations = { ...defaultTaxes.declarations, ...(settings.taxes.declarations || {}) };
          settings.taxes.deadlines = { ...defaultTaxes.deadlines, ...(settings.taxes.deadlines || {}) };
          settings.taxes.integrations = { ...defaultTaxes.integrations, ...(settings.taxes.integrations || {}) };
        }
        if (cat === 'accounts') {
          settings.accounts.defaultMappings = { ...defaultAccounts.defaultMappings, ...(settings.accounts.defaultMappings || {}) };
        }
      });

      return settings;
    } catch (error) {
      console.error('Critical error getting settings:', error);
      
      return {
        general: { companyName: "Anbar Sistemi", currency: "AZN" },
        invoices: { invoicePrefix: "INV-", showLogo: true },
        taxes: { enabledTaxes: [], rates: { vat: 18 } },
        accounts: { defaultMappings: {} },
        email: {}
      };
    }
  }

  getSettingsFromLocalStorage() {
    const settings = {};
    const defaultAccountSettings = { accountingPlan: [], defaultMappings: {} };
    const categories = ['general', 'invoices', 'taxes', 'backup', 'appearance', 'accounts', 'email'];

    categories.forEach(cat => {
      try {
        const data = localStorage.getItem(`settings_${cat}`);
        if (cat === 'accounts') {
          settings[cat] = data ? JSON.parse(data) : { ...defaultAccountSettings };
          if (!settings[cat].accountingPlan) settings[cat].accountingPlan = [];
          if (!settings[cat].defaultMappings) settings[cat].defaultMappings = {};
        } else {
          settings[cat] = data ? JSON.parse(data) : {};
        }
      } catch (e) {
        console.error(`Error parsing localStorage settings for ${cat}:`, e);
        if (cat === 'accounts') settings[cat] = { ...defaultAccountSettings };
        else settings[cat] = {};
      }
    });
    return settings;
  }

  async saveAllSettingsToDB(settings) {
    await this.ensureDB();
    const tx = this.db.transaction('settings', 'readwrite');
    const store = tx.objectStore('settings');
    const promises = Object.entries(settings).map(([category, data]) => {
      console.log(`Saving fallback settings category ${category} to IndexedDB`);
      const dataToStore = data === undefined ? {} : data;
      return store.put({ category: category, data: dataToStore });
    });
    await Promise.all(promises);
    await tx.done;
    console.log("Fallback settings saved to IndexedDB.");
  }

  async saveSettings(category, data) {
    await this.ensureDB();
    try {
      const dataToStore = data === undefined || data === null ? {} : JSON.parse(JSON.stringify(data));

      if (!category || typeof category !== 'string') {
        throw new Error('Invalid settings category');
      }

      const tx = this.db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');
      
      await new Promise((resolve, reject) => {
        const request = store.put({ category: category, data: dataToStore });
        request.onsuccess = () => resolve();
        request.onerror = (e) => reject(e.target.error);
      });

      try {
        localStorage.setItem(`settings_${category}`, JSON.stringify(dataToStore));
      } catch (localStorageError) {
        console.warn('Could not save settings to localStorage:', localStorageError);
      }

      console.log(`Settings saved locally (IndexedDB) for category: ${category}`);

      if (this.isOnline) {
        try {
          await this.saveSettingsToServer(category, dataToStore);
        } catch (serverError) {
          console.warn(`Failed to save settings ${category} to server:`, serverError);
        }
      }

      return true;
    } catch (error) {
      console.error(`Comprehensive error saving settings for ${category}:`, error);
      
      try {
        localStorage.setItem(`settings_${category}`, JSON.stringify(data || {}));
        console.log(`Fallback: Settings saved to localStorage for ${category}`);
        return true;
      } catch (localStorageError) {
        console.error('Failed to save settings to localStorage:', localStorageError);
        
        if (this.$root && this.$root.showNotification) {
          this.$root.showNotification('error', 'Parametr Xətası', `${category} parametrlərini saxlamaq mümkün olmadı. Texniki dəstəyə müraciət edin.`);
        }
        
        return false;
      }
    }
  }

  async fetchSettingsFromServer() {
    if (!this.isOnline) return null;
    try {
      const response = await fetch(`${this.API_URL}/settings?t=${Date.now()}`);

      if (!response.ok) { console.error(`Server error fetching settings: ${response.status}`); return null; }
      return await response.json();
    } catch (error) {
      console.error('Error fetching settings from server:', error);
      return null;
    }
  }

  async saveSettingsToServer(category, data) {
    if (!this.isOnline) return;
    try {
      const response = await fetch(`${this.API_URL}/settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category, settings: data })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Server error saving settings for ${category}: ${response.status}`, errorText);
        throw new Error(`Server error saving settings: ${response.status}`);
      }
      console.log(`Settings for category ${category} saved to server.`);
    } catch (error) {
      console.error(`Error saving settings to server for ${category}:`, error);
      throw error;
    }
  }
}

const dbService = new DatabaseService();
export default dbService;