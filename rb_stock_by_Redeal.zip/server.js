import express from 'express';
import cors from 'cors';
import path from 'path';
import mysql from 'mysql2/promise'; 
import bcrypt from 'bcrypt';

import { query, testConnection } from './database.js';

const app = express();
const port = process.env.PORT || 3000;
const saltRounds = 10;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static('public'));

const apiRouter = express.Router();

apiRouter.use((req, res, next) => {
  console.log(`[API] ${req.method} ${req.path} - Body:`, req.body ? JSON.stringify(req.body).substring(0, 100) + '...' : 'N/A');
  res.on('finish', () => {
    console.log(`[API] ${req.method} ${req.path} - Response: ${res.statusCode}`);
  });
  next();
});

apiRouter.get('/users/list', async (req, res, next) => {
  console.log("[API /users/list] Fetching user list...");
  try {
    const users = await query('SELECT id, fullName, username FROM users WHERE status = ? ORDER BY fullName ASC', ['active']);
    console.log(`[API /users/list] Found ${users.length} active users.`);
    res.json(users);
  } catch (error) {
    console.error("[API /users/list] Error fetching user list:", error);
    next(error); 
  }
});

apiRouter.post('/login', async (req, res, next) => {
  const { username } = req.body;
  console.log(`[API /login] Attempting login for username: ${username}`);

  if (!username) {
    console.log("[API /login] Bad Request: Username missing.");
    return res.status(400).json({ message: 'İstifadəçi adı tələb olunur' });
  }

  try {
    const [user] = await query('SELECT * FROM users WHERE username = ? AND status = ?', [username, 'active']);

    if (!user) {
      console.log(`[API /login] Unauthorized: User '${username}' not found or inactive.`);
      return res.status(401).json({ message: 'İstifadəçi tapılmadı və ya aktiv deyil' });
    }

    const token = `simulated-token-for-${user.id}-${Date.now()}`;
    console.log(`[API /login] Simulating successful login for user ID ${user.id}. Generated token.`);

    delete user.password;

    res.json({ token, user });

  } catch (error) {
    console.error("[API /login] Login Error:", error);
    next(error);
  }
});

apiRouter.post('/register', async (req, res, next) => {
    const { fullName, username, email, password } = req.body;
    console.log(`[API /register] Registration attempt for username: ${username}`);

    if (!fullName || !username || !password) {
        console.log("[API /register] Bad Request: Missing required fields.");
        return res.status(400).json({ message: 'Tam ad, istifadəçi adı və şifrə tələb olunur' });
    }
    if (password.length < 6) return res.status(400).json({ message: 'Şifrə ən azı 6 simvol olmalıdır' });
    if (!/^[a-zA-Z0-9_]{3,}$/.test(username)) return res.status(400).json({ message: 'İstifadəçi adı ən azı 3 simvol olmalı, yalnız hərf, rəqəm və alt xətt (_) ola bilər' });
    const finalEmail = email ? email.trim() : null;
    if (finalEmail && !/\S+@\S+\.\S+/.test(finalEmail)) return res.status(400).json({ message: 'Email formatı düzgün deyil' });

    try {
        const [existingUser] = await query('SELECT id FROM users WHERE username = ? OR (email = ? AND email IS NOT NULL)', [username, finalEmail]);
        if (existingUser) {
            console.log(`[API /register] Conflict: Username or email already exists for ${username}/${finalEmail}`);
            return res.status(409).json({ message: 'Bu istifadəçi adı və ya email artıq mövcuddur' });
        }

        const hashedPassword = await bcrypt.hash(password, saltRounds);
        const defaultRole = 'sales';
        const defaultPermissions = JSON.stringify(['view_dashboard']);
        const defaultStatus = 'active';

        console.log(`[API /register] Inserting new user: ${username}`);
        const result = await query(
            'INSERT INTO users (fullName, username, email, password, role, permissions, status, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())',
            [fullName, username, finalEmail, hashedPassword, defaultRole, defaultPermissions, defaultStatus]
        );

        if (result.insertId) {
            console.log(`[API /register] User ${username} registered successfully with ID: ${result.insertId}`);
            res.status(201).json({ message: 'Qeydiyyat uğurla tamamlandı!' });
        } else {
            console.error("[API /register] Insert operation did not return an insertId.");
            throw new Error('İstifadəçi yaradıla bilmədi');
        }

    } catch (error) {
        console.error("[API /register] Registration Error:", error);
        if (error.code === 'ER_DUP_ENTRY') {
           return res.status(409).json({ message: 'Daxil edilən istifadəçi adı və ya email artıq mövcuddur (DB)' });
        }
        next(error); 
    }
});

apiRouter.get('/:resource', async (req, res, next) => {
  const resource = req.params.resource;
  console.log(`[API GET /${resource}] Fetching all items...`);
  const validResources = ['products', 'categories', 'customers', 'suppliers', 'sales', 'purchases', 'operations', 'productions', 'accounts', 'transactions', 'users'];
  if (!validResources.includes(resource)) {
    console.log(`[API GET /${resource}] Resource not found.`);
    return res.status(404).json({ message: 'Resource not found' });
  }
  try {
    let results;
    let sql = `SELECT * FROM ${resource}`; 

    if (resource === 'accounts') sql += ' ORDER BY code ASC';
    else if (resource === 'users') sql = `SELECT id, fullName, username, email, role, permissions, status, createdAt, lastLogin FROM ${resource} ORDER BY fullName ASC`;
    else if (['operations', 'sales', 'purchases', 'transactions'].includes(resource)) sql += ' ORDER BY date DESC';
    else sql += ' ORDER BY id DESC'; 

    results = await query(sql);
    console.log(`[API GET /${resource}] Found ${results.length} items.`);
    res.json(results);
  } catch (error) {
    console.error(`[API GET /${resource}] Error fetching resource:`, error);
    next(error);
  }
});

apiRouter.get('/:resource/:key', async (req, res, next) => {
  const resource = req.params.resource;
  const key = req.params.key;
  const keyName = resource === 'accounts' ? 'code' : 'id';
  console.log(`[API GET /${resource}/${key}] Fetching single item...`);

  const validResources = ['products', 'categories', 'customers', 'suppliers', 'sales', 'purchases', 'operations', 'productions', 'accounts', 'transactions', 'users'];
  if (!validResources.includes(resource)) return res.status(404).json({ message: 'Resource not found' });
  if (!key) return res.status(400).json({ message: 'ID/Kod tələb olunur' });

  try {
    let sql = `SELECT * FROM ${resource} WHERE ${keyName} = ?`;
    if (resource === 'users') sql = `SELECT id, fullName, username, email, role, permissions, status, createdAt, lastLogin FROM users WHERE id = ?`;

    const [item] = await query(sql, [key]);

    if (!item) {
      console.log(`[API GET /${resource}/${key}] Item not found.`);
      return res.status(404).json({ message: `${resource} tapılmadı` });
    }
    console.log(`[API GET /${resource}/${key}] Item found.`);
    res.json(item);
  } catch (error) {
    console.error(`[API GET /${resource}/${key}] Error fetching single item:`, error);
    next(error);
  }
});

apiRouter.post('/:resource', async (req, res, next) => {
  const resource = req.params.resource;
  let data = req.body; 
  console.log(`[API POST /${resource}] Creating new item...`, data);

  const validResources = ['products', 'categories', 'customers', 'suppliers', 'sales', 'purchases', 'operations', 'productions', 'accounts', 'transactions', 'users'];
  if (!validResources.includes(resource)) return res.status(404).json({ message: 'Resource not found' });

  if (resource === 'accounts' && (!data.code || data.code.trim() === '')) return res.status(400).json({ message: 'Hesab kodu tələb olunur' });
  if (resource === 'transactions' && !data.type) return res.status(400).json({ message: 'Tranzaksiya tipi tələb olunur' });

  try {
    let result;
    let newItemIdOrCode;
    const keyName = resource === 'accounts' ? 'code' : 'id';

    if (resource === 'users' && data.password) {
      if (data.password.length < 6) return res.status(400).json({ message: 'Şifrə ən azı 6 simvol olmalıdır' });
      data.password = await bcrypt.hash(data.password, saltRounds);
      data.permissions = JSON.stringify(data.permissions || ['view_dashboard']); 
      console.log(`[API POST /users] Hashed password for user ${data.username}`);
    } else if (resource === 'users' && !data.id) { 
      return res.status(400).json({ message: 'Yeni istifadəçi üçün şifrə tələb olunur' });
    }

    if (keyName === 'id' && data.id) delete data.id; 

    const columns = Object.keys(data).map(col => `\`${col}\``).join(', '); 
    const placeholders = Object.keys(data).map(() => '?').join(', ');
    const values = Object.values(data);

    if (!columns) return res.status(400).json({ message: 'Əlavə etmək üçün məlumat tələb olunur' });

    const sql = `INSERT INTO \`${resource}\` (${columns}) VALUES (${placeholders})`;
    console.log(`[API POST /${resource}] Executing SQL: ${sql}`, values);
    result = await query(sql, values);

    if (resource === 'accounts') {
        newItemIdOrCode = data.code; 
    } else if (result.insertId) {
        newItemIdOrCode = result.insertId;
    } else {
        console.error(`[API POST /${resource}] Insert operation did not return an ID.`);
        throw new Error("Element yaradılarkən ID alınmadı.");
    }

    console.log(`[API POST /${resource}] Item created successfully with Key: ${newItemIdOrCode}`);

    let selectSql = `SELECT * FROM \`${resource}\` WHERE \`${keyName}\` = ?`;
    if (resource === 'users') selectSql = `SELECT id, fullName, username, email, role, permissions, status, createdAt, lastLogin FROM users WHERE id = ?`;
    const [newItem] = await query(selectSql, [newItemIdOrCode]);

    res.status(201).json(newItem);

  } catch (error) {
    console.error(`[API POST /${resource}] Error creating item:`, error);
    next(error);
  }
});

apiRouter.put('/:resource/:key', async (req, res, next) => {
  const resource = req.params.resource;
  const key = req.params.key;
  let data = req.body;
  const keyName = resource === 'accounts' ? 'code' : 'id';
  console.log(`[API PUT /${resource}/${key}] Updating item...`, data);

  const validResources = ['products', 'categories', 'customers', 'suppliers', 'sales', 'purchases', 'operations', 'productions', 'accounts', 'transactions', 'users'];
  if (!validResources.includes(resource)) return res.status(404).json({ message: 'Resource not found' });
  if (!key) return res.status(400).json({ message: 'Yeniləmək üçün ID/Kod tələb olunur' });

  try {
    if (data[keyName] && data[keyName] !== key) {
      console.warn(`[API PUT /${resource}/${key}] Attempt to change primary key ignored.`);
      delete data[keyName];
    }
    if (keyName === 'id' && data.id) delete data.id; 

    if (resource === 'users' && data.password && data.password.length > 0) { 
      if (data.password.length < 6) return res.status(400).json({ message: 'Şifrə ən azı 6 simvol olmalıdır' });
      data.password = await bcrypt.hash(data.password, saltRounds);
      console.log(`[API PUT /users/${key}] Hashed new password.`);
    } else if (resource === 'users') {
      delete data.password; 
    }
    if (resource === 'users' && data.permissions) {
       data.permissions = JSON.stringify(data.permissions || []);
    }

    const columnsToUpdate = Object.keys(data).map(col => `\`${col}\` = ?`).join(', ');
    const values = [...Object.values(data), key];

    if (!columnsToUpdate) return res.status(400).json({ message: 'Yeniləmək üçün məlumat tələb olunur' });

    const sql = `UPDATE \`${resource}\` SET ${columnsToUpdate} WHERE \`${keyName}\` = ?`;
    console.log(`[API PUT /${resource}/${key}] Executing SQL: ${sql}`, values);
    const result = await query(sql, values);

    if (result.affectedRows === 0) {
      console.log(`[API PUT /${resource}/${key}] Item not found or no changes made.`);
      return res.status(404).json({ message: `${resource} (Key: ${key}) tapılmadı və ya yenilənmədi` });
    }

    console.log(`[API PUT /${resource}/${key}] Item updated successfully.`);

    let selectSql = `SELECT * FROM \`${resource}\` WHERE \`${keyName}\` = ?`;
     if (resource === 'users') selectSql = `SELECT id, fullName, username, email, role, permissions, status, createdAt, lastLogin FROM users WHERE id = ?`;
    const [updatedItem] = await query(selectSql, [key]);

    res.json(updatedItem);

  } catch (error) {
    console.error(`[API PUT /${resource}/${key}] Error updating item:`, error);
    next(error);
  }
});

apiRouter.delete('/:resource/:key', async (req, res, next) => {
  const resource = req.params.resource;
  const key = req.params.key;
  const keyName = resource === 'accounts' ? 'code' : 'id';
  console.log(`[API DELETE /${resource}/${key}] Deleting item...`);

  const validResources = ['products', 'categories', 'customers', 'suppliers', 'sales', 'purchases', 'operations', 'productions', 'accounts', 'transactions', 'users'];
  if (!validResources.includes(resource)) return res.status(404).json({ message: 'Resource not found' });
  if (!key) return res.status(400).json({ message: 'Silmək üçün ID/Kod tələb olunur' });

  if (resource === 'users' && key === '1') { 
      console.warn(`[API DELETE /users/${key}] Attempt to delete admin user prevented.`);
      return res.status(403).json({ message: 'Admin istifadəçisi silinə bilməz' });
  }

  try {
    console.log(`[API DELETE /${resource}/${key}] Placeholder: Performing pre-delete checks/adjustments...`);

    const sql = `DELETE FROM \`${resource}\` WHERE \`${keyName}\` = ?`;
    console.log(`[API DELETE /${resource}/${key}] Executing SQL: ${sql}`, [key]);
    const result = await query(sql, [key]);

    if (result.affectedRows === 0) {
      console.log(`[API DELETE /${resource}/${key}] Item not found.`);
      return res.status(404).json({ message: `${resource} (Key: ${key}) tapılmadı` });
    }

    console.log(`[API DELETE /${resource}/${key}] Item deleted successfully.`);
    res.status(204).send(); 

  } catch (error) {
    console.error(`[API DELETE /${resource}/${key}] Error deleting item:`, error);
    if (error.code === 'ER_ROW_IS_REFERENCED_2') {
      console.log(`[API DELETE /${resource}/${key}] Conflict: Item is referenced elsewhere.`);
      return res.status(409).json({ message: `Bu element silinə bilməz, çünki başqa qeydlərdə istifadə olunur.` });
    }
    next(error);
  }
});

apiRouter.get('/settings', async (req, res, next) => {
    console.log("[API GET /settings] Fetching settings...");
    try {
        const dbSettings = await query('SELECT category, settings_data FROM settings');
        const formattedSettings = dbSettings.reduce((acc, row) => {
            try {
                acc[row.category] = JSON.parse(row.settings_data || '{}'); 
            } catch (e) {
                console.error(`[API GET /settings] Failed to parse settings for category ${row.category}:`, e, row.settings_data);
                acc[row.category] = {}; 
            }
            return acc;
        }, {});
        console.log("[API GET /settings] Settings fetched and formatted:", Object.keys(formattedSettings));
        res.json(formattedSettings);
    } catch (error) {
        console.error("[API GET /settings] Error fetching settings:", error);
        next(error);
    }
});

apiRouter.post('/settings', async (req, res, next) => {
    const { category, settings } = req.body;
    console.log(`[API POST /settings] Saving settings for category: ${category}...`); 
    if (!category || typeof settings === 'undefined') {
        return res.status(400).json({ message: 'Kateqoriya və parametr məlumatları tələb olunur' });
    }
    try {
        const settingsJson = JSON.stringify(settings || {}); 
        await query('INSERT INTO settings (category, settings_data) VALUES (?, ?) ON DUPLICATE KEY UPDATE settings_data = ?',
            [category, settingsJson, settingsJson]);
        console.log(`[API POST /settings] Settings saved successfully for category: ${category}`);
        res.status(200).json({ message: `${category} parametrləri saxlanıldı` });
    } catch (error) {
        console.error(`[API POST /settings] Error saving settings for ${category}:`, error);
        next(error);
    }
});

apiRouter.post('/email/test', async (req, res) => {
    const { host, port, secure, username, password } = req.body;
    console.log("[API /email/test] Received SMTP test request:", { host, port, secure, username }); 
    if (!host || !port) {
        return res.status(400).json({ message: 'Host və Port tələb olunur' });
    }
    console.log("[API /email/test] Simulating SMTP test...");
    await new Promise(resolve => setTimeout(resolve, 1000)); 
    if (host.includes('.') && port > 0) {
        console.log("[API /email/test] Simulation successful.");
        res.status(200).json({ message: 'SMTP bağlantısı yoxlanıldı (simulyasiya)' });
    } else {
        console.log("[API /email/test] Simulation failed.");
        res.status(500).json({ message: 'SMTP bağlantısı uğursuz oldu (simulyasiya)' });
    }
});

apiRouter.post('/email/send-test', async (req, res) => {
    const { smtpConfig, to } = req.body;
    console.log("[API /email/send-test] Received send test email request to:", to); 
    if (!to || !smtpConfig || !smtpConfig.host || !smtpConfig.port) {
        return res.status(400).json({ message: 'SMTP konfiqurasiyası (host/port) və alıcı email tələb olunur' });
    }
    console.log("[API /email/send-test] Simulating sending test email...");
    await new Promise(resolve => setTimeout(resolve, 1500)); 
    console.log("[API /email/send-test] Simulation successful.");
    res.status(200).json({ message: 'Test email göndərildi (simulyasiya)' });
});

app.use('/api', apiRouter);

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) {
    return next();
  }
  if (path.extname(req.path).length > 0) {
    res.sendFile(path.resolve('public', req.path.substring(1)), (err) => {
      if (err && err.status === 404) {
        console.log(`[Serve] File not found: ${req.path}, returning 404.`);
        res.status(404).send('Not Found'); 
      } else if (err) {
        next(err); 
      }
    });
  } else {
    console.log(`[Serve] Serving index.html for path: ${req.path}`);
    res.sendFile(path.resolve('public', 'index.html'));
  }
});

app.use((err, req, res, next) => {
  let statusCode = err.status || 500;
  let message = err.message || 'An unexpected server error occurred.';
  console.error("[Error Handler] Caught error:", err); 

  if (err.code) {
    console.error(`[Error Handler] MySQL Error Code: ${err.code}`);
    switch (err.code) {
      case 'ER_DUP_ENTRY':
        statusCode = 409; 
        message = 'Daxil edilən məlumat (məsələn, kod, istifadəçi adı və ya email) artıq mövcuddur.';
        break;
      case 'ER_NO_REFERENCED_ROW_2':
        statusCode = 400; 
        message = 'Əlaqəli məlumat tapılmadı (məsələn, seçilmiş kateqoriya mövcud deyil).';
        break;
      case 'ER_ROW_IS_REFERENCED_2':
        statusCode = 409; 
        message = 'Bu element silinə bilməz, çünki başqa qeydlərdə istifadə olunur.';
        break;
      case 'ER_BAD_FIELD_ERROR':
      case 'ER_TRUNCATED_WRONG_VALUE_FOR_FIELD':
      case 'ER_DATA_TOO_LONG':
         statusCode = 400; 
         message = 'Daxil edilən məlumatlar düzgün deyil və ya çox uzundur.';
         break;
       case 'ECONNREFUSED':
           statusCode = 503; 
           message = 'Verilənlər bazasına qoşulmaq mümkün olmadı. Serverin işlədiyindən əmin olun.';
           break;
       case 'PROTOCOL_CONNECTION_LOST':
           statusCode = 503;
           message = 'Verilənlər bazası ilə bağlantı kəsildi. Yenidən cəhd edin.';
           break;
      default:
        if (err.code.startsWith('ER_')) {
            console.warn(`[Error Handler] Unhandled MySQL Error Code: ${err.code}`);
            message = `Verilənlər bazası xətası: ${err.code}`;
        }
    }
  } else if (err.name === 'SyntaxError' && err.message.includes('JSON')) {
      statusCode = 400;
      message = 'Gondərilən məlumat formatı düzgün deyil (JSON xətası).';
  }

  res.status(statusCode).json({ message });
});

(async () => {
  try {
    await testConnection(); 
    console.log("[DB] Database connection successful.");
    app.listen(port, () => {
      console.log(`[Server] Server is running on http://localhost:${port}`);
    });
  } catch (error) {
    console.error("[Server Startup] FATAL: Could not connect to database. Server not started.", error);
    process.exit(1); 
  }
})();