import { config } from './config.js';

class DatabaseService {
  constructor() {
    this.dbName = 'anbarDB';
    this.dbVersion = 6; 
    this.db = null;
    this.isOnline = navigator.onLine;
    this.API_URL = config.API_URL;
    this.isAuthenticated = true; 

    this.stores = [
      'products', 'categories', 'customers', 'suppliers', 'sales',
      'purchases', 'operations', 'productions', 'accounts',
      'transactions', 'users', 'sync', 'settings' 
    ];

    window.addEventListener('online', this.handleOnlineStatusChange.bind(this));
    window.addEventListener('offline', this.handleOnlineStatusChange.bind(this));
  }

  async initDB() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        console.error('Your browser doesn\'t support IndexedDB');
        return reject('IndexedDB not supported');
      }
      if (this.db) {
        return resolve(this.db);
      }

      console.log(`[DB] Opening database ${this.dbName} version ${this.dbVersion}`);
      const request = indexedDB.open(this.dbName, this.dbVersion);

      request.onerror = (event) => {
        console.error('[DB] Database error:', event.target.error);
        reject(event.target.error);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        const transaction = event.target.transaction;

        console.log(`[DB] Running onupgradeneeded for version ${this.dbVersion}...`);

        const storeConfigs = {
          products: { keyPath: 'id', autoIncrement: false },
          categories: { keyPath: 'id', autoIncrement: false },
          customers: { keyPath: 'id', autoIncrement: false },
          suppliers: { keyPath: 'id', autoIncrement: false },
          sales: { keyPath: 'id', autoIncrement: false },
          purchases: { keyPath: 'id', autoIncrement: false },
          operations: { keyPath: 'id', autoIncrement: false },
          productions: { keyPath: 'id', autoIncrement: false },
          accounts: { keyPath: 'code' },
          transactions: { keyPath: 'id', autoIncrement: false },
          users: { keyPath: 'id', autoIncrement: false },
          sync: { keyPath: 'id', autoIncrement: false },
          settings: { keyPath: 'category' }
        };

        const indexes = {
          products: [
            { name: 'code', keyPath: 'code', options: { unique: true } },
            { name: 'name', keyPath: 'name' },
            { name: 'barcode', keyPath: 'barcode' }
          ],
          categories: [ { name: 'name', keyPath: 'name', options: { unique: true } } ],
          customers: [ { name: 'name', keyPath: 'name' }, { name: 'phone', keyPath: 'phone' } ],
          suppliers: [ { name: 'company', keyPath: 'company' }, { name: 'phone', keyPath: 'phone' } ],
          sales: [ { name: 'date', keyPath: 'date' }, { name: 'code', keyPath: 'code', options: { unique: true } }, { name: 'customerId', keyPath: 'customerId' } ],
          purchases: [ { name: 'date', keyPath: 'date' }, { name: 'code', keyPath: 'code', options: { unique: true } }, { name: 'supplierId', keyPath: 'supplierId'} ],
          operations: [ { name: 'date', keyPath: 'date' }, { name: 'type', keyPath: 'type' }, { name: 'referenceId', keyPath: 'referenceId'}, { name: 'productId', keyPath: 'productId'} ],
          productions: [ { name: 'startDate', keyPath: 'startDate' }, { name: 'status', keyPath: 'status'}, { name: 'name', keyPath: 'name' } ],
          accounts: [ { name: 'name', keyPath: 'name' }, { name: 'type', keyPath: 'type' }, { name: 'parentId', keyPath: 'parentId'} ],
          transactions: [ { name: 'date', keyPath: 'date' }, { name: 'type', keyPath: 'type' }, { name: 'accountId', keyPath: 'accountId' }, { name: 'customerId', keyPath: 'customerId' }, { name: 'fromAccountId', keyPath: 'fromAccountId' }, { name: 'toAccountId', keyPath: 'toAccountId' } ],
          users: [ { name: 'username', keyPath: 'username', options: { unique: true } } ],
          sync: [ { name: 'timestamp', keyPath: 'timestamp' } ],
          settings: []
        };

        this.stores.forEach(storeName => {
          let store;
          if (!db.objectStoreNames.contains(storeName)) {
            console.log(`[DB] Creating store: ${storeName}`);
            store = db.createObjectStore(storeName, storeConfigs[storeName]);
          } else {
            console.log(`[DB] Store ${storeName} exists, getting transaction.`);
            store = transaction.objectStore(storeName);
            const newIndexNames = indexes[storeName]?.map(idx => idx.name) || [];
            Array.from(store.indexNames).forEach(indexName => {
              if (!newIndexNames.includes(indexName)) {
                console.log(`[DB] Deleting old/unused index ${indexName} from ${storeName}`);
                try { store.deleteIndex(indexName); } catch (e) { console.warn(`[DB] Could not delete index ${indexName} from ${storeName}: ${e.message}`); }
              }
            });
          }

          if (indexes[storeName]) {
            indexes[storeName].forEach(index => {
              if (!store.indexNames.contains(index.name)) {
                console.log(`[DB] Creating index '${index.name}' for store '${storeName}'`);
                try { store.createIndex(index.name, index.keyPath, index.options || {}); } catch (e) { console.error(`[DB] Error creating index ${index.name} for ${storeName}: ${e.message}`); }
              } else {
                 console.log(`[DB] Index '${index.name}' already exists on store '${storeName}'`);
              }
            });
          }
        });

        console.log("[DB] onupgradeneeded finished.");
      };

      request.onsuccess = (event) => {
        this.db = event.target.result;
        console.log(`[DB] Database ${this.dbName} v${this.dbVersion} initialized successfully.`);
        this.db.onversionchange = () => {
          this.db.close();
          console.warn("[DB] Database version change detected, closing connection. Please reload.");
          alert("Database has been updated. Please reload the page.");
        };
        this.db.onclose = () => {
          console.log("[DB] Database connection closed.");
          this.db = null;
        };
        if (this.isOnline) {
          this.syncWithServer();
        }
        resolve(this.db);
      };

      request.onblocked = () => {
        console.warn("[DB] Database open request blocked. Please close other tabs/windows using this app.");
        alert("An older version of the app is open in another tab. Please close it and reload this page.");
      };
    });
  }

  async ensureDB() {
    if (!this.db) {
      console.log("[DB] DB not initialized, attempting to init...");
      try {
        await this.initDB();
      } catch (error) {
        console.error("[DB] Failed to initialize DB in ensureDB:", error);
        throw new Error("Database connection could not be established.");
      }
    }
    if (!this.db) {
      throw new Error("Database connection could not be established after init attempt.");
    }
  }

  handleOnlineStatusChange() {
    const wasOnline = this.isOnline;
    this.isOnline = navigator.onLine;

    if (!wasOnline && this.isOnline) {
      console.log('[NET] Device is back online. Starting sync...');
      this.syncWithServer();
    } else if (wasOnline && !this.isOnline) {
      console.log('[NET] Device is offline. Changes will be stored locally.');
    }
  }

  async adjustStockAndLog(transaction, productId, quantityChange, operationType, referenceId, referenceType, userId = null) {
    if (isNaN(quantityChange) || quantityChange === 0) {
      console.warn(`[Stock] Skipping stock adjustment for product ${productId}: Invalid quantity change ${quantityChange}`);
      return Promise.resolve(null);
    }
    console.log(`[Stock] Attempting adjustment: Product ${productId}, Change ${quantityChange}, Op: ${operationType}, Ref: ${referenceType}#${referenceId}`);

    const productsStore = transaction.objectStore('products');
    const operationsStore = transaction.objectStore('operations');

    return new Promise((resolve, reject) => {
      const getRequest = productsStore.get(productId);

      getRequest.onsuccess = () => {
        const product = getRequest.result;
        if (!product) {
          console.error(`[Stock] Product with ID ${productId} not found for stock adjustment.`);
          resolve(null);
          return;
        }

        const oldQuantity = parseFloat(product.quantity) || 0;
        const newQuantity = oldQuantity + parseFloat(quantityChange);

        console.log(`[Stock] Adjusting stock for ${product.name} (${productId}): ${oldQuantity} -> ${newQuantity} (Change: ${quantityChange}) due to ${operationType} ${referenceType} #${referenceId}`);

        const updatedProduct = { ...product, quantity: newQuantity };
        const putRequest = productsStore.put(updatedProduct);

        putRequest.onerror = (e) => {
          console.error(`[Stock] Error updating stock for product ${productId}:`, e.target.error);
          resolve(null);
        };

        putRequest.onsuccess = () => {
          const operationId = `op_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
          const logEntry = {
            id: operationId,
            type: operationType,
            date: new Date().toISOString(),
            productId: productId,
            productName: product.name,
            quantity: parseFloat(quantityChange),
            unit: product.unit || '',
            description: `${operationType} - Məhsul: ${product.name}, Miqdar: ${quantityChange}, Yeni Stok: ${newQuantity}`,
            referenceId: referenceId,
            referenceType: referenceType,
            userId: userId || null,
            userName: null 
          };

          const logRequest = operationsStore.add(logEntry);
          logRequest.onerror = (e) => {
            console.error("[OpLog] Error adding stock adjustment operation log:", e.target.error);
            resolve(updatedProduct); 
          };
          logRequest.onsuccess = () => {
             console.log(`[OpLog] Stock adjustment operation logged for ${productId}: Change ${quantityChange}, New Qty ${newQuantity}`);
            resolve(updatedProduct);
          };
        };
      };
      getRequest.onerror = (e) => {
        console.error(`[Stock] Error fetching product ${productId} for stock adjustment:`, e.target.error);
        resolve(null);
      };
    });
  }

  async fetchFromServer(storeName) {
    await this.ensureDB();
    if (!this.isOnline) {
      console.warn(`[NET] Cannot fetch ${storeName} from server: offline.`);
      return null;
    }

    const url = `${this.API_URL}/${storeName}?t=${Date.now()}`;
    console.log(`[NET] Fetching from server: ${url}`);
    try {
      const response = await fetch(url);

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`[NET] Server error fetching ${storeName}: ${response.status} ${response.statusText}`, errorText);
        throw new Error(`Server error: ${response.status} ${response.statusText}`);
      }
      const data = await response.json();
      console.log(`[NET] Fetched ${data?.length ?? 0} items for ${storeName} from server.`);
      return data;
    } catch (error) {
      console.error(`[NET] Error fetching ${storeName} from server:`, error);
      return null;
    }
  }

  async _sendToServerCore(method, storeName, data, syncOpId = null) {
    const context = syncOpId ? `sync op ${syncOpId}` : 'direct call';
    if (!this.isOnline) {
        console.error(`[NET] _sendToServerCore (${context}) called while offline - this should ideally be caught earlier.`);
        throw new Error(`NetworkError: Attempted server operation while offline (${context})`);
    }

    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const dataKey = data[keyName];
    const originalOfflineId = (method === 'POST' && dataKey && typeof dataKey === 'string' && dataKey.startsWith('offline_')) ? dataKey : null;
    const endpointKey = (method === 'PUT' || method === 'DELETE') ? dataKey : null;

    console.log(`[NET] Sending to server (${context}): ${method} ${storeName}`, { key: endpointKey ?? dataKey, originalOfflineId, hasPayload: method !== 'DELETE' });

    if ((method === 'PUT' || method === 'DELETE')) {
      if (typeof endpointKey === 'string' && endpointKey.startsWith('offline_')) {
        console.error(`[NET] Error (${context}): Attempting to ${method} with an unresolved offline key ${endpointKey}.`);
        throw new Error(`Cannot ${method} unresolved offline key ${endpointKey}`);
      } else if (endpointKey === undefined || endpointKey === null) {
        console.error(`[NET] Error (${context}): Invalid key (${endpointKey}) for ${method}.`);
        throw new Error(`Invalid key for ${method}`);
      }
    }

    const url = method === 'POST' ? `${this.API_URL}/${storeName}` : `${this.API_URL}/${storeName}/${endpointKey}`;
    const options = {
      method: method,
      headers: { 'Content-Type': 'application/json' },
    };

    let payload = { ...data };
    delete payload._pendingSync;

    if (method !== 'DELETE') {
      if (method === 'POST' && originalOfflineId) {
        delete payload.id; 
      }
      options.body = JSON.stringify(payload);
    }

    try {
      const response = await fetch(url, options);
      console.log(`[NET] Server response (${context}): ${response.status} ${response.statusText}`);

      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = `Server error (${context}): ${response.status}`;
        try {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const parsedError = JSON.parse(errorText);
            if (parsedError.message) errorMessage += ` - ${parsedError.message}`;
          } else { errorMessage += ` - Non-JSON response.`; }
        } catch (e) { /* ignore parsing error */ }
        errorMessage += ` (${method} ${url})`;
        console.error(`[NET] Server error details (${context}):`, errorText);
        throw new Error(errorMessage);
      }

      let responseData = {};
      if (response.status !== 204) {
        responseData = await response.json();
        if (storeName === 'accounts' && !responseData.code && data.code) {
          responseData.code = data.code;
        }
        else if (method === 'POST' && keyName === 'id' && !responseData.id) {
          console.warn(`[NET] Server POST response for ${storeName} missing 'id'. Response:`, responseData);
        }
        console.log(`[NET] Server response data (${context}):`, responseData);
      } else {
        responseData = { [keyName]: endpointKey }; 
        console.log(`[NET] Server DELETE successful (${context}), key: ${endpointKey}`);
      }

      const confirmedKey = responseData[keyName];

      if (confirmedKey === undefined || confirmedKey === null || (typeof confirmedKey === 'string' && confirmedKey.trim() === '')) {
        console.error(`[NET] Server response (${context}) missing or has invalid key '${keyName}'. Response:`, responseData);
        throw new Error(`Server response missing or has invalid key '${keyName}'`);
      }

      if (method === 'POST') {
        if (originalOfflineId) {
          await this.deleteLocalRecord(storeName, originalOfflineId);
          console.log(`[DB] Removed offline record ${originalOfflineId} after successful server POST for ${storeName} (New Key: ${confirmedKey})`);
        }
        await this.updateLocalRecord(storeName, responseData);
        console.log(`[DB] Updated local store for ${storeName} with server key ${confirmedKey} after POST.`);
      } else if (method === 'PUT') {
        await this.updateLocalRecord(storeName, responseData);
        console.log(`[DB] Updated local store for ${storeName} with key ${confirmedKey} after PUT.`);
      } else if (method === 'DELETE') {
        await this.deleteLocalRecord(storeName, endpointKey);
        console.log(`[DB] Removed local store record for ${storeName} with key ${endpointKey} after DELETE.`);
      }

      if (syncOpId) {
        await this.removeSyncOperation(syncOpId);
        console.log(`[SYNC] Successfully synced and removed op: ${syncOpId}`);
      }

      return responseData;
    } catch (error) {
      console.error(`[NET] Error in _sendToServerCore (${context}):`, error);
      throw error; 
    }
  }

  async sendToServer(method, storeName, data) {
    await this.ensureDB();
    const keyName = storeName === 'accounts' ? 'code' : 'id';

    if (!this.isOnline) {
      console.warn(`[SYNC] Cannot send ${method} for ${storeName}: offline. Queuing.`);
      let localData = { ...data };

      if (method === 'POST' && !localData[keyName]) {
        if (storeName === 'accounts') {
          if (!localData.code || localData.code.trim() === '') {
            console.error("[SYNC] Cannot queue 'add account' offline without a code.");
            throw new Error("Account code is required to add an account, even offline.");
          }
        } else {
          localData.id = `offline_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
          console.log(`[SYNC] Generated offline key for ${storeName}: ${localData.id}`);
        }
      }

      localData._pendingSync = true;
      const updatedLocalData = await this.updateLocalRecord(storeName, localData);
      await this.addToSyncQueue(storeName, method === 'POST' ? 'add' : (method === 'PUT' ? 'update' : 'delete'), updatedLocalData);
      return updatedLocalData;
    }

    try {
      console.log(`[NET] Attempting direct server call: ${method} ${storeName}`);
      return await this._sendToServerCore(method, storeName, data);
    } catch (error) {
      console.error(`[NET] Direct ${method} failed for ${storeName}, queuing operation:`, error);
      let localData = { ...data, _pendingSync: true };
      if (method === 'POST' && !localData[keyName]) {
        if (storeName === 'accounts') {
          if (!localData.code) { throw new Error("Account code is required."); }
        } else {
          localData.id = `offline_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
        }
      }
      const queuedData = await this.updateLocalRecord(storeName, localData);
      await this.addToSyncQueue(storeName, method === 'POST' ? 'add' : (method === 'PUT' ? 'update' : 'delete'), queuedData);
      return queuedData; 
    }
  }

  async getAll(storeName) {
    await this.ensureDB();
    let serverData = null;
    if (this.isOnline) {
        try {
            console.log(`[GET] Attempting to fetch ${storeName} from server...`);
            serverData = await this.fetchFromServer(storeName);
        } catch (fetchError) {
            console.error(`[GET] Failed server fetch for ${storeName}:`, fetchError);
        }
    } else {
        console.log(`[GET] Offline, cannot fetch ${storeName} from server.`);
    }

    if (serverData !== null) {
      console.log(`[GET] Received ${serverData.length} items for ${storeName} from server.`);
      try {
        await this.updateLocalStore(storeName, serverData);
        console.log(`[GET] Successfully updated local store ${storeName} with server data.`);
        return serverData;
      } catch (updateError) {
        console.error(`[GET] Failed to update local store ${storeName} after server fetch:`, updateError);
        console.warn(`[GET] Returning local data for ${storeName} due to update error.`);
        return this.getAllLocal(storeName);
      }
    } else {
      console.log(`[GET] Fetching ${storeName} from local DB as fallback.`);
      return this.getAllLocal(storeName);
    }
  }

  async add(storeName, data) {
    await this.ensureDB();
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    console.log(`[ADD] Starting ADD operation for ${storeName}`, data);

    if (storeName === 'accounts' && (!data.code || data.code.trim() === '')) throw new Error('Account code is required.');
    if (storeName === 'transactions' && !data.type) throw new Error('Transaction type is required.');

    const storesForTx = new Set([storeName, 'sync', 'operations']); 
    if (['sales', 'purchases', 'productions'].includes(storeName)) {
        storesForTx.add('products');
    }
    if (['income', 'expense', 'transfer', 'credit'].includes(storeName)) {
        storesForTx.add('accounts');
        if (storeName === 'credit') storesForTx.add('customers');
    }

    const tx = this.db.transaction(Array.from(storesForTx), 'readwrite');
    console.log(`[ADD] Transaction started for stores: ${Array.from(storesForTx).join(', ')}`);

    try {
        let localData = { ...data };
        if (!localData[keyName] && storeName !== 'accounts') {
            localData.id = `offline_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
            console.log(`[ADD] Generated offline key for ${storeName}: ${localData.id}`);
        }

        const addRequest = tx.objectStore(storeName).add(localData);
        await new Promise((res, rej) => { addRequest.onsuccess = res; addRequest.onerror = rej; });
        const addedKey = localData[keyName];
        console.log(`[ADD] Successfully added to local store ${storeName} (Key: ${addedKey})`);

        await this._logOperation(tx, storeName, 'add', localData, null, null); 
        await this._performStockAdjustments(tx, storeName, localData, null, 'add'); 
        await this._performFinanceAdjustments(tx, storeName, localData, null, 'add'); 

        if (!this.isOnline) {
            localData._pendingSync = true;
            await this._addToSyncQueueInternal(tx, storeName, 'add', localData);
            await tx.done;
            console.log(`[ADD] Queued offline ADD, logged, adjusted for ${storeName} (Key: ${addedKey})`);
            return localData;
        } else {
            await tx.done; 
            console.log(`[ADD] Online: Local add, log, adjustments committed for ${storeName} (Key: ${addedKey})`);

            try {
                console.log(`[ADD] Online: Sending ${storeName} (Key: ${addedKey}) to server...`);
                const serverResponse = await this._sendToServerCore('POST', storeName, localData);
                console.log(`[ADD] Online: Server POST successful for ${storeName} (Server Key: ${serverResponse[keyName]})`);
                return serverResponse; 
            } catch (serverError) {
                console.error(`[ADD] Online: Server POST failed for ${storeName} (Local Key: ${addedKey}). Re-Queuing...`, serverError);
                localData._pendingSync = true; 
                await this.addToSyncQueue(storeName, 'add', localData); 
                return localData; 
            }
        }
    } catch (error) {
        console.error(`[ADD] Transaction failed for ${storeName}:`, error);
        try { tx.abort(); console.log(`[ADD] Transaction aborted for ${storeName}`); } catch (e) { console.error("[ADD] Abort failed:", e); }
        throw error; 
    }
  }

  async update(storeName, key, data) {
    await this.ensureDB();
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const updateData = { ...data, [keyName]: key }; 

    const storesForTx = new Set([storeName, 'sync', 'operations']); 
    if (['sales', 'purchases', 'productions', 'products'].includes(storeName)) { 
        storesForTx.add('products');
    }
    if (['income', 'expense', 'transfer', 'credit'].includes(storeName)) {
        storesForTx.add('accounts');
        if (storeName === 'credit') storesForTx.add('customers');
    }

    const tx = this.db.transaction(Array.from(storesForTx), 'readwrite');
    console.log(`[UPDATE] Transaction started for stores: ${Array.from(storesForTx).join(', ')}`);

    try {
        const oldItem = await this._getLocalRecordInternal(tx, storeName, key);
        if (!oldItem) {
            console.warn(`[UPDATE] Item ${key} not found locally in ${storeName}. Aborting.`);
            try { tx.abort(); } catch (e) { console.warn("[UPDATE] Abort failed on non-existent update:", e); }
            throw new Error(`Element tapılmadı (Key: ${key})`);
        }
        console.log(`[UPDATE] Found old item for ${storeName} (Key: ${key})`, oldItem);

        const putRequest = tx.objectStore(storeName).put(updateData);
        await new Promise((res, rej) => { putRequest.onsuccess = res; putRequest.onerror = rej; });
        console.log(`[UPDATE] Successfully updated local store ${storeName} (Key: ${key})`);

        await this._logOperation(tx, storeName, 'update', updateData, oldItem, null);
        await this._performStockAdjustments(tx, storeName, updateData, oldItem, 'update');
        await this._performFinanceAdjustments(tx, storeName, updateData, oldItem, 'update');

        if (!this.isOnline) {
            updateData._pendingSync = true;
            await this._addToSyncQueueInternal(tx, storeName, 'update', updateData);
            await tx.done;
            console.log(`[UPDATE] Queued offline UPDATE, logged, adjusted for ${storeName} (Key: ${key})`);
            return updateData;
        } else {
            await tx.done; 
            console.log(`[UPDATE] Online: Local update, log, adjustments committed for ${storeName} (Key: ${key})`);

            try {
                console.log(`[UPDATE] Online: Sending ${storeName} (Key: ${key}) to server...`);
                const serverResponse = await this._sendToServerCore('PUT', storeName, updateData);
                console.log(`[UPDATE] Online: Server PUT successful for ${storeName} (Key: ${key})`);
                return serverResponse;
            } catch (serverError) {
                console.error(`[UPDATE] Online: Server PUT failed for ${storeName} (Key: ${key}). Re-Queuing...`, serverError);
                updateData._pendingSync = true;
                await this.addToSyncQueue(storeName, 'update', updateData);
                return updateData;
            }
        }
    } catch (error) {
        console.error(`[UPDATE] Transaction failed for ${storeName} (Key: ${key}):`, error);
        try { tx.abort(); console.log(`[UPDATE] Transaction aborted for ${storeName} (Key: ${key})`); } catch (e) { console.error("[UPDATE] Abort failed:", e); }
        throw error;
    }
  }

  async delete(storeName, key) {
    await this.ensureDB();
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const dataWithKey = { [keyName]: key }; 

    const storesForTx = new Set([storeName, 'sync', 'operations']); 
    if (['sales', 'purchases', 'productions'].includes(storeName)) {
        storesForTx.add('products');
    }
    if (['income', 'expense', 'transfer', 'credit'].includes(storeName)) {
        storesForTx.add('accounts');
        if (storeName === 'credit') storesForTx.add('customers');
    }

    const tx = this.db.transaction(Array.from(storesForTx), 'readwrite');
    console.log(`[DELETE] Transaction started for stores: ${Array.from(storesForTx).join(', ')}`);

    try {
        const itemToDelete = await this._getLocalRecordInternal(tx, storeName, key);
        if (!itemToDelete) {
            console.warn(`[DELETE] Item ${key} not found locally in ${storeName}. Assuming already deleted or never existed locally.`);
            try { tx.abort(); } catch (e) { /* Ignore abort error if nothing happened */ }
            if (this.isOnline) {
                console.warn(`[DELETE] Online: Attempting server DELETE for potentially non-local item ${storeName} (Key: ${key})`);
                try {
                    await this._sendToServerCore('DELETE', storeName, dataWithKey);
                    console.log(`[DELETE] Online: Server DELETE successful for potentially non-local item ${storeName} (Key: ${key})`);
                    return;
                } catch (serverError) {
                    console.error(`[DELETE] Online: Server DELETE failed for non-local item ${storeName} (Key: ${key}):`, serverError);
                    throw serverError; 
                }
            } else {
                console.log(`[DELETE] Offline: Item ${key} not found locally, nothing to queue.`);
                return; 
            }
        }
        console.log(`[DELETE] Found item to delete for ${storeName} (Key: ${key})`, itemToDelete);

        const deleteRequest = tx.objectStore(storeName).delete(key);
        await new Promise((res, rej) => { deleteRequest.onsuccess = res; deleteRequest.onerror = rej; });
        console.log(`[DELETE] Successfully deleted from local store ${storeName} (Key: ${key})`);

        await this._logOperation(tx, storeName, 'delete', null, itemToDelete, null);
        await this._performStockAdjustments(tx, storeName, null, itemToDelete, 'delete');
        await this._performFinanceAdjustments(tx, storeName, null, itemToDelete, 'delete');

        if (!this.isOnline) {
            itemToDelete._pendingSync = true; 
            await this._addToSyncQueueInternal(tx, storeName, 'delete', itemToDelete);
            await tx.done;
            console.log(`[DELETE] Queued offline DELETE, logged, adjusted for ${storeName} (Key: ${key})`);
            return;
        } else {
            await tx.done; 
            console.log(`[DELETE] Online: Local delete, log, adjustments committed for ${storeName} (Key: ${key})`);

            try {
                console.log(`[DELETE] Online: Sending DELETE for ${storeName} (Key: ${key}) to server...`);
                await this._sendToServerCore('DELETE', storeName, dataWithKey);
                console.log(`[DELETE] Online: Server DELETE successful for ${storeName} (Key: ${key})`);
                return;
            } catch (serverError) {
                console.error(`[DELETE] Online: Server DELETE failed for ${storeName} (Key: ${key}). Re-Queuing...`, serverError);
                itemToDelete._pendingSync = true; 
                await this.addToSyncQueue(storeName, 'delete', itemToDelete);
                return; 
            }
        }
    } catch (error) {
        console.error(`[DELETE] Transaction failed for ${storeName} (Key: ${key}):`, error);
        try { tx.abort(); console.log(`[DELETE] Transaction aborted for ${storeName} (Key: ${key})`); } catch (e) { console.error("[DELETE] Abort failed:", e); }
        throw error;
    }
  }

  async _performFinanceAdjustments(transaction, storeName, newData, oldData, operationKind) {
    if (!['income', 'expense', 'transfer', 'credit', 'sale', 'purchase'].includes(storeName)) {
        return;
    }
    console.log(`[Finance] Processing adjustments for ${operationKind} ${storeName}`);

    const accountsStore = transaction.objectStore('accounts');
    const customersStore = storeName === 'credit' ? transaction.objectStore('customers') : null;

    const adjustAccount = async (accountId, amountChange) => {
        if (!accountId || isNaN(amountChange) || amountChange === 0) return;
        console.log(`[Finance] Adjusting account ${accountId} by ${amountChange}`);
        const getReq = accountsStore.get(accountId);
        return new Promise((resolve, reject) => {
            getReq.onsuccess = () => {
                const account = getReq.result;
                if (!account) {
                    console.error(`[Finance] Account ${accountId} not found for adjustment.`);
                    resolve(); return;
                }
                const oldBalance = parseFloat(account.balance) || 0;
                account.balance = oldBalance + amountChange;
                const putReq = accountsStore.put(account);
                putReq.onsuccess = resolve;
                putReq.onerror = (e) => { console.error(`[Finance] Error updating account ${accountId}:`, e.target.error); resolve(); }; 
            };
            getReq.onerror = (e) => { console.error(`[Finance] Error fetching account ${accountId}:`, e.target.error); resolve(); };
        });
    };

    const adjustCustomerDebt = async (customerId, amountChange) => {
        if (!customersStore || !customerId || isNaN(amountChange) || amountChange === 0) return;
        console.log(`[Finance] Adjusting customer ${customerId} debt by ${amountChange}`);
        const getReq = customersStore.get(customerId);
        return new Promise((resolve, reject) => {
            getReq.onsuccess = () => {
                const customer = getReq.result;
                if (!customer) { console.error(`[Finance] Customer ${customerId} not found for debt adjustment.`); resolve(); return; }
                const oldDebt = parseFloat(customer.debt) || 0;
                customer.debt = oldDebt + amountChange;
                const putReq = customersStore.put(customer);
                putReq.onsuccess = resolve;
                putReq.onerror = (e) => { console.error(`[Finance] Error updating customer ${customerId} debt:`, e.target.error); resolve(); };
            };
            getReq.onerror = (e) => { console.error(`[Finance] Error fetching customer ${customerId}:`, e.target.error); resolve(); };
        });
    };

    let adjustments = [];

    if (operationKind === 'add') {
        if (storeName === 'income') adjustments.push({ accountId: newData.accountId, change: parseFloat(newData.amount) });
        if (storeName === 'expense') adjustments.push({ accountId: newData.accountId, change: -parseFloat(newData.amount) });
        if (storeName === 'transfer') {
            adjustments.push({ accountId: newData.fromAccountId, change: -parseFloat(newData.amount) });
            adjustments.push({ accountId: newData.toAccountId, change: parseFloat(newData.amount) });
        }
        if (storeName === 'credit') {
            adjustments.push({ accountId: newData.accountId, change: parseFloat(newData.amount) });
            adjustments.push({ customerId: newData.customerId, debtChange: -parseFloat(newData.amount) });
        }
    } else if (operationKind === 'delete') {
        if (storeName === 'income') adjustments.push({ accountId: oldData.accountId, change: -parseFloat(oldData.amount) });
        if (storeName === 'expense') adjustments.push({ accountId: oldData.accountId, change: parseFloat(oldData.amount) });
        if (storeName === 'transfer') {
            adjustments.push({ accountId: oldData.fromAccountId, change: parseFloat(oldData.amount) });
            adjustments.push({ accountId: oldData.toAccountId, change: -parseFloat(oldData.amount) });
        }
        if (storeName === 'credit') {
            adjustments.push({ accountId: oldData.accountId, change: -parseFloat(oldData.amount) });
            adjustments.push({ customerId: oldData.customerId, debtChange: parseFloat(oldData.amount) });
        }
    } else if (operationKind === 'update') {
        if (storeName === 'income') adjustments.push({ accountId: oldData.accountId, change: -parseFloat(oldData.amount) });
        if (storeName === 'expense') adjustments.push({ accountId: oldData.accountId, change: parseFloat(oldData.amount) });
        if (storeName === 'transfer') {
            adjustments.push({ accountId: oldData.fromAccountId, change: parseFloat(oldData.amount) });
            adjustments.push({ accountId: oldData.toAccountId, change: -parseFloat(oldData.amount) });
        }
        if (storeName === 'credit') {
            adjustments.push({ accountId: oldData.accountId, change: -parseFloat(oldData.amount) });
            adjustments.push({ customerId: oldData.customerId, debtChange: parseFloat(oldData.amount) });
        }
        if (storeName === 'income') adjustments.push({ accountId: newData.accountId, change: parseFloat(newData.amount) });
        if (storeName === 'expense') adjustments.push({ accountId: newData.accountId, change: -parseFloat(newData.amount) });
        if (storeName === 'transfer') {
            adjustments.push({ accountId: newData.fromAccountId, change: -parseFloat(newData.amount) });
            adjustments.push({ accountId: newData.toAccountId, change: parseFloat(newData.amount) });
        }
        if (storeName === 'credit') {
            adjustments.push({ accountId: newData.accountId, change: parseFloat(newData.amount) });
            adjustments.push({ customerId: newData.customerId, debtChange: -parseFloat(newData.amount) });
        }
    }

    if (adjustments.length > 0) {
        console.log(`[Finance] Performing ${adjustments.length} finance adjustments.`);
        const adjustmentPromises = adjustments.map(adj =>
             adj.accountId ? adjustAccount(adj.accountId, adj.change)
            : adj.customerId ? adjustCustomerDebt(adj.customerId, adj.debtChange)
            : Promise.resolve()
         );
         await Promise.all(adjustmentPromises);
    }
  }

  async _logOperation(transaction, storeName, operationKind, newData, oldData = null, userId = null) {
    const operationsStore = transaction.objectStore('operations');
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const referenceId = newData?.[keyName] ?? oldData?.[keyName];
    const referenceType = storeName.replace(/s$/, ''); 
    const operationType = `${referenceType}_${operationKind}`;

    let description = `${operationType}: `;
    let details = '';
    if (storeName === 'categories' || storeName === 'accounts') {
      details = newData?.name ?? oldData?.name ?? referenceId;
    } else if (storeName === 'users') {
      details = newData?.fullName ?? oldData?.fullName ?? referenceId;
    } else if (storeName === 'sales' || storeName === 'purchases') {
      details = `Kod ${newData?.code ?? oldData?.code ?? referenceId}`;
    } else if (storeName === 'transactions') {
      details = `${newData?.type ?? oldData?.type} (${newData?.amount ?? oldData?.amount})`;
    }
    else {
      details = referenceId; 
    }
    description += details;

    if (operationKind === 'update' && oldData && newData) {
      const changes = [];
      for (const key in newData) {
        if (key !== '_pendingSync' && key !== keyName && !key.startsWith('_') && JSON.stringify(newData[key]) !== JSON.stringify(oldData[key])) {
          const oldValueStr = typeof oldData[key] === 'object' ? '[Object]' : String(oldData[key]);
          const newValueStr = typeof newData[key] === 'object' ? '[Object]' : String(newData[key]);
          if (changes.length < 3) { 
            changes.push(`${key}: ${oldValueStr.substring(0, 20)} -> ${newValueStr.substring(0, 20)}`);
          } else if (changes.length === 3) {
            changes.push('...');
          }
        }
      }
      if (changes.length > 0) {
        description += ` (Dəyişiklik: ${changes.join(', ')})`;
      } else {
        description += ' (Məlumat dəyişikliyi yoxdur)';
      }
    }

    const operationId = `op_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    const logEntry = {
      id: operationId,
      type: operationType,
      date: new Date().toISOString(),
      description: description.substring(0, 255), 
      referenceId: referenceId,
      referenceType: referenceType,
      userId: userId || null, 
      userName: null 
    };

    if (storeName === 'accounts') logEntry.accountName = newData?.name ?? oldData?.name;
    if (storeName === 'categories') logEntry.categoryName = newData?.name ?? oldData?.name;
    if (storeName === 'products') logEntry.productName = newData?.name ?? oldData?.name;
    if (storeName === 'sales') logEntry.customerId = newData?.customerId ?? oldData?.customerId;
    if (storeName === 'purchases') logEntry.supplierId = newData?.supplierId ?? oldData?.supplierId;
    if (storeName === 'transactions') logEntry.amount = newData?.amount ?? oldData?.amount;

    return new Promise((resolve, reject) => {
      const logRequest = operationsStore.add(logEntry);
      logRequest.onerror = (e) => {
        console.error(`[OpLog] Error adding operation log for ${operationType} on ${storeName} (Ref: ${referenceId}):`, e.target.error);
        resolve(); 
      };
      logRequest.onsuccess = () => {
        console.log(`[OpLog] Operation logged: ${operationType} on ${storeName} (Ref: ${referenceId})`);
        resolve();
      };
    });
  }

  async getAllLocal(storeName) {
    await this.ensureDB();
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction(storeName, 'readonly');
        const store = transaction.objectStore(storeName);
        const request = store.getAll();
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = (e) => {
          console.error(`[DB] Error getting all local ${storeName}:`, e.target.error);
          reject(e.target.error);
        };
      } catch (error) {
        console.error(`[DB] Error in getAllLocal for ${storeName}:`, error);
        if (transaction?.abort) { 
          try { transaction.abort(); } catch (abortError) { console.error("[DB] Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async updateLocalRecord(storeName, data) {
    await this.ensureDB();
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const keyName = store.keyPath;

        if (!data || !data.hasOwnProperty(keyName) || data[keyName] === null || data[keyName] === undefined || (typeof data[keyName] === 'string' && data[keyName].trim() === '')) {
          console.error(`[DB] Attempted to update local record in ${storeName} without valid key '${keyName}':`, data);
          return reject(new Error(`Missing or invalid key '${keyName}' for store ${storeName}`));
        }
        const dataToStore = JSON.parse(JSON.stringify(data));
        const request = store.put(dataToStore);

        request.onsuccess = () => {
            console.log(`[DB] Successfully updated local record in ${storeName} (Key: ${data[keyName]})`);
            resolve(dataToStore); 
        }
        request.onerror = (e) => {
          console.error(`[DB] Error updating local record in ${storeName} (key: ${data[keyName]}):`, e.target.error, dataToStore);
          reject(e.target.error);
        };
      } catch (error) {
        console.error(`[DB] Error in updateLocalRecord transaction for ${storeName}:`, error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("[DB] Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async deleteLocalRecord(storeName, key) {
    await this.ensureDB();
    if (key === null || key === undefined || (typeof key === 'string' && key.trim() === '')) {
      console.error(`[DB] Attempted to delete local record in ${storeName} with invalid key:`, key);
      return Promise.reject(new Error(`Invalid key provided for deletion in ${storeName}`));
    }
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.delete(key);
        request.onsuccess = () => {
            console.log(`[DB] Successfully deleted local record ${key} from ${storeName}`);
            resolve();
        }
        request.onerror = (e) => {
          console.error(`[DB] Error deleting local record ${key} from ${storeName}:`, e.target.error);
          reject(e.target.error);
        };
      } catch (error) {
        console.error(`[DB] Error in deleteLocalRecord transaction for ${storeName}:`, error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("[DB] Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async updateLocalStore(storeName, items) {
    await this.ensureDB();
    console.log(`[DB] Updating local store ${storeName} with ${items?.length ?? 0} items.`);
    return new Promise((resolve, reject) => {
      if (!Array.isArray(items)) {
        console.error(`[DB] updateLocalStore expected an array for ${storeName}, got:`, typeof items);
        return reject(new Error(`Invalid data format for ${storeName}`));
      }
      let transaction;
      try {
        transaction = this.db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const keyName = store.keyPath;
        let processedCount = 0;
        let errorCount = 0;
        const totalItems = items.length;

        const clearRequest = store.clear();
        clearRequest.onerror = (e) => {
          console.error(`[DB] Error clearing ${storeName} before update:`, e.target.error);
          if (transaction?.abort) transaction.abort(); 
          reject(e.target.error);
        };

        clearRequest.onsuccess = () => {
          console.log(`[DB] Store ${storeName} cleared.`);
          if (totalItems === 0) {
            console.log(`[DB] No items to add to ${storeName}.`);
            resolve(); 
            return;
          }

          const addPromises = items.map(item => {
            return new Promise((itemResolve, itemReject) => {
                const itemKey = item ? item[keyName] : undefined;
                if (item === null || itemKey === undefined || itemKey === null || (typeof itemKey === 'string' && itemKey.trim() === '')) {
                    console.warn(`[DB] Item in ${storeName} missing or has invalid key '${keyName}', skipping:`, item);
                    errorCount++; 
                    itemResolve(); 
                    return;
                }
                try {
                    const itemToAdd = JSON.parse(JSON.stringify(item));
                    const addRequest = store.add(itemToAdd);
                    addRequest.onsuccess = () => { processedCount++; itemResolve(); };
                    addRequest.onerror = (e) => {
                        errorCount++;
                        console.error(`[DB] Error adding item to ${storeName} during updateLocalStore (key: ${itemKey}):`, e.target.error);
                        itemResolve(); 
                    };
                } catch (addError) {
                    errorCount++;
                    console.error(`[DB] Error calling store.add for item in ${storeName} (key: ${itemKey}):`, addError, item);
                    itemResolve(); 
                }
            });
          });

          Promise.all(addPromises).then(() => {
            console.log(`[DB] Finished adding items to ${storeName}. Added: ${totalItems - errorCount}, Errors: ${errorCount}`);
            resolve();
          }).catch(finalError => {
            console.error(`[DB] Unexpected error during Promise.all in updateLocalStore for ${storeName}:`, finalError);
            reject(finalError);
          });
        };

        transaction.oncomplete = () => {
            console.log(`[DB] Transaction complete for updateLocalStore ${storeName}.`);
        };
        transaction.onerror = (e) => {
          console.error(`[DB] Transaction error during updateLocalStore for ${storeName}:`, e.target.error);
          reject(e.target.error);
        };

      } catch (error) {
        console.error(`[DB] Error initiating updateLocalStore transaction for ${storeName}:`, error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("[DB] Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async addToSyncQueue(storeName, operation, data) {
    await this.ensureDB();
    const syncOpId = `sync_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    const keyName = storeName === 'accounts' ? 'code' : 'id';
    const dataKey = data[keyName]; 

    if (dataKey === undefined || dataKey === null || (typeof dataKey === 'string' && dataKey.trim() === '')) {
      console.error(`[SYNC] Cannot add to sync queue: Missing or invalid key '${keyName}' in data for ${storeName}`, data);
      throw new Error(`Missing or invalid key '${keyName}' for sync operation.`);
    }

    const syncItem = {
      id: syncOpId, 
      storeName,
      operation, 
      dataKey: dataKey, 
      data: JSON.parse(JSON.stringify(data)), 
      timestamp: Date.now()
    };

    console.log(`[SYNC] Adding to queue: ${operation} on ${storeName} (Data Key: ${dataKey}, Sync ID: ${syncOpId})`);
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction('sync', 'readwrite');
        const store = transaction.objectStore('sync');
        const request = store.add(syncItem);
        request.onsuccess = () => {
          console.log(`[SYNC] Successfully added to queue: ${syncOpId}`);
          resolve(syncItem);
        };
        request.onerror = (e) => {
          console.error('[SYNC] Error adding to sync queue:', e.target.error, syncItem);
          reject(e.target.error);
        };
      } catch (error) {
        console.error('[SYNC] Error in addToSyncQueue:', error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("[SYNC] Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async syncWithServer() {
    await this.ensureDB();
    if (!this.isOnline) {
      console.log('[SYNC] Sync deferred: offline.');
      return;
    }

    console.log('[SYNC] Attempting sync with server...');

    let syncReadTx; 
    try {
      syncReadTx = this.db.transaction('sync', 'readonly'); 
      const store = syncReadTx.objectStore('sync');
      const request = store.getAll();

      request.onerror = (e) => console.error('[SYNC] Error fetching sync queue:', e.target.error);
      request.onsuccess = async () => {
        const pendingOperations = request.result;
        if (pendingOperations.length === 0) {
          console.log('[SYNC] Sync queue is empty.');
          console.log("[SYNC] Triggering data refresh after empty sync queue.");
          window.dispatchEvent(new CustomEvent('request-data-refresh'));
          return;
        }
        console.log(`[SYNC] Processing ${pendingOperations.length} pending operations...`);
        pendingOperations.sort((a, b) => a.timestamp - b.timestamp); 

        let failedOps = 0;
        for (const op of pendingOperations) {
          if (!navigator.onLine) {
            console.log("[SYNC] Went offline during sync processing. Stopping.");
            break; 
          }
          try {
            console.log(`[SYNC] Syncing: ${op.operation} on ${op.storeName} (Data Key: ${op.dataKey}, Sync ID: ${op.id})`);
            const method = op.operation === 'add' ? 'POST' : (op.operation === 'update' ? 'PUT' : 'DELETE');
            await this._sendToServerCore(method, op.storeName, op.data, op.id);
          } catch (error) {
            failedOps++;
            console.error(`[SYNC] Failed to sync operation ${op.id}:`, error);
          }
        }
        console.log(`[SYNC] Sync processing finished. Total: ${pendingOperations.length}, Failed: ${failedOps}`);
        if (pendingOperations.length > 0) {
           console.log("[SYNC] Triggering data refresh after sync processing.");
           window.dispatchEvent(new CustomEvent('request-data-refresh'));
        }
      };
      await syncReadTx.done; 

    } catch (error) {
      console.error('[SYNC] Error during sync process initiation:', error);
      if (syncReadTx?.abort) {
        try { syncReadTx.abort(); } catch (abortError) { console.error("[SYNC] Error aborting sync read transaction:", abortError); }
      }
    }
  }

  async removeSyncOperation(syncOpId) {
    await this.ensureDB();
    console.log(`[SYNC] Removing sync operation: ${syncOpId}`);
    return new Promise((resolve, reject) => {
      let transaction;
      try {
        transaction = this.db.transaction('sync', 'readwrite');
        const store = transaction.objectStore('sync');
        const request = store.delete(syncOpId);
        request.onsuccess = () => {
             console.log(`[SYNC] Successfully removed sync op: ${syncOpId}`);
             resolve();
        }
        request.onerror = (e) => {
          console.error(`[SYNC] Error removing sync operation ${syncOpId}:`, e.target.error);
          reject(e.target.error);
        };
      } catch (error) {
        console.error('[SYNC] Error in removeSyncOperation:', error);
        if (transaction?.abort) {
          try { transaction.abort(); } catch (abortError) { console.error("[SYNC] Error aborting transaction:", abortError); }
        }
        reject(error);
      }
    });
  }

  async getSettings() {
    try {
      await this.ensureDB();
      let settings = {};
      console.log("[Settings] Getting settings from IndexedDB...");
      const tx = this.db.transaction('settings', 'readonly');
      const store = tx.objectStore('settings');
      const request = store.getAll();

      const allSettings = await new Promise((res, rej) => {
        request.onsuccess = () => res(request.result);
        request.onerror = (e) => rej(e.target.error);
      });

      if (allSettings.length > 0) {
        allSettings.forEach(s => settings[s.category] = s.data);
        console.log("[Settings] Settings loaded from IndexedDB:", Object.keys(settings));
      }
      else {
        console.log("[Settings] No settings in IndexedDB, using defaults.");
        settings = {
          general: { companyName: "Anbar Sistemi", currency: "AZN" },
          invoices: { invoicePrefix: "INV-", showLogo: true },
          taxes: { enabledTaxes: [], rates: { vat: 18 }, automation: {}, declarations: {}, deadlines: {}, integrations: {} },
          accounts: { defaultMappings: {} },
          email: {}
        };
        try {
          await this.saveAllSettingsToDB(settings); 
          console.log("[Settings] Saved default settings to IndexedDB.");
        } catch (dbSaveError) {
          console.error("[Settings] Failed to save default settings to IndexedDB:", dbSaveError);
        }
      }

      const defaultTaxes = { enabledTaxes: [], rates: { vat: 18 }, automation: {}, declarations: {}, deadlines: {}, integrations: {} };
      const defaultAccounts = { defaultMappings: {} };
      const defaultGeneral = { companyName: "Anbar Sistemi", currency: "AZN" };
      const defaultInvoices = { invoicePrefix: "INV-", showLogo: true };
      const defaultEmail = {};
      const categories = ['general', 'invoices', 'taxes', 'backup', 'appearance', 'accounts', 'email'];

      categories.forEach(cat => {
        if (!settings[cat]) {
          settings[cat] = cat === 'accounts' ? { ...defaultAccounts }
                        : cat === 'email' ? { ...defaultEmail }
                        : cat === 'general' ? { ...defaultGeneral }
                        : cat === 'invoices' ? { ...defaultInvoices }
                        : {};
          console.log(`[Settings] Applied default structure for missing category: ${cat}`);
        }
        if (cat === 'taxes') {
          settings.taxes = settings.taxes || {};
          settings.taxes.rates = { ...defaultTaxes.rates, ...(settings.taxes.rates || {}) };
          settings.taxes.automation = { ...defaultTaxes.automation, ...(settings.taxes.automation || {}) };
          settings.taxes.declarations = { ...defaultTaxes.declarations, ...(settings.taxes.declarations || {}) };
          settings.taxes.deadlines = { ...defaultTaxes.deadlines, ...(settings.taxes.deadlines || {}) };
          settings.taxes.integrations = { ...defaultTaxes.integrations, ...(settings.taxes.integrations || {}) };
        }
        if (cat === 'accounts') {
          settings.accounts = settings.accounts || {};
          settings.accounts.defaultMappings = { ...defaultAccounts.defaultMappings, ...(settings.accounts.defaultMappings || {}) };
        }
      });

      return settings;
    } catch (error) {
      console.error('[Settings] Critical error getting settings:', error);
      return { 
        general: { companyName: "Anbar Sistemi", currency: "AZN" },
        invoices: { invoicePrefix: "INV-", showLogo: true },
        taxes: { enabledTaxes: [], rates: { vat: 18 } },
        accounts: { defaultMappings: {} },
        email: {}
      };
    }
  }

  async saveAllSettingsToDB(settings) {
    await this.ensureDB();
    console.log("[Settings] Saving all settings categories to IndexedDB...");
    const tx = this.db.transaction('settings', 'readwrite');
    const store = tx.objectStore('settings');
    const promises = Object.entries(settings).map(([category, data]) => {
      const dataToStore = data === undefined ? {} : data;
      return new Promise((resolve, reject) => {
        const req = store.put({ category: category, data: dataToStore });
        req.onsuccess = resolve;
        req.onerror = reject;
      });
    });
    try {
        await Promise.all(promises);
        await tx.done;
        console.log("[Settings] All settings categories saved to IndexedDB.");
    } catch(error) {
         console.error("[Settings] Error saving all settings categories to DB:", error);
         if (tx.abort) tx.abort();
         throw error;
    }
  }

  async saveSettings(category, data) {
    await this.ensureDB();
    console.log(`[Settings] Saving settings for category: ${category}`, data);
    try {
      const dataToStore = data === undefined || data === null ? {} : JSON.parse(JSON.stringify(data));

      if (!category || typeof category !== 'string') {
        throw new Error('Invalid settings category');
      }

      const tx = this.db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');

      await new Promise((resolve, reject) => {
        const request = store.put({ category: category, data: dataToStore });
        request.onsuccess = resolve;
        request.onerror = (e) => {
            console.error(`[DB] Error putting settings for ${category}:`, e.target.error);
            reject(e.target.error);
        };
      });
      await tx.done; 

      console.log(`[Settings] Settings saved locally (IndexedDB) for category: ${category}`);

      try { localStorage.setItem(`settings_${category}`, JSON.stringify(dataToStore)); }
      catch (localStorageError) { console.warn('[Settings] Could not save settings to localStorage:', localStorageError); }

      if (this.isOnline) {
        try {
          console.log(`[Settings] Attempting to save settings ${category} to server...`);
          await this.saveSettingsToServer(category, dataToStore);
          console.log(`[Settings] Successfully saved settings ${category} to server.`);
        } catch (serverError) {
          console.warn(`[Settings] Failed to save settings ${category} to server immediately:`, serverError);
        }
      }
      return true; 
    } catch (error) {
      console.error(`[Settings] Comprehensive error saving settings for ${category}:`, error);
      try {
        localStorage.setItem(`settings_${category}`, JSON.stringify(data || {}));
        console.log(`[Settings] Fallback: Settings saved to localStorage for ${category}`);
        return true; 
      } catch (localStorageError) {
        console.error('[Settings] Failed to save settings to localStorage:', localStorageError);
        return false; 
      }
    }
  }

  async fetchSettingsFromServer() {
    if (!this.isOnline) {
      console.log("[Settings] Offline, cannot fetch settings from server.");
      return null;
    }
    const url = `${this.API_URL}/settings?t=${Date.now()}`;
    console.log(`[Settings] Fetching settings from server: ${url}`);
    try {
      const response = await fetch(url);
      if (!response.ok) {
        console.error(`[Settings] Server error fetching settings: ${response.status}`);
        return null;
      }
      const data = await response.json();
      console.log("[Settings] Successfully fetched settings from server:", data);
      return data;
    } catch (error) {
      console.error('[Settings] Error fetching settings from server:', error);
      return null;
    }
  }

  async saveSettingsToServer(category, data) {
    if (!this.isOnline) {
      console.warn(`[Settings] Offline, cannot save settings ${category} to server.`);
      return; 
    }
    const url = `${this.API_URL}/settings`;
    console.log(`[Settings] Saving settings ${category} to server: ${url}`);
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category, settings: data })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`[Settings] Server error saving settings for ${category}: ${response.status}`, errorText);
        throw new Error(`Server error saving settings: ${response.status}`);
      }
      console.log(`[Settings] Settings for category ${category} saved to server.`);
    } catch (error) {
      console.error(`[Settings] Error saving settings to server for ${category}:`, error);
      throw error; 
    }
  }
}

const dbService = new DatabaseService();
export default dbService;