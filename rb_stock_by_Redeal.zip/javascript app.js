import { createApp } from 'vue';
import { config, getIconSvg } from './config.js';
import { registerComponents } from './components/index.js';
import dbService from './database.js';

// Simple counter for unique notification IDs
let notificationIdCounter = 0;

const app = createApp({
  data() {
    return {
      activeTab: 'dashboard',
      showMobileMenu: false,
      menuItems: config.menuItems,
      products: [],
      categories: [],
      customers: [],
      suppliers: [],
      users: [],
      sales: [],
      purchases: [],
      operations: [],
      productions: [],
      accounts: [],
      incomeTransactions: [],
      expenseTransactions: [],
      transfers: [],
      credits: [],
      activeModal: null,
      modalData: null,
      isLoading: true,
      notifications: [],
      showQuickMenu: false,
      settings: {
        general: { companyName: "Anbar Sistemi", currency: "AZN" },
        invoices: { invoicePrefix: "INV-", showLogo: true },
        taxes: {
          enabledTaxes: [],
          rates: { vat: 18, income_tax: 20, simplified_turnover: 2, simplified_profit: 10, social_employer: 22, social_employee: 3, property: 0.5 },
          automation: { generateReports: false, calculateLiabilities: false, createInvoices: false },
          declarations: { vatFrequency: 'monthly', incomeFrequency: 'quarterly' },
          deadlines: { vat: 15, income: 20 },
          integrations: { statePortal: false, bank: false }
        },
        backup: {},
        appearance: {},
        accounts: { defaultMappings: {} },
        email: {}
      },
      dialog: {
        show: false,
        title: '',
        message: '',
        confirmText: 'Bəli',
        cancelText: 'Xeyr',
        confirmButtonClass: 'btn-danger',
        onConfirm: null,
        onCancel: null
      },
      isOnline: navigator.onLine,
      isAuthenticated: true,
      currentUser: null,
      initialLoadNotificationShown: false // Flag to track if initial load notification was shown
    };
  },
  created() {
    this.loadUserFromStorage();
  },
  computed: {
    currentTabComponent() {
      const componentName = `${this.activeTab}-tab`;
      if (this.menuItems.some(item => item.id === this.activeTab)) {
         return componentName;
      }
      console.warn(`Computed property 'currentTabComponent' could not find component for tab: ${this.activeTab}. Defaulting to dashboard.`);
      this.activeTab = 'dashboard'; 
      return 'dashboard-tab';
    },
    cashAccounts() {
      return Array.isArray(this.accounts)
        ? this.accounts.filter(acc => ['cash', 'bank', 'card'].includes(acc.type))
        : [];
    },
    fabMenuItems() {
        return this.getFabMenuItems(this.activeTab);
    }
  },
  methods: {
    getIconSvg,

    handleApiError(error, context = 'operation') {
       console.error(`API Error during ${context}:`, error);
       const errorMessage = error.message || 'Naməlum server xətası';
       if (!this.notifications.some(n => n.message.includes(errorMessage))) {
           this.showNotification('error', 'Server Xətası', `Əməliyyat zamanı xəta baş verdi: ${errorMessage}`);
       }
       this.isLoading = false;
    },

    async loadAllData(isInitialLoad = false) { 
        console.log(`Loading all data (settings first) - Initial: ${isInitialLoad}`);
        this.isLoading = true;
        try {
            await this.loadSettings();

            const fetchPromises = [
                dbService.getAll('products').then(data => this.products = data || []),
                dbService.getAll('categories').then(data => this.categories = data || []),
                dbService.getAll('customers').then(data => this.customers = data || []),
                dbService.getAll('suppliers').then(data => this.suppliers = data || []),
                dbService.getAll('sales').then(data => this.sales = data || []),
                dbService.getAll('purchases').then(data => this.purchases = data || []),
                dbService.getAll('operations').then(data => this.operations = data || []),
                dbService.getAll('productions').then(data => this.productions = data || []),
                dbService.getAll('accounts').then(data => this.accounts = data || []),
                dbService.getAll('transactions').then(data => this.processTransactions(data || [])),
                dbService.getAll('users').then(data => this.users = data || []),
            ];
            await Promise.all(fetchPromises);
            console.log('All data loaded after settings.');

            if (isInitialLoad && this.isOnline && !this.initialLoadNotificationShown) {
                 this.showNotification('info', 'Məlumatlar Yükləndi', 'Sistem hazır.', 3000);
                 this.initialLoadNotificationShown = true; 
            }
        } catch (error) {
            console.error("Failed to load all data:", error);
            this.showNotification('error', 'Yükləmə Xətası', 'Serverdən məlumatlar yüklənə bilmədi.');
            if (dbService.db) {
                 await this.loadAllDataLocalFallback(isInitialLoad); 
             } else {
                  this.showNotification('error', 'Kritik Xəta', 'Verilənlər bazası mövcud deyil. Lokal məlumatlar yüklənə bilmir.');
             }
        } finally {
            this.isLoading = false;
        }
    },

     processTransactions(allTransactions) {
         this.incomeTransactions = Array.isArray(allTransactions) ? allTransactions.filter(t => t.type === 'income') : [];
         this.expenseTransactions = Array.isArray(allTransactions) ? allTransactions.filter(t => t.type === 'expense') : [];
         this.transfers = Array.isArray(allTransactions) ? allTransactions.filter(t => t.type === 'transfer') : [];
         this.credits = Array.isArray(allTransactions) ? allTransactions.filter(t => t.type === 'credit') : [];
         console.log(`Processed ${allTransactions?.length || 0} transactions into categories.`);
     },

    async loadAllDataLocalFallback(isInitialLoad = false) { 
        console.log(`Loading data from local DB as fallback - Initial: ${isInitialLoad}`);
        try {
            await this.loadSettings();
            const fetchPromises = [
                 dbService.getAllLocal('products').then(data => this.products = data || []),
                 dbService.getAllLocal('categories').then(data => this.categories = data || []),
                 dbService.getAllLocal('customers').then(data => this.customers = data || []),
                 dbService.getAllLocal('suppliers').then(data => this.suppliers = data || []),
                 dbService.getAllLocal('sales').then(data => this.sales = data || []),
                 dbService.getAllLocal('purchases').then(data => this.purchases = data || []),
                 dbService.getAllLocal('operations').then(data => this.operations = data || []),
                 dbService.getAllLocal('productions').then(data => this.productions = data || []),
                 dbService.getAllLocal('accounts').then(data => this.accounts = data || []),
                 dbService.getAllLocal('transactions').then(data => this.processTransactions(data || [])),
                 dbService.getAllLocal('users').then(data => this.users = data || []),
             ];
             await Promise.all(fetchPromises);
             console.log('Local fallback data loaded after settings.');

             if (isInitialLoad && !this.initialLoadNotificationShown) {
                 this.showNotification('warning', 'Lokal Məlumat', 'Serverə qoşulma mümkün olmadı, lokal məlumatlar göstərilir.', 4000);
                  this.initialLoadNotificationShown = true; 
             }
        } catch (error) {
             console.error("Failed to load local fallback data:", error);
             this.showNotification('error', 'Kritik Xəta', 'Lokal məlumatları yükləmək mümkün olmadı.');
        }
    },

    async loadSettings() {
       try {
         const localSettings = await dbService.getSettings();
         const defaultTaxes = { enabledTaxes: [], rates: { vat: 18, income_tax: 20, simplified_turnover: 2, simplified_profit: 10, social_employer: 22, social_employee: 3, property: 0.5 }, automation: {}, declarations: {}, deadlines: {}, integrations: {} };
         const defaultAccounts = { defaultMappings: {} };

         this.settings = {
            general: { ...(localSettings.general || {}) },
            invoices: { ...(localSettings.invoices || {}) },
            taxes: { ...defaultTaxes, ...(localSettings.taxes || {}) },
            backup: { ...(localSettings.backup || {}) },
            appearance: { ...(localSettings.appearance || {}) },
            accounts: { ...defaultAccounts, ...(localSettings.accounts || {}) }
         };
         this.settings.taxes.rates = { ...defaultTaxes.rates, ...(this.settings.taxes.rates || {}) };
        this.settings.taxes.automation = { ...defaultTaxes.automation, ...(this.settings.taxes.automation || {}) };
        this.settings.taxes.declarations = { ...defaultTaxes.declarations, ...(this.settings.taxes.declarations || {}) };
        this.settings.taxes.deadlines = { ...defaultTaxes.deadlines, ...(this.settings.taxes.deadlines || {}) };
        this.settings.taxes.integrations = { ...defaultTaxes.integrations, ...(this.settings.taxes.integrations || {}) };
        this.settings.accounts.defaultMappings = { ...defaultAccounts.defaultMappings, ...(this.settings.accounts.defaultMappings || {}) };

         if (dbService.isOnline) {
           const serverSettings = await dbService.fetchSettingsFromServer();
           if (serverSettings) {
              console.log("Merging server settings:", serverSettings);
              this.settings.general = { ...this.settings.general, ...(serverSettings.general || {}) };
              this.settings.invoices = { ...this.settings.invoices, ...(serverSettings.invoices || {}) };
              this.settings.taxes = {
                   ...this.settings.taxes, 
                   ...(serverSettings.taxes || {}), 
                   rates: { ...this.settings.taxes.rates, ...(serverSettings.taxes?.rates || {}) }, 
                   automation: { ...this.settings.taxes.automation, ...(serverSettings.taxes?.automation || {}) },
                   declarations: { ...this.settings.taxes.declarations, ...(serverSettings.taxes?.declarations || {}) },
                   deadlines: { ...this.settings.taxes.deadlines, ...(serverSettings.taxes?.deadlines || {}) },
                   integrations: { ...this.settings.taxes.integrations, ...(serverSettings.taxes?.integrations || {}) },
               };
              this.settings.accounts = {
                   ...this.settings.accounts,
                   ...(serverSettings.accounts || {}),
                   defaultMappings: { ...this.settings.accounts.defaultMappings, ...(serverSettings.accounts?.defaultMappings || {}) }
              };

              for (const category in this.settings) {
                 if (this.settings.hasOwnProperty(category)) {
                     await dbService.saveSettings(category, this.settings[category]);
                 }
              }
           } else {
               console.log("No settings received from server or failed fetch.");
           }
         }
         console.log('Settings loaded/merged:', this.settings);
        } catch (error) {
           console.error('Error loading settings:', error);
           this.settings = this.settings || {};
           if (!this.settings.general) this.settings.general = {};
           if (!this.settings.invoices) this.settings.invoices = {};
           if (!this.settings.taxes) this.settings.taxes = { enabledTaxes: [], rates: {}, automation: {}, declarations: {}, deadlines: {}, integrations: {} };
           if (!this.settings.accounts) this.settings.accounts = { defaultMappings: {} };
        }
     },

     async handleSettingsUpdated({ section, data }) {
       console.log(`Handling settings update for section: ${section}`, data);
       if (!this.settings[section]) this.settings[section] = {};

        // Deep merge for nested structures like taxes and accounts
       if (section === 'taxes') {
         data.rates = { ...this.settings.taxes.rates, ...(data.rates || {}) };
         data.automation = { ...this.settings.taxes.automation, ...(data.automation || {}) };
         data.declarations = { ...this.settings.taxes.declarations, ...(data.declarations || {}) };
         data.deadlines = { ...this.settings.taxes.deadlines, ...(data.deadlines || {}) };
         data.integrations = { ...this.settings.taxes.integrations, ...(data.integrations || {}) };
       }
        if (section === 'accounts' && data.defaultMappings) {
           data.defaultMappings = { ...this.settings.accounts.defaultMappings, ...data.defaultMappings };
        }

       this.settings[section] = { ...this.settings[section], ...data }; 

       // Save locally first
       const localSaveSuccess = await dbService.saveSettings(section, this.settings[section]);

       // If local save succeeds, try saving to server
       if (localSaveSuccess) {
           try {
               await dbService.saveSettingsToServer(section, this.settings[section]);
               this.showNotification('success', 'Parametrlər saxlanıldı', `${this.getSectionLabel(section)} parametrləri uğurla saxlanıldı`);
           } catch(error) {
                // Handle server save error (show warning)
                console.error(`Error saving ${section} settings to server:`, error);
                this.showNotification('warning', 'Lokal Saxlanıldı', `${this.getSectionLabel(section)} parametrləri lokal saxlanıldı, serverə göndərilə bilmədi.`);
           }
       } else {
            // Handle local save error
            this.showNotification('error', 'Xəta', `${this.getSectionLabel(section)} parametrlərini lokal saxlamaq mümkün olmadı.`);
       }
     },

    openModal(modalType, data = null) {
      console.log('Opening modal:', modalType, data);
      this.activeModal = modalType;
      this.modalData = data ? JSON.parse(JSON.stringify(data)) : null; 
    },

    closeModal() {
      this.activeModal = null;
      this.modalData = null;
    },

    async saveItem(itemType, itemData) {
      this.isLoading = true; 
      const storeName = this.getStoreName(itemType); 
      if (!storeName) {
           this.showNotification('error', 'Xəta', `Naməlum element tipi: ${itemType}`);
           this.isLoading = false;
           return;
      }

      let isNew; 
      const keyName = storeName === 'accounts' ? 'code' : 'id'; 

      if (storeName === 'accounts') {
          if (!itemData.code || itemData.code.trim() === '') {
              this.showNotification('error', 'Xəta', 'Hesab kodu boş ola bilməz.'); this.isLoading = false; return;
          }
          isNew = !Array.isArray(this.accounts) || !(this.accounts.some(a => a.code === itemData.code));
      } else {
          if (storeName === 'transactions') {
                const type = itemData.type;
                let targetArray;
                if (type === 'income') targetArray = this.incomeTransactions;
                else if (type === 'expense') targetArray = this.expenseTransactions;
                else if (type === 'transfer') targetArray = this.transfers;
                else if (type === 'credit') targetArray = this.credits;
                else targetArray = []; 
                isNew = !itemData.id || (typeof itemData.id === 'string' && itemData.id.startsWith('offline_')) || (Array.isArray(targetArray) && !targetArray.some(i => i.id === itemData.id));
           } else { 
               const dataArray = this[storeName];
               isNew = !itemData.id || (typeof itemData.id === 'string' && itemData.id.startsWith('offline_')) || (Array.isArray(dataArray) && !dataArray.some(i => i.id === itemData.id));
           }
      }

      if (storeName === 'transactions' && !itemData.type) {
           if (['income', 'expense', 'transfer', 'credit'].includes(itemType)) {
               itemData.type = itemType;
           } else {
                this.showNotification('error', 'Xəta', 'Tranzaksiya tipi təyin edilməyib.'); this.isLoading = false; return;
           }
       }

      const dateFields = ['date', 'startDate', 'endDate'];
       dateFields.forEach(field => {
            if (itemData[field]) {
                try {
                    const d = new Date(itemData[field]);
                    if (!isNaN(d.getTime())) {
                        itemData[field] = d.toISOString();
                    } else {
                        console.warn(`Invalid date string provided for ${field}: ${itemData[field]}. Removing field.`);
                        delete itemData[field]; 
                    }
                } catch (e) {
                    console.warn(`Error parsing date string for ${field}: ${itemData[field]}. Removing field.`, e);
                    delete itemData[field];
                }
            }
       });
       if (!itemData.date) {
            itemData.date = new Date().toISOString();
       }

      try {
        let savedData;
        if (isNew) {
          const dataToSend = { ...itemData }; 
          if (keyName === 'id' && dataToSend.id && typeof dataToSend.id === 'string' && dataToSend.id.startsWith('offline_')) {
              delete dataToSend.id;
          }
          savedData = await dbService.add(storeName, dataToSend);
        } else {
          const keyToUpdate = itemData[keyName];
          if (keyToUpdate === undefined || keyToUpdate === null) {
              throw new Error(`Cannot update ${itemType}: Missing key '${keyName}'`);
          }
          savedData = await dbService.update(storeName, keyToUpdate, itemData);
        }

        if (savedData && !savedData[keyName]) {
             if (!isNew) {
                  savedData[keyName] = itemData[keyName]; 
             } else if (storeName === 'accounts' && itemData.code) {
                 savedData.code = itemData.code; 
             } else {
                  console.error(`Saved data for ${itemType} is missing key '${keyName}':`, savedData);
                  if (isNew && itemData[keyName]) savedData[keyName] = itemData[keyName];
                   else if (!isNew && itemData[keyName]) savedData[keyName] = itemData[keyName];
                   else console.error("Could not determine key for saved data."); 
             }
         }

        this.updateLocalData(itemType, savedData);

        const reloadPromises = [];
         if (['sale', 'purchase', 'production'].includes(itemType)) {
             reloadPromises.push(dbService.getAll('products').then(data => this.products = data || []));
         }
          if (storeName === 'transactions' || storeName === 'accounts') {
             reloadPromises.push(dbService.getAll('accounts').then(data => this.accounts = data || []));
         }
          if (storeName === 'transactions') {
             reloadPromises.push(dbService.getAll('transactions').then(data => this.processTransactions(data || [])));
         }
         if (itemType === 'credit' || storeName === 'customers') {
              reloadPromises.push(dbService.getAll('customers').then(data => this.customers = data || []));
         }
          if (storeName === 'products') {
              reloadPromises.push(dbService.getAll('categories').then(data => this.categories = data || []));
          }
         reloadPromises.push(dbService.getAll('operations').then(data => this.operations = data || []));

         if (reloadPromises.length > 0) {
             await Promise.all(reloadPromises);
             console.log("Related data reloaded after save.");
         }
        this.closeModal(); 
        this.showNotification('success', 'Uğurlu', `${this.getItemTypeLabel(itemType)} uğurla ${isNew ? 'əlavə edildi' : 'yeniləndi'}`);
      } catch (error) {
         this.handleApiError(error, `saving ${itemType}`); 
      } finally {
        this.isLoading = false; 
      }
    },

    performDelete(itemType, itemKey) {
       const storeName = this.getStoreName(itemType);
       const keyName = storeName === 'accounts' ? 'code' : 'id';

       if (!storeName || itemKey === null || itemKey === undefined || (typeof itemKey === 'string' && itemKey.trim() === '')) {
            this.showNotification('error', 'Xəta', `Silmək üçün ID/Kod təyin edilməyib: ${itemType}`); return;
       }

      this.showDialog({
        title: 'Silmə Təsdiqi',
        message: `${this.getItemTypeLabel(itemType)} (ID/Kod: ${itemKey}) silmək istədiyinizə əminsiniz? Bu əməliyyat geri qaytarıla bilməz.`,
        confirmText: 'Bəli, sil',
        confirmButtonClass: 'btn-danger', 
        onConfirm: async () => { 
          this.isLoading = true;
          try {
            await dbService.delete(storeName, itemKey); 
            this.removeLocalData(itemType, itemKey); 

             const reloadPromises = [];
              if (['sale', 'purchase', 'production'].includes(itemType)) {
                 reloadPromises.push(dbService.getAll('products').then(data => this.products = data || []));
             }
              if (storeName === 'transactions' || storeName === 'accounts') {
                 reloadPromises.push(dbService.getAll('accounts').then(data => this.accounts = data || []));
             }
              if (storeName === 'transactions') {
                  reloadPromises.push(dbService.getAll('transactions').then(data => this.processTransactions(data || [])));
             }
             if (itemType === 'credit' || storeName === 'customers') {
                  reloadPromises.push(dbService.getAll('customers').then(data => this.customers = data || []));
             }
              if (storeName === 'products') {
                  reloadPromises.push(dbService.getAll('categories').then(data => this.categories = data || []));
              }
             reloadPromises.push(dbService.getAll('operations').then(data => this.operations = data || []));

             if (reloadPromises.length > 0) {
                 await Promise.all(reloadPromises);
                 console.log("Related data reloaded after delete.");
             }
            this.showNotification('success', 'Silindi', `${this.getItemTypeLabel(itemType)} uğurla silindi`);
          } catch (error) {
             this.handleApiError(error, `deleting ${itemType}`); 
          } finally {
            this.isLoading = false; 
          }
        }
      });
    },

    updateLocalData(itemType, data) {
      const storeName = this.getStoreName(itemType);
      const keyName = storeName === 'accounts' ? 'code' : 'id';
      const itemKey = data ? data[keyName] : null; 

      if (itemKey === undefined || itemKey === null || (typeof itemKey === 'string' && itemKey.trim() === '')) {
          console.warn(`Cannot update local data for ${itemType}: Missing or invalid key '${keyName}'`, data);
          return;
      }

      if (storeName === 'transactions') {
          const type = data.type;
          let targetArrayName;
            if (type === 'income') targetArrayName = 'incomeTransactions';
            else if (type === 'expense') targetArrayName = 'expenseTransactions';
            else if (type === 'transfer') targetArrayName = 'transfers';
            else if (type === 'credit') targetArrayName = 'credits';
            else { console.warn(`Unknown transaction type for updateLocalData: ${type}`); return; }

          if (!this[targetArrayName] || !Array.isArray(this[targetArrayName])) {
               console.warn(`Target array '${targetArrayName}' for transaction type ${type} is not an array. Initializing.`);
               this[targetArrayName] = [];
          }
          const targetArray = this[targetArrayName];

          const index = targetArray.findIndex(item => item[keyName] === itemKey);
          if (index !== -1) {
              targetArray.splice(index, 1, data); 
          } else {
              targetArray.push(data); 
              // Optionally sort after adding if needed: targetArray.sort(...)
          }
          console.log(`Updated/Added local transaction in ${targetArrayName} with key: ${itemKey}`);
      }
      else if (this[storeName] && Array.isArray(this[storeName])) {
          const dataArray = this[storeName];
          const index = dataArray.findIndex(item => item[keyName] === itemKey);
          if (index !== -1) {
            dataArray.splice(index, 1, data); 
          } else {
            dataArray.push(data); 
          }
           console.log(`Updated/Added local ${itemType} with key: ${itemKey}`);
      } else {
           console.warn(`Cannot update local data for ${itemType}: Store array '${storeName}' not found or not an array.`);
      }
    },

    removeLocalData(itemType, itemKey) {
      const storeName = this.getStoreName(itemType);
      const keyName = storeName === 'accounts' ? 'code' : 'id';

       if (itemKey === null || itemKey === undefined || (typeof itemKey === 'string' && itemKey.trim() === '')) {
          console.warn(`Cannot remove local data for ${itemType}: Invalid key`, itemKey);
          return;
      }

      if (storeName === 'transactions') {
          let removed = false;
          const arraysInfo = [
              { name: 'incomeTransactions', arr: this.incomeTransactions },
              { name: 'expenseTransactions', arr: this.expenseTransactions },
              { name: 'transfers', arr: this.transfers },
              { name: 'credits', arr: this.credits }
          ];

           arraysInfo.forEach(({ name, arr }) => {
               if (arr && Array.isArray(arr)) { 
                   const index = arr.findIndex(item => item[keyName] === itemKey);
                   if (index !== -1) {
                       arr.splice(index, 1); 
                       removed = true;
                       console.log(`Removed transaction with key ${itemKey} from ${name}`);
                   }
               }
           });

          if (!removed) {
               console.warn(`Attempted to remove local transaction with key: ${itemKey}, but not found in any transaction array.`);
          }
      }
      else if (this[storeName] && Array.isArray(this[storeName])) {
          const dataArray = this[storeName];
          const index = dataArray.findIndex(item => item[keyName] === itemKey);
          if (index !== -1) {
            dataArray.splice(index, 1); 
            console.log(`Removed local ${itemType} with key: ${itemKey}`);
          } else {
            console.warn(`Attempted to remove local ${itemType} with key: ${itemKey}, but not found in '${storeName}'.`);
          }
      } else {
           console.warn(`Cannot remove local data for ${itemType}: Store array '${storeName}' not found or not an array.`);
      }
    },

    getStoreName(itemType) {
      const map = {
        'product': 'products', 'category': 'categories', 'customer': 'customers',
        'supplier': 'suppliers', 'user': 'users', 'sale': 'sales',
        'purchase': 'purchases', 'operation': 'operations', 'production': 'productions',
        'account': 'accounts',
         'income': 'transactions', 'expense': 'transactions',
         'transfer': 'transactions', 'credit': 'transactions'
      };
      const storeName = map[itemType];
       if (!storeName) console.error(`No store mapping found for itemType: ${itemType}`); 
      return storeName;
    },

    getItemTypeLabel(itemType) {
       const labels = {
         'product': 'Məhsul', 'category': 'Kateqoriya', 'customer': 'Müştəri',
         'supplier': 'Təchizatçı', 'user': 'İstifadəçi', 'sale': 'Satış',
         'purchase': 'Alış', 'operation': 'Əməliyyat', 'production': 'İstehsal',
         'account': 'Hesab', 'income': 'Gəlir', 'expense': 'Xərc',
         'transfer': 'Transfer', 'credit': 'Kredit Ödəməsi'
       };
       return labels[itemType] || itemType; 
    },

    getFabMenuItems(tabId) {
        const items = {
            products: [
                { id: 'productAdd', name: 'Yeni Məhsul', icon: 'products', color: 'var(--primary-color)' },
                { id: 'categoryAdd', name: 'Yeni Kateqoriya', icon: 'settings', color: 'var(--warning-color)' },
            ],
            sales: [
                { id: 'saleAdd', name: 'Yeni Satış', icon: 'sales', color: 'var(--success-color)' },
                { id: 'creditAdd', name: 'Kredit Ödənişi', icon: 'cashier', color: 'var(--primary-color)' },
            ],
            purchases: [
                { id: 'purchaseAdd', name: 'Yeni Alış', icon: 'purchases', color: 'var(--primary-color)' },
            ],
            customers: [
                { id: 'customerAdd', name: 'Yeni Müştəri', icon: 'customers', color: 'var(--danger-color)' },
            ],
            suppliers: [
                { id: 'supplierAdd', name: 'Yeni Təchizatçı', icon: 'suppliers', color: 'var(--info-color)' }, 
            ],
            cashier: [
                { id: 'incomeAdd', name: 'Yeni Gəlir', icon: 'sales', color: 'var(--success-color)' },
                { id: 'expenseAdd', name: 'Yeni Xərc', icon: 'purchases', color: 'var(--danger-color)' },
                { id: 'transferAdd', name: 'Transfer', icon: 'operations', color: 'var(--primary-color)' },
                { id: 'accountAdd', name: 'Yeni Hesab', icon: 'settings', color: 'var(--warning-color)' },
            ],
            production: [
                { id: 'productionAdd', name: 'Yeni İstehsal', icon: 'production', color: 'var(--primary-color)' },
            ],
            users: [ 
                { id: 'userAdd', name: 'Yeni İstifadəçi', icon: 'users', color: 'var(--info-color)' } 
            ],
            default: [
                { id: 'saleAdd', name: 'Yeni Satış', icon: 'sales', color: 'var(--success-color)' },
                { id: 'purchaseAdd', name: 'Yeni Alış', icon: 'purchases', color: 'var(--primary-color)' },
                { id: 'productAdd', name: 'Yeni Məhsul', icon: 'products', color: 'var(--warning-color)' },
            ]
        };
        return items[tabId] || items.default;
     },

    showNotification(type, title, message, duration = 5000) {
       const timestamp = Date.now() + Math.random(); 
       this.notifications.unshift({ type, title, message, duration, timestamp }); 
       setTimeout(() => this.closeNotificationByTimestamp(timestamp), duration);
     },
     closeNotification(index) {
         if (index >= 0 && index < this.notifications.length) {
             this.notifications.splice(index, 1);
         }
     },
     closeNotificationByTimestamp(timestamp) {
       const index = this.notifications.findIndex(n => n.timestamp === timestamp);
       if (index !== -1) this.closeNotification(index);
     },

    showDialog(options) {
         this.dialog = { ...this.dialog, ...options, show: true };
     },
     confirmDialog() {
       if (typeof this.dialog.onConfirm === 'function') {
           try { this.dialog.onConfirm(); } catch (e) { console.error("Error in dialog confirm callback:", e); }
       }
       this.resetDialog();
     },
     cancelDialog() {
       if (typeof this.dialog.onCancel === 'function') {
            try { this.dialog.onCancel(); } catch (e) { console.error("Error in dialog cancel callback:", e); }
       }
       this.resetDialog();
     },
     resetDialog() {
       this.dialog = { show: false, title: '', message: '', confirmText: 'Bəli', cancelText: 'Xeyr', confirmButtonClass: 'btn-danger', onConfirm: null, onCancel: null };
     },

    toggleFabMenu() { this.showQuickMenu = !this.showQuickMenu; },

    updateOnlineStatus() {
         const oldStatus = this.isOnline;
         this.isOnline = navigator.onLine;
         if (oldStatus !== this.isOnline) {
             this.showNotification(this.isOnline ? 'success' : 'warning',
                                   this.isOnline ? 'Online' : 'Offline',
                                   this.isOnline ? 'İnternet bağlantısı bərpa olundu.' : 'İnternet bağlantısı kəsildi. Offline rejim aktivdir.');
         }
         dbService.isOnline = this.isOnline; 
         if (this.isOnline) {
             dbService.syncWithServer();
         }
     },

    getAccountName(accountCodeOrId) {
      if (!Array.isArray(this.accounts) || !accountCodeOrId) return 'Naməlum';
      const account = this.accounts.find(acc => acc.code === accountCodeOrId || acc.id === accountCodeOrId);
      return account ? account.name : `Naməlum (${accountCodeOrId})`;
    },
     getCustomerName(customerId) {
        if (!Array.isArray(this.customers) || !customerId) return 'Anonim';
        const customer = this.customers.find(c => c.id === customerId);
        return customer ? customer.name : 'Anonim';
     },
    getSupplierName(supplierId) {
        if (!Array.isArray(this.suppliers) || !supplierId) return 'Naməlum';
        const supplier = this.suppliers.find(s => s.id === supplierId);
        return supplier ? supplier.company : 'Naməlum';
    },
    formatCurrency(amount) {
      if (amount === null || amount === undefined || isNaN(parseFloat(amount))) return '0.00 ₼';
      return parseFloat(amount).toFixed(2) + ' ₼';
    },
     formatDateTime(dateString) {
        if (!dateString) return '-';
        try {
          const date = new Date(dateString);
          if (isNaN(date.getTime())) return '-'; 
          return date.toLocaleString('az-AZ', { 
             year: 'numeric', month: '2-digit', day: '2-digit',
             hour: '2-digit', minute: '2-digit'
          });
        } catch (e) { return '-'; } 
     },
     getPaymentMethodLabel(method) {
        const labels = { 'cash': 'Nağd', 'card': 'Kart', 'bank': 'Bank' };
        return labels[method] || method;
     },
     getTransactionTypeClass(type) {
       const baseClass = 'badge ';
       switch (type) {
           case 'income': return baseClass + 'status-normal'; 
           case 'expense': return baseClass + 'status-critical'; 
           case 'transfer': return baseClass + 'status-warning'; 
           case 'credit': return baseClass + 'status-info'; 
           default: return baseClass + 'badge-dark'; 
       }
     },
     getSectionLabel(section) {
        const labels = { general: 'Ümumi', invoices: 'Faktura', taxes: 'Vergi', categories: 'Kateqoriya', accounting: 'Hesablar Planı/Təyinatlar', backup: 'Yedəkləmə', appearance: 'Görünüş', accounts: 'Hesab Ayarları' };
        return labels[section] || section;
     },
    async toggleUserStatus(userId, newStatus) {
         this.isLoading = true;
         try {
              const user = this.users.find(u => u.id === userId);
              if (!user) throw new Error("İstifadəçi tapılmadı");
              if (user.username === 'admin') {
                  this.showNotification('error', 'Xəta', 'Admin istifadəçisinin statusu dəyişdirilə bilməz.');
                  this.isLoading = false;
                  return;
              }

              const updatedUserData = { ...user, status: newStatus };
              const savedData = await dbService.update('users', userId, updatedUserData); 

              this.updateLocalData('user', savedData); 
              this.showNotification('success', 'Status Dəyişdirildi', `${user.fullName} istifadəçisinin statusu ${newStatus === 'active' ? 'aktiv' : 'deaktiv'} edildi.`);
         } catch (error) {
              this.handleApiError(error, `toggling user status for ${userId}`);
         } finally {
              this.isLoading = false;
         }
      },

    loadUserFromStorage() {
        // Implement logic to load user from storage
    },
  },

  async mounted() {
     window.addEventListener('online', this.updateOnlineStatus);
     window.addEventListener('offline', this.updateOnlineStatus);
     window.addEventListener('request-data-refresh', () => this.loadAllData(false)); 

     this.updateOnlineStatus(); 
     this.loadUserFromStorage();

     this.isLoading = true; 
     try {
         await dbService.initDB(); 
         console.log("DB initialized from mounted");
         await this.loadAllData(true); 
     } catch (error) {
         console.error("Initialization error in mounted:", error);
         this.showNotification('error', 'Başlanğıc Xətası', 'Sistem yüklənərkən xəta baş verdi.');
         if (dbService.db) {
            await this.loadAllDataLocalFallback(true); 
         }
         this.isLoading = false; 
     }

     this.clickOutsideFabHandler = (event) => {
       if (this.showQuickMenu) {
         const fabContainer = this.$refs.fabContainer;
         if (fabContainer && !fabContainer.contains(event.target)) {
           this.toggleFabMenu();
         }
       }
     };
     document.addEventListener('click', this.clickOutsideFabHandler);
  },
  beforeUnmount() {
      window.removeEventListener('online', this.updateOnlineStatus);
      window.removeEventListener('offline', this.updateOnlineStatus);
      window.removeEventListener('request-data-refresh', () => this.loadAllData(false));
      document.removeEventListener('click', this.clickOutsideFabHandler);
  }
});

registerComponents(app);
app.config.globalProperties.$root = app;

const mountedApp = app.mount('#app');
export { mountedApp as app };