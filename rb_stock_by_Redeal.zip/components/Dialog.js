export default {
  props: {
    show: {
      type: Boolean,
      required: true
    },
    title: {
      type: String,
      default: 'Təsdiq'
    },
    message: {
      type: String,
      required: true
    },
    confirmText: {
      type: String,
      default: 'Bəli'
    },
    cancelText: {
      type: String,
      default: 'Xeyr'
    },
    confirmButtonClass: {
      type: String,
      default: 'btn-danger'
    }
  },
  template: `
    <transition name="dialog-fade">
      <div v-if="show" class="dialog-backdrop" @click.self="$emit('cancel')">
        <div class="dialog">
          <div class="dialog-header">
            <h3 class="dialog-title">{{ title }}</h3>
          </div>
          <div class="dialog-content">{{ message }}</div>
          <div class="dialog-actions">
            <button class="btn btn-secondary" @click="$emit('cancel')">{{ cancelText }}</button>
            <button :class="['btn', confirmButtonClass]" @click="$emit('confirm')">{{ confirmText }}</button>
          </div>
        </div>
      </div>
    </transition>
  `
}

