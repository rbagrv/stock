export default {
  props: ['products', 'operations', 'customers', 'sales', 'purchases'],
  template: `
    <div class="tab-content">
      <h2>Əsas Səhifə</h2>

      <!-- Quick Stats -->
      <div class="dashboard-stats">
        <div class="dash-stat-card primary">
          <div class="dash-stat-icon" v-html="$root.getIconSvg('products')"></div>
          <div class="dash-stat-content">
            <h3>Məhsullar</h3>
            <!-- Use optional chaining for safety -->
            <div class="dash-stat-value">{{ products?.length || 0 }}</div>
            <div class="dash-stat-info">Ümumi məhsul sayı</div>
          </div>
        </div>

        <div class="dash-stat-card success">
          <div class="dash-stat-icon" v-html="$root.getIconSvg('sales')"></div>
          <div class="dash-stat-content">
            <h3>Satışlar (Bu gün)</h3>
            <!-- Calculate today's sales -->
            <div class="dash-stat-value">{{ todaySalesCount }}</div>
            <div class="dash-stat-info">Bugünkü satış sayı</div>
          </div>
        </div>

        <div class="dash-stat-card warning">
          <div class="dash-stat-icon" v-html="$root.getIconSvg('customers')"></div>
          <div class="dash-stat-content">
            <h3>Alıcılar</h3>
            <div class="dash-stat-value">{{ customers?.length || 0 }}</div>
            <div class="dash-stat-info">Ümumi alıcı sayı</div>
          </div>
        </div>

        <div class="dash-stat-card danger">
           <div class="dash-stat-icon">
               <!-- Low Stock Icon -->
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
           </div>
           <div class="dash-stat-content">
             <h3>Stok Xəbərdarlıqları</h3>
             <div class="dash-stat-value">{{ lowStockProductsCount }}</div>
             <div class="dash-stat-info">Az qalan məhsul sayı</div>
           </div>
        </div>
      </div>

      <!-- Detailed Sections -->
      <div class="dashboard-row">
        <!-- Low Stock Warnings -->
        <div class="dashboard-card">
          <div class="card-header">
            <h3>Stok Xəbərdarlıqları</h3>
          </div>
          <!-- Check if lowStockProducts exists and has items -->
          <div class="dashboard-list" v-if="lowStockProducts && lowStockProducts.length > 0">
            <!-- Slice the array safely -->
            <div class="dashboard-list-item" v-for="product in lowStockProducts.slice(0, 5)" :key="product.id">
              <div class="dashboard-list-icon" :class="getLowStockIconClass(product.quantity)">
                 <!-- Product Icon -->
                 <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4a2 2 0 0 0 1-1.73z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22" x2="12" y2="12"/></svg>
              </div>
              <div class="dashboard-list-content">
                <div class="dashboard-list-title">{{ product.name }}</div>
                <!-- Use root formatter for consistency -->
                <div class="dashboard-list-subtitle">{{ $root.formatCurrency(product.salePrice) }}</div>
              </div>
              <div class="dashboard-list-badge" :class="getLowStockBadgeClass(product.quantity)">
                {{ product.quantity }} {{ product.unit }}
              </div>
            </div>
             <div v-if="lowStockProducts.length > 5" class="dashboard-list-footer">
                <a href="#" @click.prevent="$root.activeTab = 'products'; $root.quantityFilter = 'low';">Hamısına bax...</a>
             </div>
          </div>
          <div class="empty-state" v-else>
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
            <p>Stok xəbərdarlığı yoxdur</p>
          </div>
        </div>

        <!-- Recent Operations -->
        <div class="dashboard-card">
          <div class="card-header">
            <h3>Son Əməliyyatlar</h3>
          </div>
          <!-- Check if operations exists and has items -->
          <div class="dashboard-list" v-if="operations && operations.length > 0">
            <!-- Slice the array safely -->
            <div class="dashboard-list-item" v-for="operation in sortedOperations.slice(0, 5)" :key="operation.id">
              <div class="dashboard-list-icon" :class="getOperationIconClass(operation.type)">
                 <!-- Use dynamic icons based on type -->
                 <span v-html="getOperationIcon(operation.type)"></span>
              </div>
              <div class="dashboard-list-content">
                <!-- Display more meaningful title -->
                <div class="dashboard-list-title">{{ getOperationTitle(operation) }}</div>
                <div class="dashboard-list-subtitle">{{ operation.description || 'Təsvir yoxdur' }}</div>
              </div>
              <div class="dashboard-list-date">{{ $root.formatDateTime(operation.date) }}</div>
            </div>
            <div v-if="operations.length > 5" class="dashboard-list-footer">
                <a href="#" @click.prevent="$root.activeTab = 'operations'">Hamısına bax...</a>
            </div>
          </div>
          <div class="empty-state" v-else>
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
            <p>Əməliyyat yoxdur</p>
          </div>
        </div>
      </div>
    </div>
  `,
  computed: {
    lowStockProducts() {
      // Ensure products is an array before filtering
      if (!Array.isArray(this.products)) return [];
      // Use a configurable threshold (e.g., from settings, default 10)
      const threshold = this.$root.settings?.general?.lowStockThreshold || 10;
      return this.products
        .filter(product => product.quantity <= threshold)
        .sort((a, b) => a.quantity - b.quantity); // Sort by lowest quantity first
    },
    lowStockProductsCount() {
        return this.lowStockProducts.length;
    },
    todaySalesCount() {
        if (!Array.isArray(this.sales)) return 0;
        const today = new Date().toISOString().slice(0, 10); // Get YYYY-MM-DD for today
        return this.sales.filter(sale => sale.date?.startsWith(today)).length;
    },
    sortedOperations() {
        // Ensure operations is an array and sort by date descending
        if (!Array.isArray(this.operations)) return [];
        return [...this.operations].sort((a, b) => new Date(b.date) - new Date(a.date));
    }
  },
  methods: {
      getLowStockIconClass(quantity) {
          if (quantity <= 0) return 'status-critical danger-icon';
          if (quantity <= 5) return 'status-critical danger-icon'; // Example: Critical below 5
          if (quantity <= 10) return 'status-warning warning-icon'; // Example: Warning below 10
          return 'status-normal success-icon'; // Should not happen in this list, but default
      },
      getLowStockBadgeClass(quantity) {
          if (quantity <= 0) return 'status-critical';
          if (quantity <= 5) return 'status-critical';
          if (quantity <= 10) return 'status-warning';
          return 'status-normal';
      },
      getOperationIconClass(type) {
          if (type?.includes('_add') || type?.includes('income') || type?.includes('sale') || type?.includes('_output') || type?.includes('stock_adjust_purch_del') || type?.includes('stock_adjust_prod_out_del') || type?.includes('credit')) return 'success-icon';
          if (type?.includes('_delete') || type?.includes('expense') || type?.includes('stock_adjust_sale_del') || type?.includes('stock_adjust_prod_in_del')) return 'danger-icon';
          if (type?.includes('_update') || type?.includes('transfer') || type?.includes('production') || type?.includes('_input') || type?.includes('stock_adjust_update')) return 'warning-icon';
          return 'info-icon'; // Default info icon for account_*, category_*, user_* etc.
      },
      getOperationIcon(type) {
          if (type?.includes('sale')) return this.$root.getIconSvg('sales');
          if (type?.includes('purchase')) return this.$root.getIconSvg('purchases');
          if (type?.includes('product')) return this.$root.getIconSvg('products');
          if (type?.includes('transfer')) return `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>`;
          if (type?.includes('income') || type?.includes('credit')) return `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`; // Plus sign
          if (type?.includes('expense')) return `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>`; // Minus sign
          if (type?.includes('production')) return this.$root.getIconSvg('production');
          if (type?.includes('customer')) return this.$root.getIconSvg('customers');
          if (type?.includes('supplier')) return this.$root.getIconSvg('suppliers');
          if (type?.includes('user')) return this.$root.getIconSvg('users');
          if (type?.includes('account')) return this.$root.getIconSvg('cashier');
          if (type?.includes('category')) return `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4a2 2 0 0 0 1-1.73z"/><path d="M7.5 4.21l4.5 2.6 4.5-2.6"/><path d="m7.5 19.79 4.5-2.6 4.5 2.6"/><path d="M3.27 6.96 12 12.01l8.73-5.05"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`; // Layers/Category icon
          return this.$root.getIconSvg('operations'); // Default icon
      },
      getOperationTitle(operation) {
         // Provides a more descriptive title for the operation list item
         const typeLabel = this.$root.getItemTypeLabel(operation.type);
         const amount = operation.amount ? this.$root.formatCurrency(operation.amount) : null;
         const quantity = operation.quantity !== undefined ? `${operation.quantity} ${operation.unit || ''}`.trim() : null;

         // Specific formats for common types
         if (operation.type.startsWith('sale_') || operation.type.startsWith('purchase_')) {
            return `${typeLabel}: Kod ${operation.referenceId}`;
         }
         if (operation.type.startsWith('product_')) {
            return `${typeLabel}: ${operation.productName || `(ID: ${operation.referenceId})`}`;
         }
         if (operation.type.startsWith('income_') || operation.type.startsWith('expense_') || operation.type.startsWith('credit_')) {
            let details = amount ? `${typeLabel}: ${amount}` : typeLabel;
            if (operation.referenceType === 'customer') details += ` - ${this.$root.getCustomerName(operation.referenceId)}`;
            return details;
         }
         if (operation.type.startsWith('transfer_')) {
             return amount ? `${typeLabel}: ${amount}` : typeLabel;
         }
         if (operation.type.startsWith('production_')) {
             let details = typeLabel;
             if(operation.productName) details += ` - ${operation.productName}`;
             if(quantity) details += ` (${quantity})`;
             return details;
         }
         if (operation.type.startsWith('stock_adjust_')) {
             let details = typeLabel;
             if(operation.productName) details += ` - ${operation.productName}`;
             if(quantity) details += ` (${quantity})`;
             return details;
         }
         if (operation.type.startsWith('customer_')) {
             return `${typeLabel}: ${this.$root.getCustomerName(operation.referenceId)}`;
         }
          if (operation.type.startsWith('supplier_')) {
             return `${typeLabel}: ${this.$root.getSupplierName(operation.referenceId)}`;
         }
         if (operation.type.startsWith('account_')) {
              return `${typeLabel}: ${this.$root.getAccountName(operation.referenceId)}`;
         }

         // Fallback using reference details if available
         if (operation.referenceType && operation.referenceId) {
              let relatedItemName = '';
              if(operation.referenceType === 'sale') relatedItemName = `Satış #${operation.referenceId}`;
              else if(operation.referenceType === 'purchase') relatedItemName = `Alış #${operation.referenceId}`;
              else if(operation.referenceType === 'customer') relatedItemName = this.$root.getCustomerName(operation.referenceId);
              else if(operation.referenceType === 'supplier') relatedItemName = this.$root.getSupplierName(operation.referenceId);
              else if(operation.referenceType === 'account') relatedItemName = this.$root.getAccountName(operation.referenceId);
              else relatedItemName = `${operation.referenceType} #${operation.referenceId}`;
             return `${typeLabel} (${relatedItemName})`;
         }

         // Final fallback to just the type label
         return typeLabel || operation.type;
      }
  }
};