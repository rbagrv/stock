export default {
  props: ['users'],
  data() {
    return {
      search: '',
      roleFilter: ''
    };
  },
  template: `
    <div class="tab-content">
      <h2>İstifadəçilər</h2>
      
      <div class="card">
        <div class="card-header">
          <div class="search-input">
            <input type="text" v-model="search" placeholder="İstifadəçi axtar..." />
          </div>
          <div class="button-group">
            <button class="add-btn" @click="addUser">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"></path></svg>
              İstifadəçi əlavə et
            </button>
          </div>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>Tam Ad</th>
                  <th>İstifadəçi adı</th>
                  <th>Email</th>
                  <th>Rol</th>
                  <th>Status</th>
                  <th>Son giriş</th>
                  <th>Əməliyyatlar</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="user in filteredUsers" :key="user.id">
                  <td>{{ user.fullName }}</td>
                  <td>{{ user.username }}</td>
                  <td>{{ user.email || '-' }}</td>
                  <td>{{ user.role }}</td>
                  <td>
                    <span :class="user.status === 'active' ? 'status-normal' : 'status-critical'">
                      {{ user.status === 'active' ? 'Aktiv' : 'Deaktiv' }}
                    </span>
                  </td>
                  <td>{{ user.lastLogin ? new Date(user.lastLogin).toLocaleString() : 'Heç vaxt' }}</td>
                  <td>
                    <div class="button-group">
                      <button class="btn-edit" @click="editUser(user)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>
                      </button>
                      <button class="btn-delete" @click="toggleUserStatus(user)" v-if="user.username !== 'admin'">
                        <svg v-if="user.status === 'active'" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                        <svg v-else xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
  computed: {
    filteredUsers() {
      if (!this.search && !this.roleFilter) return this.users;
      
      return this.users.filter(user => {
        const matchesSearch = !this.search || 
          user.fullName.toLowerCase().includes(this.search.toLowerCase()) || 
          user.username.toLowerCase().includes(this.search.toLowerCase()) || 
          (user.email && user.email.toLowerCase().includes(this.search.toLowerCase()));
          
        const matchesRole = !this.roleFilter || user.role === this.roleFilter;
        
        return matchesSearch && matchesRole;
      });
    }
  },
  methods: {
    addUser() {
      this.$emit('open-modal', 'userAdd');
    },
    editUser(user) {
      this.$emit('open-modal', 'userEdit', user);
    },
    toggleUserStatus(user) {
      if (user.username === 'admin') {
        alert('Admin istifadəçisinin statusu dəyişdirilə bilməz!');
        return;
      }
      
      const newStatus = user.status === 'active' ? 'inactive' : 'active';
      const message = newStatus === 'active' 
        ? `${user.fullName} istifadəçisini aktivləşdirmək istədiyinizə əminsiniz?`
        : `${user.fullName} istifadəçisini deaktiv etmək istədiyinizə əminsiniz?`;
        
      if (confirm(message)) {
        this.$emit('toggle-user-status', user.id, newStatus);
      }
    }
  }
};