export default {
  props: ['productions', 'products'],
  data() {
    return {
      search: '',
      statusFilter: ''
    };
  },
  template: `
    <div class="tab-content">
      <h2>İstehsal</h2>
      
      <div class="card">
        <div class="card-header">
          <div class="search-input">
            <input type="text" v-model="search" placeholder="İstehsal axtar..." />
          </div>
          <div class="button-group">
            <button class="add-btn" @click="addProduction">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"></path></svg>
              Yeni İstehsal
            </button>
          </div>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>Ad</th>
                  <th>Status</th>
                  <th>Başlama Tarixi</th>
                  <th>Bitmə Tarixi</th>
                  <th>Giriş Məhsulları</th>
                  <th>Çıxış Məhsulları</th>
                  <th>Əməliyyatlar</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="production in filteredProductions" :key="production.id">
                  <td>{{ production.name }}</td>
                  <td>
                    <span :class="getStatusClass(production.status)">{{ production.status }}</span>
                  </td>
                  <td>{{ new Date(production.startDate).toLocaleDateString() }}</td>
                  <td>{{ production.endDate ? new Date(production.endDate).toLocaleDateString() : '-' }}</td>
                  <td>{{ production.items ? production.items.length : 0 }} məhsul</td>
                  <td>{{ production.output ? production.output.length : 0 }} məhsul</td>
                  <td>
                    <div class="button-group">
                      <button class="btn-view" @click="viewProductionDetails(production)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12" y2="16"></line></svg>
                      </button>
                      <button class="btn-edit" @click="editProduction(production)" v-if="production.status !== 'completed'">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
  computed: {
    filteredProductions() {
      if (!this.search && !this.statusFilter) return this.productions;
      
      return this.productions.filter(production => {
        const matchesSearch = !this.search || production.name.toLowerCase().includes(this.search.toLowerCase());
        const matchesStatus = !this.statusFilter || production.status === this.statusFilter;
        return matchesSearch && matchesStatus;
      });
    }
  },
  methods: {
    addProduction() {
      this.$emit('open-modal', 'productionAdd');
    },
    viewProductionDetails(production) {
      this.$emit('open-modal', 'productionDetails', production);
    },
    editProduction(production) {
      this.$emit('open-modal', 'productionEdit', production);
    },
    getStatusClass(status) {
      const classes = {
        'planned': 'status-info',
        'in-progress': 'status-warning',
        'completed': 'status-normal',
        'canceled': 'status-critical'
      };
      return classes[status] || '';
    }
  }
};