export default {
  props: ['purchases', 'suppliers'],
  data() {
    return {
      search: ''
    };
  },
  template: `
    <div class="tab-content">
      <h2>Alışlar</h2>

      <div class="card">
        <div class="card-header">
          <div class="search-input-group"> 
            <div class="search-input">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                <input type="text" v-model="search" placeholder="Alış axtar (Kod, Təchizatçı, Faktura)..." />
            </div>
            <!-- Add filter button if needed later -->
          </div>
          <div class="button-group">
            <button class="add-btn" @click="addPurchase">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"></path></svg>
              Yeni Alış
            </button>
          </div>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Kod</th>
                  <th>Təchizatçı</th>
                  <th>Tarix</th>
                  <th>Ödəniş Metodu</th>
                  <th>Ümumi Məbləğ</th>
                  <th>İnvoice №</th>
                  <th>Əməliyyatlar</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="purchase in filteredPurchases" :key="purchase.id">
                  <td><span class="badge badge-dark">{{ purchase.id }}</span></td>
                  <td>{{ purchase.code || 'N/A' }}</td>
                  <td>{{ getSupplierName(purchase.supplierId) || '-' }}</td>
                  <td>{{ formatDate(purchase.date) }}</td>
                  <td>
                      <span :class="['payment-method', purchase.paymentMethod]">
                          {{ getPaymentMethodLabel(purchase.paymentMethod) }}
                      </span>
                  </td>
                  <td class="amount-cell text-right">{{ formatCurrency(purchase.totalAmount) }}</td>
                  <td>{{ purchase.invoiceNumber || '-' }}</td>
                  <td>
                    <div class="button-group">
                      <!-- View Details Button -->
                      <button class="action-btn view-btn" @click="viewPurchaseDetails(purchase)" title="Ətraflı bax">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                      </button>
                      <!-- Edit Button -->
                      <button class="action-btn edit-btn" @click="editPurchase(purchase)" title="Düzəliş et">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>
                      </button>
                      <!-- Delete Button -->
                      <button class="action-btn delete-btn" @click="deletePurchase(purchase.id)" title="Sil">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                      </button>
                      <!-- Print/Share are now handled by the Details modal -->
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
           <div class="empty-state" v-if="!filteredPurchases || filteredPurchases.length === 0">
             <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 3H8"></path></svg>
             <p>Heç bir alış tapılmadı.</p>
          </div>
        </div>
      </div>
    </div>
  `,
  computed: {
    filteredPurchases() {
       if (!Array.isArray(this.purchases)) return [];
      let filtered = [...this.purchases];

      if (this.search) {
        const searchTerm = this.search.toLowerCase();
        filtered = filtered.filter(purchase => {
          const supplierName = this.getSupplierName(purchase.supplierId) || '';
          return (
            (purchase.code && purchase.code.toLowerCase().includes(searchTerm)) ||
            (supplierName.toLowerCase().includes(searchTerm)) ||
            (purchase.invoiceNumber && purchase.invoiceNumber.toLowerCase().includes(searchTerm)) ||
            (purchase.id && purchase.id.toString().includes(searchTerm))
          );
        });
      }
      // Sort by date descending by default
      return filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    }
  },
  methods: {
    // Use root methods for formatting and getting names
    formatCurrency(amount) { return this.$root.formatCurrency(amount); },
    formatDate(dateString) { return this.$root.formatDateTime(dateString).split(',')[0]; }, // Show only date part
    getSupplierName(supplierId) { return this.$root.getSupplierName(supplierId); },
    getPaymentMethodLabel(method) { return this.$root.getPaymentMethodLabel(method); },

    addPurchase() {
      this.$emit('open-modal', 'purchaseAdd');
    },
    viewPurchaseDetails(purchase) {
      // Open the generic details modal for purchases
      this.$emit('open-modal', 'purchaseDetails', purchase);
    },
    editPurchase(purchase) {
      this.$emit('open-modal', 'purchaseEdit', purchase);
    },
    deletePurchase(purchaseId) {
      // Emit delete event to be handled by the root instance
      this.$emit('delete-item', 'purchase', purchaseId);
    }
    // printPurchase and sharePurchase removed - handled by DetailsModal
  }
};