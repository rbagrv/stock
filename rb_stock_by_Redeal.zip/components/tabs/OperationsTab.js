export default {
  props: ['operations'],
  data() {
    return {
      search: '',
      typeFilter: '',
      dateFilter: {
        start: null,
        end: null
      },
      showFilters: false
    };
  },
  template: `
    <div class="tab-content">
      <h2>Əməliyyatlar</h2>

      <div class="card">
        <div class="card-header">
          <div class="search-input-group">
            <div class="search-input">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
              <input type="text" v-model="search" placeholder="Əməliyyat axtar..." />
            </div>
            <button class="filter-btn" @click="showFilters = !showFilters">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
              Filtr
            </button>
          </div>
        </div>

        <div class="filter-panel" v-if="showFilters">
          <div class="form-row">
            <div class="form-group">
              <label>Əməliyyat Növü</label>
              <select v-model="typeFilter">
                <option value="">Bütün növlər</option>
                <option v-for="opType in uniqueOperationTypes" :key="opType" :value="opType">
                  {{ getOperationTypeLabel(opType) }}
                </option>
              </select>
            </div>
            <div class="form-group">
              <label>Başlanğıc Tarix</label>
              <input type="date" v-model="dateFilter.start">
            </div>
            <div class="form-group">
              <label>Son Tarix</label>
              <input type="date" v-model="dateFilter.end">
            </div>
            <div class="form-group filter-actions">
              <button class="btn btn-primary" @click="applyFilters">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                Tətbiq et
              </button>
              <button class="btn btn-secondary" @click="resetFilters">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 2v6h6M21.5 22v-6h-6M2 11.5a10 10 0 0 0 18.8 4.5M22 12.5a10 10 0 0 0-18.8-4.5"></path></svg>
                Sıfırla
              </button>
            </div>
          </div>
        </div>

        <div class="card-body">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Tarix</th>
                  <th>Əməliyyat Növü</th>
                  <th>Məhsul</th>
                  <th>Miqdar</th>
                  <th>Təsvir</th>
                  <th>İstifadəçi</th>
                  <th>Əlaqəli ID</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="operation in filteredOperations" :key="operation.id">
                  <td><span class="badge badge-dark">{{ operation.id }}</span></td>
                  <td>{{ formatDateTime(operation.date) }}</td>
                  <td>
                    <span :class="getOperationTypeClass(operation.type)">
                      {{ getOperationTypeLabel(operation.type) }}
                    </span>
                  </td>
                  <td>{{ operation.productName || '-' }}</td>
                  <td>{{ operation.quantity !== null ? operation.quantity : '-' }}</td>
                  <td>{{ operation.description || '-' }}</td>
                  <td>{{ operation.userName || '-' }}</td>
                  <td>{{ operation.referenceId ? `${operation.referenceType}:${operation.referenceId}` : '-' }}</td>
                </tr>
              </tbody>
            </table>

            <div class="empty-state" v-if="!filteredOperations || filteredOperations.length === 0">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
              <p>Heç bir əməliyyat tapılmadı</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  computed: {
    filteredOperations() {
      if (!Array.isArray(this.operations)) return []; 

      let filtered = [...this.operations];

      if (this.search) {
        const searchTerm = this.search.toLowerCase();
        filtered = filtered.filter(operation => {
          return (
            (operation.description && operation.description.toLowerCase().includes(searchTerm)) ||
            (operation.productName && operation.productName.toLowerCase().includes(searchTerm)) ||
            (operation.userName && operation.userName.toLowerCase().includes(searchTerm)) ||
            (operation.id && operation.id.toString().includes(searchTerm)) || 
            (operation.referenceId && operation.referenceId.toString().includes(searchTerm)) 
          );
        });
      }

      if (this.typeFilter) {
        filtered = filtered.filter(operation => operation.type === this.typeFilter);
      }

      if (this.dateFilter.start) {
        const startDate = new Date(this.dateFilter.start);
        startDate.setHours(0, 0, 0, 0);
        filtered = filtered.filter(operation => new Date(operation.date) >= startDate);
      }

      if (this.dateFilter.end) {
        const endDate = new Date(this.dateFilter.end);
        endDate.setHours(23, 59, 59, 999);
        filtered = filtered.filter(operation => new Date(operation.date) <= endDate);
      }

      return filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    },
    uniqueOperationTypes() {
       if (!Array.isArray(this.operations)) return [];
       const types = new Set(this.operations.map(op => op.type));
       return Array.from(types).sort();
    }
  },
  methods: {
    formatDateTime(dateString) {
      if (!dateString) return '-';
      try {
        const date = new Date(dateString);
         if (isNaN(date.getTime())) return '-';
        return date.toLocaleString('az-AZ', {
          year: 'numeric', month: '2-digit', day: '2-digit',
          hour: '2-digit', minute: '2-digit'
        });
      } catch (e) { return '-'; }
    },

    getOperationTypeLabel(type) {
      const labels = {
        'income_add': 'Gəlir', 'expense_add': 'Xərc', 'transfer_add': 'Transfer', 'credit_add': 'Kredit Ödəmə',
        'income_update': 'Gəlir Düzəliş', 'expense_update': 'Xərc Düzəliş', 'transfer_update': 'Transfer Düzəliş', 'credit_update': 'Kredit Düzəliş',
        'income_delete': 'Gəlir Silmə', 'expense_delete': 'Xərc Silmə', 'transfer_delete': 'Transfer Silmə', 'credit_delete': 'Kredit Silmə',
        'product_add': 'Məhsul Əlavə', 'product_update': 'Məhsul Düzəliş', 'product_delete': 'Məhsul Silmə',
        'sale_add': 'Satış', 'purchase_add': 'Alış',
        'sale_update': 'Satış Düzəliş', 'purchase_update': 'Alış Düzəliş',
        'sale_delete': 'Satış Silmə', 'purchase_delete': 'Alış Silmə',
        'production_add': 'İstehsal Başlanğıc', 'production_update': 'İstehsal Düzəliş', 'production_delete': 'İstehsal Silmə',
        'production_input': 'İstehsal Giriş', 'production_output': 'İstehsal Çıxış',
        'production_complete': 'İstehsal Tamamlandı', 'production_revert_complete': 'İstehsal Geri Alındı',
        'customer_add': 'Müştəri Əlavə', 'supplier_add': 'Təchizatçı Əlavə', 'user_add': 'İstifadəçi Əlavə',
        'category_add': 'Kateqoriya Əlavə', 'category_update': 'Kateqoriya Düzəliş', 'category_delete': 'Kateqoriya Silmə',
        'account_add': 'Hesab Əlavə', 'account_update': 'Hesab Düzəliş', 'account_delete': 'Hesab Silmə',
        'stock_adjust_update': 'Stok Düzəlişi (Yeniləmə)',
        'stock_adjust_prod_in': 'Stok Düzəlişi (İstehsal Giriş)',
        'stock_adjust_prod_out': 'Stok Düzəlişi (İstehsal Çıxış)',
        'stock_adjust_sale_del': 'Stok Düzəlişi (Satış Silmə)',
        'stock_adjust_purch_del': 'Stok Düzəlişi (Alış Silmə)',
        'stock_adjust_prod_in_del': 'Stok Düzəlişi (İstehsal Giriş Silmə)',
        'stock_adjust_prod_out_del': 'Stok Düzəlişi (İstehsal Çıxış Silmə)'
      };
      return labels[type] || type; 
    },

    getOperationTypeClass(type) {
      const baseClass = 'badge ';
      if (type?.includes('_add') || type?.includes('income') || type?.includes('sale') || type?.includes('_output')) return baseClass + 'status-normal'; 
      if (type?.includes('_delete') || type?.includes('expense') || type?.includes('stock_adjust_purch_del') || type?.includes('stock_adjust_prod_out_del')) return baseClass + 'status-critical'; 
      if (type?.includes('_update') || type?.includes('transfer') || type?.includes('production') || type?.includes('_input')) return baseClass + 'status-warning'; 
      return baseClass + 'status-info'; 
    },

    applyFilters() {
      this.showFilters = false;
    },

    resetFilters() {
      this.search = '';
      this.typeFilter = '';
      this.dateFilter.start = null;
      this.dateFilter.end = null;
      this.showFilters = false;
    }
  }
};