export default {
  props: ['products', 'categories'],
  data() {
    return {
      search: '',
      barcodeSearch: '',
      categoryFilter: '',
      quantityFilter: '',
      showFilters: false,
      sortBy: 'name',
      sortDesc: false
    };
  },
  template: `
    <div class="tab-content">
      <h2>Məhsullar</h2>
      
      <div class="card">
        <div class="card-header">
          <div class="search-input-group">
            <div class="search-input">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
              <input type="text" v-model="search" placeholder="Məhsul axtar..." />
            </div>
            <button class="filter-btn" @click="showFilters = !showFilters">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
              Filtr
            </button>
          </div>
          <div class="button-group">
            <button class="add-btn" @click="addProduct">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"></path></svg>
              Məhsul əlavə et
            </button>
          </div>
        </div>
        
        <div class="filter-panel" v-if="showFilters">
          <div class="form-row">
            <div class="form-group">
              <label>Kateqoriya</label>
              <select v-model="categoryFilter">
                <option value="">Bütün kateqoriyalar</option>
                <option v-for="category in categories" :key="category.id" :value="category.id">
                  {{ category.name }}
                </option>
              </select>
            </div>
            <div class="form-group">
              <label>Stok vəziyyəti</label>
              <select v-model="quantityFilter">
                <option value="">Hamısı</option>
                <option value="low">Az qalanlar (10-dan az)</option>
                <option value="out">Bitənlər (0)</option>
                <option value="available">Mövcud olanlar (>0)</option>
              </select>
            </div>
            <div class="form-group">
              <label>Barkod</label>
              <input type="text" v-model="barcodeSearch" placeholder="Barkod axtar">
            </div>
            <div class="form-group filter-actions">
              <button class="btn btn-primary" @click="applyFilters">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                Tətbiq et
              </button>
              <button class="btn btn-secondary" @click="resetFilters">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 2v6h6M21.5 22v-6h-6M2 11.5a10 10 0 0 0 18.8 4.5M22 12.5a10 10 0 0 0-18.8-4.5"></path></svg>
                Sıfırla
              </button>
            </div>
          </div>
        </div>
        
        <div class="card-body">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th @click="changeSorting('code')">
                    Kod
                    <span class="sort-icon" v-if="sortBy === 'code'">
                      <svg v-if="sortDesc" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                      <svg v-else xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>
                    </span>
                  </th>
                  <th @click="changeSorting('name')">
                    Ad
                    <span class="sort-icon" v-if="sortBy === 'name'">
                      <svg v-if="sortDesc" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                      <svg v-else xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>
                    </span>
                  </th>
                  <th>Kateqoriya</th>
                  <th @click="changeSorting('purchasePrice')">
                    Alış qiyməti
                    <span class="sort-icon" v-if="sortBy === 'purchasePrice'">
                      <svg v-if="sortDesc" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                      <svg v-else xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>
                    </span>
                  </th>
                  <th @click="changeSorting('salePrice')">
                    Satış qiyməti
                    <span class="sort-icon" v-if="sortBy === 'salePrice'">
                      <svg v-if="sortDesc" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                      <svg v-else xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>
                    </span>
                  </th>
                  <th @click="changeSorting('quantity')">
                    Stok 
                    <span class="sort-icon" v-if="sortBy === 'quantity'">
                      <svg v-if="sortDesc" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                      <svg v-else xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>
                    </span>
                  </th>
                  <th>Əməliyyatlar</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="product in filteredAndSortedProducts" :key="product.id">
                  <td><span class="badge badge-primary">{{ product.code }}</span></td>
                  <td>{{ product.name }}</td>
                  <td>{{ product.categoryName || 'Kateqoriyasız' }}</td>
                  <td>{{ formatCurrency(product.purchasePrice) }}</td>
                  <td>{{ formatCurrency(product.salePrice) }}</td>
                  <td>
                    <span :class="getQuantityStatusClass(product.quantity)">
                      {{ product.quantity }} {{ product.unit }}
                    </span>
                  </td>
                  <td>
                    <div class="button-group">
                      <button class="action-btn view-btn" @click="viewProduct(product)" title="Ətraflı bax">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                      </button>
                      <button class="action-btn edit-btn" @click="editProduct(product)" title="Düzəliş et">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>
                      </button>
                      <button class="action-btn delete-btn" @click="deleteProduct(product.id)" title="Sil">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            
            <div class="empty-state" v-if="filteredAndSortedProducts.length === 0">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
              <p>Heç bir məhsul tapılmadı</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  computed: {
    filteredAndSortedProducts() {
      let filtered = [...this.products];
      
      // Apply search filter
      if (this.search) {
        const searchTerm = this.search.toLowerCase();
        filtered = filtered.filter(product => 
          product.name.toLowerCase().includes(searchTerm) || 
          product.code.toLowerCase().includes(searchTerm) ||
          (product.categoryName && product.categoryName.toLowerCase().includes(searchTerm))
        );
      }
      
      // Apply barcode filter
      if (this.barcodeSearch) {
        filtered = filtered.filter(product => 
          product.barcode && product.barcode.includes(this.barcodeSearch)
        );
      }
      
      // Apply category filter
      if (this.categoryFilter) {
        filtered = filtered.filter(product => product.categoryId === this.categoryFilter);
      }
      
      // Apply quantity filter
      if (this.quantityFilter) {
        switch(this.quantityFilter) {
          case 'low':
            filtered = filtered.filter(product => product.quantity > 0 && product.quantity <= 10);
            break;
          case 'out':
            filtered = filtered.filter(product => product.quantity <= 0);
            break;
          case 'available':
            filtered = filtered.filter(product => product.quantity > 0);
            break;
        }
      }
      
      // Sort products
      filtered.sort((a, b) => {
        let comparison = 0;
        
        switch (this.sortBy) {
          case 'code':
            comparison = a.code.localeCompare(b.code);
            break;
          case 'name':
            comparison = a.name.localeCompare(b.name);
            break;
          case 'purchasePrice':
            comparison = a.purchasePrice - b.purchasePrice;
            break;
          case 'salePrice':
            comparison = a.salePrice - b.salePrice;
            break;
          case 'quantity':
            comparison = a.quantity - b.quantity;
            break;
          default:
            comparison = a.name.localeCompare(b.name);
        }
        
        return this.sortDesc ? -comparison : comparison;
      });
      
      return filtered;
    }
  },
  methods: {
    addProduct() {
      this.$emit('open-modal', 'productAdd');
    },
    
    editProduct(product) {
      this.$emit('open-modal', 'productEdit', product);
    },
    
    viewProduct(product) {
      this.$emit('open-modal', 'productDetails', product);
    },
    
    deleteProduct(productId) {
      this.$emit('delete-item', 'product', productId);
    },
    
    formatCurrency(amount) {
      return parseFloat(amount).toFixed(2) + ' ₼';
    },
    
    getQuantityStatusClass(quantity) {
      if (quantity <= 0) return 'status-critical';
      if (quantity <= 10) return 'status-warning';
      return 'status-normal';
    },
    
    changeSorting(column) {
      if (this.sortBy === column) {
        // Toggle sort direction if already sorting by this column
        this.sortDesc = !this.sortDesc;
      } else {
        // Set new column and default to ascending for most columns
        this.sortBy = column;
        this.sortDesc = false;
      }
    },
    
    applyFilters() {
      this.showFilters = false;
    },
    
    resetFilters() {
      this.categoryFilter = '';
      this.quantityFilter = '';
      this.barcodeSearch = '';
      this.showFilters = false;
    }
  }
};