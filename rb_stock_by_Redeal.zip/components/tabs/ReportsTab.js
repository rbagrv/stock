export default {
  props: ['products', 'sales', 'purchases', 'customers', 'suppliers'],
  data() {
    return {
      activeReport: 'inventory',
      dateRange: {
        start: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10),
        end: new Date().toISOString().slice(0, 10)
      }
    };
  },
  template: `
    <div class="tab-content">
      <h2>Hesabatlar</h2>
      
      <div class="settings-tabs">
        <button 
          :class="{ active: activeReport === 'inventory' }" 
          @click="activeReport = 'inventory'">
          İnventar Hesabatı
        </button>
        <button 
          :class="{ active: activeReport === 'sales' }" 
          @click="activeReport = 'sales'">
          Satış Hesabatı
        </button>
        <button 
          :class="{ active: activeReport === 'purchases' }" 
          @click="activeReport = 'purchases'">
          Alış Hesabatı
        </button>
        <button 
          :class="{ active: activeReport === 'financial' }" 
          @click="activeReport = 'financial'">
          Maliyyə Hesabatı
        </button>
      </div>
      
      <!-- Inventory Report -->
      <div v-if="activeReport === 'inventory'" class="settings-section">
        <div class="card">
          <div class="card-header">
            <h3>İnventar Hesabatı</h3>
            <div class="button-group">
              <button class="btn btn-primary" @click="printReport('inventory')">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                Çap et
              </button>
            </div>
          </div>
          <div class="card-body">
            <div class="dashboard-stats">
              <div class="dash-stat-card primary">
                <div class="dash-stat-icon" v-html="$root.getIconSvg('products')"></div>
                <div class="dash-stat-content">
                  <h3>Ümumi Məhsullar</h3>
                  <div class="dash-stat-value">{{ products.length }}</div>
                </div>
              </div>
              <div class="dash-stat-card success">
                <div class="dash-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                </div>
                <div class="dash-stat-content">
                  <h3>Ümumi Dəyər</h3>
                  <div class="dash-stat-value">{{ totalInventoryValue.toFixed(2) }} ₼</div>
                </div>
              </div>
              <div class="dash-stat-card warning">
                <div class="dash-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                </div>
                <div class="dash-stat-content">
                  <h3>Az Stoklu Məhsullar</h3>
                  <div class="dash-stat-value">{{ lowStockProducts.length }}</div>
                </div>
              </div>
            </div>
            
            <h4 class="mt-4">Az Stoklu Məhsullar</h4>
            <div class="table-responsive">
              <table>
                <thead>
                  <tr>
                    <th>Kod</th>
                    <th>Ad</th>
                    <th>Kateqoriya</th>
                    <th>Stok miqdarı</th>
                    <th>Satış qiyməti</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="product in lowStockProducts" :key="product.id">
                    <td>{{ product.code }}</td>
                    <td>{{ product.name }}</td>
                    <td>{{ product.categoryName || 'Kateqoriyasız' }}</td>
                    <td>{{ product.quantity }} {{ product.unit }}</td>
                    <td>{{ product.salePrice }} ₼</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Sales Report -->
      <div v-if="activeReport === 'sales'" class="settings-section">
        <div class="card">
          <div class="card-header">
            <h3>Satış Hesabatı</h3>
            <div class="date-filter">
              <div class="form-row">
                <div class="form-group">
                  <label>Başlanğıc Tarix</label>
                  <input type="date" v-model="dateRange.start">
                </div>
                <div class="form-group">
                  <label>Son Tarix</label>
                  <input type="date" v-model="dateRange.end">
                </div>
              </div>
            </div>
            <div class="button-group mt-2">
              <button class="btn btn-primary" @click="printReport('sales')">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                Çap et
              </button>
            </div>
          </div>
          <div class="card-body">
            <div class="dashboard-stats">
              <div class="dash-stat-card primary">
                <div class="dash-stat-icon" v-html="$root.getIconSvg('sales')"></div>
                <div class="dash-stat-content">
                  <h3>Ümumi Satışlar</h3>
                  <div class="dash-stat-value">{{ filteredSales.length }}</div>
                </div>
              </div>
              <div class="dash-stat-card success">
                <div class="dash-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                </div>
                <div class="dash-stat-content">
                  <h3>Ümumi Məbləğ</h3>
                  <div class="dash-stat-value">{{ totalSalesAmount.toFixed(2) }} ₼</div>
                </div>
              </div>
            </div>
            
            <h4 class="mt-4">Satışlar</h4>
            <div class="table-responsive">
              <table>
                <thead>
                  <tr>
                    <th>Kod</th>
                    <th>Müştəri</th>
                    <th>Tarix</th>
                    <th>Ödəniş Metodu</th>
                    <th>Ümumi Məbləğ</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="sale in filteredSales" :key="sale.id">
                    <td>{{ sale.code }}</td>
                    <td>{{ sale.customerName || 'Anonim' }}</td>
                    <td>{{ new Date(sale.date).toLocaleDateString() }}</td>
                    <td>{{ sale.paymentMethod }}</td>
                    <td>{{ sale.totalAmount }} ₼</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Purchases Report -->
      <div v-if="activeReport === 'purchases'" class="settings-section">
        <!-- Similar to Sales Report but for Purchases -->
        <div class="card">
          <div class="card-header">
            <h3>Alış Hesabatı</h3>
            <div class="date-filter">
              <div class="form-row">
                <div class="form-group">
                  <label>Başlanğıc Tarix</label>
                  <input type="date" v-model="dateRange.start">
                </div>
                <div class="form-group">
                  <label>Son Tarix</label>
                  <input type="date" v-model="dateRange.end">
                </div>
              </div>
            </div>
            <div class="button-group mt-2">
              <button class="btn btn-primary" @click="printReport('purchases')">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                Çap et
              </button>
            </div>
          </div>
          <div class="card-body">
            <div class="dashboard-stats">
              <div class="dash-stat-card primary">
                <div class="dash-stat-icon" v-html="$root.getIconSvg('purchases')"></div>
                <div class="dash-stat-content">
                  <h3>Ümumi Alışlar</h3>
                  <div class="dash-stat-value">{{ filteredPurchases.length }}</div>
                </div>
              </div>
              <div class="dash-stat-card danger">
                <div class="dash-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                </div>
                <div class="dash-stat-content">
                  <h3>Ümumi Məbləğ</h3>
                  <div class="dash-stat-value">{{ totalPurchasesAmount.toFixed(2) }} ₼</div>
                </div>
              </div>
            </div>
            
            <h4 class="mt-4">Alışlar</h4>
            <div class="table-responsive">
              <table>
                <thead>
                  <tr>
                    <th>Kod</th>
                    <th>Təchizatçı</th>
                    <th>Tarix</th>
                    <th>Ödəniş Metodu</th>
                    <th>Ümumi Məbləğ</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="purchase in filteredPurchases" :key="purchase.id">
                    <td>{{ purchase.code }}</td>
                    <td>{{ purchase.supplierName || '-' }}</td>
                    <td>{{ new Date(purchase.date).toLocaleDateString() }}</td>
                    <td>{{ purchase.paymentMethod }}</td>
                    <td>{{ purchase.totalAmount }} ₼</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Financial Report -->
      <div v-if="activeReport === 'financial'" class="settings-section">
        <div class="card">
          <div class="card-header">
            <h3>Maliyyə Hesabatı</h3>
            <div class="date-filter">
              <div class="form-row">
                <div class="form-group">
                  <label>Başlanğıc Tarix</label>
                  <input type="date" v-model="dateRange.start">
                </div>
                <div class="form-group">
                  <label>Son Tarix</label>
                  <input type="date" v-model="dateRange.end">
                </div>
              </div>
            </div>
            <div class="button-group mt-2">
              <button class="btn btn-primary" @click="printReport('financial')">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                Çap et
              </button>
            </div>
          </div>
          <div class="card-body">
            <div class="dashboard-stats">
              <div class="dash-stat-card success">
                <div class="dash-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
                </div>
                <div class="dash-stat-content">
                  <h3>Ümumi Gəlir</h3>
                  <div class="dash-stat-value">{{ totalSalesAmount.toFixed(2) }} ₼</div>
                </div>
              </div>
              <div class="dash-stat-card danger">
                <div class="dash-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline></svg>
                </div>
                <div class="dash-stat-content">
                  <h3>Ümumi Xərc</h3>
                  <div class="dash-stat-value">{{ totalPurchasesAmount.toFixed(2) }} ₼</div>
                </div>
              </div>
              <div class="dash-stat-card primary">
                <div class="dash-stat-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                </div>
                <div class="dash-stat-content">
                  <h3>Balans</h3>
                  <div class="dash-stat-value">{{ (totalSalesAmount - totalPurchasesAmount).toFixed(2) }} ₼</div>
                </div>
              </div>
            </div>
            
            <div class="chart-card">
              <h4>Gəlir/Xərc Qrafiki</h4>
              <div class="chart-container">
                <canvas id="financialChart" width="400" height="200"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  computed: {
    lowStockProducts() {
      return this.products.filter(product => product.quantity <= 10)
        .sort((a, b) => a.quantity - b.quantity);
    },
    totalInventoryValue() {
      return this.products.reduce((sum, product) => {
        return sum + (product.salePrice * product.quantity);
      }, 0);
    },
    filteredSales() {
      const start = new Date(this.dateRange.start);
      const end = new Date(this.dateRange.end);
      end.setHours(23, 59, 59, 999); // Set to end of day
      
      return this.sales.filter(sale => {
        const saleDate = new Date(sale.date);
        return saleDate >= start && saleDate <= end;
      });
    },
    filteredPurchases() {
      const start = new Date(this.dateRange.start);
      const end = new Date(this.dateRange.end);
      end.setHours(23, 59, 59, 999); // Set to end of day
      
      return this.purchases.filter(purchase => {
        const purchaseDate = new Date(purchase.date);
        return purchaseDate >= start && purchaseDate <= end;
      });
    },
    totalSalesAmount() {
      return this.filteredSales.reduce((sum, sale) => {
        return sum + parseFloat(sale.totalAmount);
      }, 0);
    },
    totalPurchasesAmount() {
      return this.filteredPurchases.reduce((sum, purchase) => {
        return sum + parseFloat(purchase.totalAmount);
      }, 0);
    }
  },
  methods: {
    printReport(reportType) {
      alert(`${reportType} hesabatı çap edilir...`);
      // Actual print functionality would be implemented here
    }
  }
};