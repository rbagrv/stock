export default {
  props: ['customers'],
  data() {
    return {
      search: ''
    };
  },
  template: `
    <div class="tab-content">
      <h2>Alıcılar</h2>
      
      <div class="card">
        <div class="card-header">
          <div class="search-input">
            <input type="text" v-model="search" placeholder="Alıcı axtar..." />
          </div>
          <div class="button-group">
            <button class="add-btn" @click="addCustomer">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"></path></svg>
              Alıcı əlavə et
            </button>
          </div>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Ad</th>
                  <th>Şirkət</th>
                  <th>Telefon</th>
                  <th>Email</th>
                  <th>Ünvan</th>
                  <th>Borc</th>
                  <th>Əməliyyatlar</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="customer in filteredCustomers" :key="customer.id">
                  <td><span class="badge badge-dark">{{ customer.id }}</span></td>
                  <td>{{ customer.name }}</td>
                  <td>{{ customer.company || '-' }}</td>
                  <td>{{ customer.phone || '-' }}</td>
                  <td>{{ customer.email || '-' }}</td>
                  <td>{{ customer.address || '-' }}</td>
                  <td>{{ customer.debt || 0 }} ₼</td>
                  <td>
                    <div class="button-group">
                      <button class="btn-edit" @click="editCustomer(customer)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>
                      </button>
                      <button class="btn-delete" @click="deleteCustomer(customer.id)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <!-- Mobile view -->
      <div class="customers-mobile-cards">
        <div class="customer-card" v-for="customer in filteredCustomers" :key="customer.id">
          <div class="customer-card-header">
            <div class="dashboard-list-icon success-icon">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
            </div>
            <div class="customer-info">
              <h4>{{ customer.name }}</h4>
              <div class="customer-company">{{ customer.company || 'Fərdi' }}</div>
              <div class="customer-id">ID: {{ customer.id }}</div>
            </div>
          </div>
          <div class="customer-card-body">
            <div class="customer-detail" v-if="customer.phone">
              <strong>Telefon:</strong> {{ customer.phone }}
            </div>
            <div class="customer-detail" v-if="customer.email">
              <strong>Email:</strong> {{ customer.email }}
            </div>
            <div class="customer-detail" v-if="customer.address">
              <strong>Ünvan:</strong> {{ customer.address }}
            </div>
            <div class="customer-detail">
              <strong>Borc:</strong> {{ customer.debt || 0 }} ₼
            </div>
          </div>
          <div class="customer-card-footer">
            <button class="btn-edit" @click="editCustomer(customer)">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>
              Düzəliş et
            </button>
            <button class="btn-delete" @click="deleteCustomer(customer.id)">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
              Sil
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  computed: {
    filteredCustomers() {
      if (!this.search) return this.customers || [];
      
      const searchTerm = this.search.toLowerCase();
      return (this.customers || []).filter(customer => {
        return (
          (customer.name && customer.name.toLowerCase().includes(searchTerm)) ||
          (customer.company && customer.company.toLowerCase().includes(searchTerm)) ||
          (customer.phone && customer.phone.includes(searchTerm)) ||
          (customer.email && customer.email.toLowerCase().includes(searchTerm))
        );
      });
    }
  },
  methods: {
    addCustomer() {
      this.$emit('open-modal', 'customerAdd');
    },
    editCustomer(customer) {
      this.$emit('open-modal', 'customerEdit', customer);
    },
    deleteCustomer(customerId) {
      if (confirm('Bu alıcını silmək istədiyinizə əminsiniz?')) {
        this.$emit('delete-item', 'customer', customerId);
      }
    }
  }
};