export default {
  props: ['accounts', 'incomeTransactions', 'expenseTransactions', 'transfers', 'credits'],
  data() {
    return {
      search: '', // Can be used for filtering recent transactions or accounts
      showAllTransactions: false, // Flag to potentially show more transactions
      recentTransactionLimit: 10 // How many recent transactions to show initially
    };
  },
  template: `
    <div class="tab-content">
      <h2>Kassa</h2>

      <!-- Summary Cards -->
      <div class="dashboard-stats cashier-summary">
        <div class="dash-stat-card primary">
          <div class="dash-stat-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
          </div>
          <div class="dash-stat-content">
            <h3>Ümumi Balans</h3>
            <div class="dash-stat-value">{{ formatCurrency(totalBalance) }}</div>
            <div class="dash-stat-info">{{ accounts.length }} hesab</div>
          </div>
        </div>
        <div class="dash-stat-card success">
           <div class="dash-stat-icon">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"></rect><circle cx="12" cy="12" r="2"></circle><path d="M6 12h.01M18 12h.01"></path></svg>
           </div>
           <div class="dash-stat-content">
             <h3>Nağd Balans</h3>
             <div class="dash-stat-value">{{ formatCurrency(cashBalance) }}</div>
           </div>
        </div>
        <div class="dash-stat-card warning">
           <div class="dash-stat-icon">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="2" y1="10" x2="22" y2="10"></line></svg>
           </div>
           <div class="dash-stat-content">
             <h3>Kart Balansı</h3>
             <div class="dash-stat-value">{{ formatCurrency(cardBalance) }}</div>
           </div>
        </div>
        <div class="dash-stat-card info">
           <div class="dash-stat-icon">
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2"></polygon><line x1="12" y1="22" x2="12" y2="15.5"></line><polyline points="22 8.5 12 15.5 2 8.5"></polyline><line x1="2" y1="8.5" x2="22" y2="8.5"></line></svg>
           </div>
           <div class="dash-stat-content">
             <h3>Bank Balansı</h3>
             <div class="dash-stat-value">{{ formatCurrency(bankBalance) }}</div>
           </div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="card quick-actions-card">
        <div class="card-header">
           <h3>Sürətli Əməliyyatlar</h3>
        </div>
        <div class="card-body">
           <div class="button-group cashier-actions">
             <button class="btn btn-success" @click="addIncome">
               <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
               Yeni Gəlir
             </button>
             <button class="btn btn-danger" @click="addExpense">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
               Yeni Xərc
             </button>
             <button class="btn btn-primary" @click="addTransfer">
               <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"></polyline><path d="M3 11V9a4 4 0 0 1 4-4h14"></path><polyline points="7 23 3 19 7 15"></polyline><path d="M21 13v2a4 4 0 0 1-4 4H3"></path></svg>
               Transfer
             </button>
              <button class="btn btn-info" @click="addCreditPayment">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                 Kredit Ödəməsi
              </button>
             <button class="btn btn-secondary" @click="addAccount">
               <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="M6 8h.01M6 16h.01M18 8h.01M18 16h.01"></path></svg>
               Yeni Hesab
             </button>
           </div>
        </div>
      </div>


      <!-- Accounts Section -->
      <div class="card">
        <div class="card-header">
          <h3>Hesablar</h3>
           <div class="search-input-group"> 
              <div class="search-input">
                 <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                 <input type="text" v-model="search" placeholder="Hesab axtar..." />
              </div>
           </div>
        </div>
        <div class="card-body">
          <div class="accounts-grid">
            <div v-for="account in filteredAccounts" :key="account.code" class="account-card">
              <div :class="['account-card-header', account.type]">
                <div class="account-icon">
                   <svg v-if="account.type === 'cash'" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"></rect><circle cx="12" cy="12" r="2"></circle><path d="M6 12h.01M18 12h.01"></path></svg>
                   <svg v-else-if="account.type === 'bank'" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2"></polygon><line x1="12" y1="22" x2="12" y2="15.5"></line><polyline points="22 8.5 12 15.5 2 8.5"></polyline><line x1="2" y1="8.5" x2="22" y2="8.5"></line></svg>
                   <svg v-else-if="account.type === 'card'" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="2" y1="10" x2="22" y2="10"></line></svg>
                   <svg v-else xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/><path d="M6 8h.01M6 16h.01M18 8h.01M18 16h.01"></path></svg>
                </div>
                <div class="account-name">{{ account.name }}</div>
                <span class="badge badge-dark" style="margin-left: auto;">{{ account.code }}</span>
              </div>
              <div class="account-balance">{{ formatCurrency(account.balance) }}</div>
              <div class="account-type-label">{{ getAccountTypeName(account.type) }}</div>
              <div class="account-actions">
                <button class="action-btn edit-btn" @click="editAccount(account)" title="Düzəliş et"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg></button>
                <button class="action-btn delete-btn" @click="deleteAccount(account.code)" title="Sil"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6"/></svg></button>
              </div>
            </div>
          </div>
          <div class="empty-state" v-if="!filteredAccounts || filteredAccounts.length === 0">
             <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/><path d="M6 8h.01M6 16h.01M18 8h.01M18 16h.01"></path></svg>
             <p>Heç bir hesab tapılmadı.</p>
          </div>
        </div>
      </div>

      <!-- Recent Transactions Section -->
      <div class="card">
        <div class="card-header">
          <h3>Son Əməliyyatlar</h3>
           <div class="search-input-group">
              <div class="search-input">
                 <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                 <input type="text" v-model="search" placeholder="Əməliyyat axtar..." />
              </div>
           </div>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Tarix</th>
                  <th>Tip</th>
                  <th>Məbləğ</th>
                  <th>Hesab</th>
                  <th>Əlavə Məlumat</th>
                  <th>Təsvir</th>
                  <th>Əməliyyatlar</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="transaction in recentTransactions" :key="transaction.id">
                  <td><span class="badge badge-dark">{{ transaction.id || 'N/A' }}</span></td>
                  <td>{{ formatDateTime(transaction.date) }}</td>
                  <td>
                     <span :class="getTransactionTypeClass(transaction.type)">
                        {{ getTransactionTypeLabel(transaction.type) }}
                     </span>
                  </td>
                  <td class="text-right">{{ formatCurrency(transaction.amount) }}</td>
                  <td>{{ getAccountName(transaction.accountId) }}</td>
                  <td>
                      <span v-if="transaction.type === 'transfer'">{{ getAccountName(transaction.toAccountId) }}</span>
                      <span v-else-if="transaction.type === 'income' && transaction.customerId">{{ getCustomerName(transaction.customerId) }} ({{ transaction.category || 'Gəlir' }})</span>
                      <span v-else-if="transaction.type === 'credit'">{{ getCustomerName(transaction.customerId) }}</span>
                      <span v-else>{{ transaction.category || '-' }}</span>
                  </td>
                  <td>{{ transaction.description || '-' }}</td>
                  <td>
                      <div class="button-group">
                          <button class="action-btn view-btn" @click="viewTransactionDetails(transaction)" title="Ətraflı bax">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                          </button>
                          <button v-if="['income', 'expense'].includes(transaction.type)" class="action-btn edit-btn" @click="editTransaction(transaction)" title="Düzəliş et">
                              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg>
                          </button>
                          <button class="action-btn delete-btn" @click="deleteTransaction(transaction.id, transaction.type)" title="Sil">
                              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6"/></svg>
                          </button>
                      </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="empty-state" v-if="!recentTransactions || recentTransactions.length === 0">
             <p>Heç bir əməliyyat tapılmadı.</p>
          </div>
           <div class="text-center mt-3" v-if="allTransactions.length > recentTransactionLimit && !showAllTransactions">
                <button class="btn btn-secondary" @click="showAllTransactions = true">Daha Çox Göstər</button>
           </div>
           <div class="text-center mt-3" v-if="showAllTransactions">
                <button class="btn btn-secondary" @click="showAllTransactions = false">Az Göstər</button>
           </div>
        </div>
      </div>

    </div>
  `,
  computed: {
    allTransactions() {
      const combined = [
        ...(this.incomeTransactions || []),
        ...(this.expenseTransactions || []),
        ...(this.transfers || []),
        ...(this.credits || [])
      ];
      return combined.sort((a, b) => new Date(b.date) - new Date(a.date));
    },
    filteredTransactions() {
        if (!this.search) {
            return this.allTransactions;
        }
        const searchTerm = this.search.toLowerCase();
        return this.allTransactions.filter(t =>
            (this.getTransactionTypeLabel(t.type)?.toLowerCase().includes(searchTerm)) ||
            (this.getAccountName(t.accountId)?.toLowerCase().includes(searchTerm)) ||
            (t.type === 'transfer' && this.getAccountName(t.toAccountId)?.toLowerCase().includes(searchTerm)) ||
            (['income', 'credit'].includes(t.type) && this.getCustomerName(t.customerId)?.toLowerCase().includes(searchTerm)) ||
            (t.category && t.category.toLowerCase().includes(searchTerm)) ||
            (t.description && t.description.toLowerCase().includes(searchTerm)) ||
            (t.id && t.id.toString().toLowerCase().includes(searchTerm)) ||
             (t.reference && t.reference.toLowerCase().includes(searchTerm))
        );
    },
    recentTransactions() {
       return this.showAllTransactions ? this.filteredTransactions : this.filteredTransactions.slice(0, this.recentTransactionLimit);
    },
    filteredAccounts() {
        if (!Array.isArray(this.accounts)) return [];
        const cashTypes = ['cash', 'bank', 'card'];
        let accounts = this.accounts.filter(acc => cashTypes.includes(acc.type));

        if (this.search) {
            const searchTerm = this.search.toLowerCase();
            accounts = accounts.filter(acc =>
                (acc.name && acc.name.toLowerCase().includes(searchTerm)) ||
                (acc.code && acc.code.toLowerCase().includes(searchTerm))
            );
        }
        return accounts.sort((a, b) => a.name.localeCompare(b.name)); 
    },
    totalBalance() {
      return (this.accounts || []).reduce((sum, acc) => sum + (parseFloat(acc.balance) || 0), 0);
    },
    cashBalance() {
      return (this.accounts || [])
        .filter(acc => acc.type === 'cash')
        .reduce((sum, acc) => sum + (parseFloat(acc.balance) || 0), 0);
    },
    bankBalance() {
      return (this.accounts || [])
        .filter(acc => acc.type === 'bank')
        .reduce((sum, acc) => sum + (parseFloat(acc.balance) || 0), 0);
    },
    cardBalance() {
      return (this.accounts || [])
        .filter(acc => acc.type === 'card')
        .reduce((sum, acc) => sum + (parseFloat(acc.balance) || 0), 0);
    },
  },
  methods: {
    formatCurrency(amount) { return this.$root.formatCurrency(amount); },
    formatDateTime(dateString) { return this.$root.formatDateTime(dateString); },
    getAccountName(accountCodeOrId) { return this.$root.getAccountName(accountCodeOrId); },
    getCustomerName(customerId) { return this.$root.getCustomerName(customerId); },
    getTransactionTypeLabel(type) { return this.$root.getItemTypeLabel(type); },
    getTransactionTypeClass(type) { return this.$root.getTransactionTypeClass(type); },

    addAccount() { this.$emit('open-modal', 'accountAdd'); },
    editAccount(account) { this.$emit('open-modal', 'accountEdit', account); },
    deleteAccount(accountCode) { this.$emit('delete-item', 'account', accountCode); },
    addIncome() { this.$emit('open-modal', 'incomeAdd'); },
    addExpense() { this.$emit('open-modal', 'expenseAdd'); },
    addTransfer() { this.$emit('open-modal', 'transferAdd'); },
    addCreditPayment() { this.$emit('open-modal', 'creditAdd'); },
    editTransaction(transaction) {
      const modalType = transaction.type === 'income' ? 'incomeEdit'
                       : transaction.type === 'expense' ? 'expenseEdit'
                       : null; 
      if (modalType) {
          this.$emit('open-modal', modalType, transaction);
      } else {
          this.$root.showNotification('info', 'Mümkün deyil', 'Bu əməliyyat növü redaktə edilə bilməz.');
      }
    },
    viewTransactionDetails(transaction) {
       this.$emit('open-modal', 'transactionDetails', transaction);
    },
    deleteTransaction(id, type) {
      if (!id || !type) {
          console.error('Invalid ID or type for deletion:', id, type);
          this.$root.showNotification('error', 'Xəta', 'Silinəcək elementin ID və ya tipi düzgün deyil.');
          return;
      }
      this.$emit('delete-item', type, id);
    },
    getAccountTypeName(typeId) {
       const types = {
         cash: 'Nağd pul', bank: 'Bank', card: 'Kart',
         asset: 'Aktiv', liability: 'Passiv', equity: 'Kapital',
         income: 'Gəlir', expense: 'Xərc'
       };
       return types[typeId] || typeId;
    },
  }
};