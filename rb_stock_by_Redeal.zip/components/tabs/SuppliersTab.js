export default {
  props: ['suppliers'],
  data() {
    return {
      search: ''
    };
  },
  template: `
    <div class="tab-content">
      <h2>Təchizatçılar</h2>
      
      <div class="card">
        <div class="card-header">
          <div class="search-input">
            <input type="text" v-model="search" placeholder="Təchizatçı axtar..." />
          </div>
          <div class="button-group">
            <button class="add-btn" @click="addSupplier">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"></path></svg>
              Təchizatçı əlavə et
            </button>
          </div>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Şirkət</th>
                  <th>Əlaqə şəxsi</th>
                  <th>Telefon</th>
                  <th>Email</th>
                  <th>Ünvan</th>
                  <th>Kateqoriya</th>
                  <th>Əməliyyatlar</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="supplier in filteredSuppliers" :key="supplier.id">
                  <td><span class="badge badge-dark">{{ supplier.id }}</span></td>
                  <td>{{ supplier.company }}</td>
                  <td>{{ supplier.contact || '-' }}</td>
                  <td>{{ supplier.phone || '-' }}</td>
                  <td>{{ supplier.email || '-' }}</td>
                  <td>{{ supplier.address || '-' }}</td>
                  <td>{{ supplier.category || '-' }}</td>
                  <td>
                    <div class="button-group">
                      <button class="btn-edit" @click="editSupplier(supplier)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"></path><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"></polygon></svg>
                      </button>
                      <button class="btn-delete" @click="deleteSupplier(supplier.id)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
  computed: {
    filteredSuppliers() {
      if (!this.search) return this.suppliers || [];
      
      const searchTerm = this.search.toLowerCase();
      return (this.suppliers || []).filter(supplier => {
        return (
          (supplier.company && supplier.company.toLowerCase().includes(searchTerm)) ||
          (supplier.contact && supplier.contact.toLowerCase().includes(searchTerm)) ||
          (supplier.phone && supplier.phone.includes(searchTerm)) ||
          (supplier.email && supplier.email.toLowerCase().includes(searchTerm)) ||
          (supplier.category && supplier.category.toLowerCase().includes(searchTerm))
        );
      });
    }
  },
  methods: {
    addSupplier() {
      this.$emit('open-modal', 'supplierAdd');
    },
    editSupplier(supplier) {
      this.$emit('open-modal', 'supplierEdit', supplier);
    },
    deleteSupplier(supplierId) {
      if (confirm('Bu təchizatçını silmək istədiyinizə əminsiniz?')) {
        this.$emit('delete-item', 'supplier', supplierId);
      }
    }
  }
};