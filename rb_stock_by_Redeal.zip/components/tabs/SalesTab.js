// Placeholder SalesTab component
export default {
  props: ['sales', 'customers'], // Example props
  data() {
    return {
      search: '',
    };
  },
  template: `
    <div class="tab-content">
      <h2>Satışlar</h2>
       <div class="card">
         <div class="card-header">
           <div class="search-input-group">
             <div class="search-input">
               <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
               <input type="text" v-model="search" placeholder="Satış axtar (Kod, Müştəri)..." />
             </div>
           </div>
           <div class="button-group">
             <button class="add-btn" @click="addSale">
               <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
               Yeni Satış
             </button>
           </div>
         </div>
         <div class="card-body">
           <div class="table-responsive">
             <table>
               <thead>
                 <tr>
                   <th>Kod</th>
                   <th>Müştəri</th>
                   <th>Tarix</th>
                   <th>Ödəniş Metodu</th>
                   <th>Ümumi Məbləğ</th>
                   <th>Əməliyyatlar</th>
                 </tr>
               </thead>
               <tbody>
                 <tr v-for="sale in filteredSales" :key="sale.id">
                   <td><span class="badge badge-primary">{{ sale.code || sale.id }}</span></td>
                   <td class="customer-cell">
                      <svg class="customer-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="7" r="4"/><path d="M5.5 22a8.38 8.38 0 0 1 13 0"/></svg>
                     {{ getCustomerName(sale.customerId) }}
                   </td>
                   <td class="date-cell">
                     <span class="date">{{ formatDate(sale.date) }}</span>
                     <span class="time">{{ formatTime(sale.date) }}</span>
                   </td>
                   <td>
                      <span :class="['payment-method', sale.paymentMethod]">
                          {{ getPaymentMethodLabel(sale.paymentMethod) }}
                      </span>
                   </td>
                   <td class="amount-cell text-right">{{ formatCurrency(sale.totalAmount) }}</td>
                   <td>
                     <div class="button-group">
                        <button class="action-btn view-btn" @click="viewSaleDetails(sale)" title="Ətraflı bax"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></button>
                        <button class="action-btn edit-btn" @click="editSale(sale)" title="Düzəliş et"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg></button>
                        <button class="action-btn delete-btn" @click="deleteSale(sale.id)" title="Sil"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6"/></svg></button>
                     </div>
                   </td>
                 </tr>
               </tbody>
             </table>
             <div class="empty-state" v-if="!filteredSales || filteredSales.length === 0">
                <p>Heç bir satış tapılmadı.</p>
             </div>
           </div>
         </div>
       </div>
    </div>
  `,
  computed: {
    filteredSales() {
        if (!Array.isArray(this.sales)) return [];
        let filtered = [...this.sales];

        if (this.search) {
            const searchTerm = this.search.toLowerCase();
            filtered = filtered.filter(sale => {
                 const customerName = this.getCustomerName(sale.customerId) || '';
                 return (
                     (sale.code && sale.code.toLowerCase().includes(searchTerm)) ||
                     (customerName.toLowerCase().includes(searchTerm)) ||
                     (sale.id && sale.id.toString().includes(searchTerm))
                 );
            });
        }
        return filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    }
  },
  methods: {
    formatCurrency(amount) { return this.$root.formatCurrency(amount); },
    formatDate(dateString) {
        if (!dateString) return '-';
        try { return new Date(dateString).toLocaleDateString('az-AZ'); }
        catch(e) { return '-'; }
    },
    formatTime(dateString) {
        if (!dateString) return '';
        try { return new Date(dateString).toLocaleTimeString('az-AZ', { hour: '2-digit', minute: '2-digit'}); }
        catch(e) { return ''; }
    },
    getCustomerName(customerId) { return this.$root.getCustomerName(customerId); },
    getPaymentMethodLabel(method) { return this.$root.getPaymentMethodLabel(method); },
    addSale() { this.$emit('open-modal', 'saleAdd'); },
    viewSaleDetails(sale) { this.$emit('open-modal', 'saleDetails', sale); },
    editSale(sale) { this.$emit('open-modal', 'saleEdit', sale); },
    deleteSale(saleId) { this.$emit('delete-item', 'sale', saleId); }
  }
};