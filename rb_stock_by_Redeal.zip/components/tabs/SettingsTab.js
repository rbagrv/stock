export default {
  props: ['settings'],
  emits: ['open-modal', 'delete-item', 'settings-updated', 'save-item'],
  data() {
    return {
      activeSettingsTab: 'general',
      localSettings: {
        general: {}, 
        invoices: {}, 
        taxes: {}, 
        backup: {}, 
        appearance: {}, 
        accounts: {}, 
        email: {}
      },
      logoPreview: null,
      accountTypes: [
        { id: 'asset', name: 'Aktiv' }, 
        { id: 'liability', name: 'Passiv' },
        { id: 'equity', name: 'Kapital' }, 
        { id: 'income', name: 'Gəlir' },
        { id: 'expense', name: 'Xərc' },
        { id: 'cash', name: 'Nağd pul' },
        { id: 'bank', name: 'Bank hesabı' },
        { id: 'card', name: 'Kart hesabı' },
      ],
      defaultMappings: {
        customer_receivable: '', 
        supplier_payable: '', 
        inventory: '',
        sales_revenue: '', 
        cost_of_goods: '', 
        cash: '', 
        bank: '', 
        capital: '',
      },
      taxTypes: [
        { id: 'vat', name: 'ƏDV (Əlavə Dəyər Vergisi)' }, 
        { id: 'income_tax', name: 'Gəlir Vergisi' },
        { id: 'simplified_tax', name: 'Sadələşdirilmiş Vergi' },
        { id: 'social_security', name: 'Sosial Sığorta Haqqı' },
        { id: 'property_tax', name: 'Əmlak Vergisi' },
        { id: 'other', name: 'Digər Vergilər' }
      ],
      emailTestStatus: null,
      testNotificationMessage: 'Bu bir test bildirişidir!',
      accountSearch: '',
      emailConfig: {
        smtp: {
          host: '',
          port: 587,
          secure: false,
          username: '',
          password: '',
          fromEmail: '',
          fromName: ''
        },
        templates: {
          passwordReset: {
            subject: 'Şifrə Bərpası',
            body: 'Şifrənizi bərpa etmək üçün keçid: {resetLink}'
          },
          transactionReceipt: {
            subject: 'Əməliyyat Qəbzi',
            body: 'Əməliyyat qəbzi əlavə edilib: {transactionDetails}'
          }
        },
        notifications: {
          passwordReset: true,
          transactionReceipt: true,
          lowStock: true,
          dailySummary: false
        }
      }
    };
  },
  mounted() {
    if (this.settings?.email) {
      this.emailConfig = {
        ...this.emailConfig,
        ...this.settings.email
      };
    }
  },
  watch: {
    settings: {
      handler(newSettings) {
        const currentSettings = newSettings || {};
        this.localSettings = {
          general: { ...(currentSettings.general || {}) },
          invoices: { ...(currentSettings.invoices || {}) },
          taxes: { ...(currentSettings.taxes || {}) },
          backup: { ...(currentSettings.backup || {}) },
          appearance: { ...(currentSettings.appearance || {}) },
          accounts: { ...(currentSettings.accounts || {}) },
          email: { ...(currentSettings.email || {}) }
        };

        this.logoPreview = this.localSettings.general?.logo || null;
        this.defaultMappings = {
          customer_receivable: '', 
          supplier_payable: '', 
          inventory: '',
          sales_revenue: '', 
          cost_of_goods: '', 
          cash: '', 
          bank: '', 
          capital: '',
          ...(this.localSettings.accounts?.defaultMappings || {})
        };
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    saveSettings(section) {
      if (!this.localSettings[section]) {
        this.localSettings[section] = {}; 
      }
      this.$emit('settings-updated', { section, data: this.localSettings[section] });
    },
    saveAccountSettings() {
      this.$emit('settings-updated', { section: 'accounts', data: { defaultMappings: this.defaultMappings } });
    },
    getSectionLabel(section) {
      const labels = {
        general: 'Ümumi', 
        invoices: 'Faktura', 
        taxes: 'Vergi',
        categories: 'Kateqoriya', 
        accounting: 'Hesablar Planı/Təyinatlar',
        backup: 'Yedəkləmə', 
        appearance: 'Görünüş',
        email: 'Email Parametrləri'
      };
      return labels[section] || section;
    },
    formatCurrency(amount) {
      if (amount === null || amount === undefined || isNaN(parseFloat(amount))) return '0.00 ₼';
      return parseFloat(amount).toFixed(2) + ' ₼';
    },
    triggerLogoUpload() { 
      document.getElementById('companyLogo').click(); 
    },
    handleLogoUpload(event) {
      const file = event.target.files[0];
      if (!file) return;
      if (!file.type.match('image.*')) { 
        this.$root.showNotification('error', 'Xəta', 'Yalnız şəkil faylları yükləyə bilərsiniz'); 
        return; 
      }
      if (file.size > 2 * 1024 * 1024) { 
        this.$root.showNotification('error', 'Xəta', 'Şəkil faylının ölçüsü 2MB-dan böyük olmamalıdır'); 
        return; 
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        this.logoPreview = e.target.result;
        if (!this.localSettings.general) this.localSettings.general = {};
        this.localSettings.general.logo = e.target.result;
        this.saveSettings('general'); 
      };
      reader.readAsDataURL(file);
    },
    removeLogo() {
      this.logoPreview = null;
      if (this.localSettings.general) this.localSettings.general.logo = null;
      this.saveSettings('general'); 
    },
    addCategory() { 
      this.$emit('open-modal', 'categoryAdd'); 
    },
    editCategory(category) { 
      this.$emit('open-modal', 'categoryEdit', category); 
    },
    deleteCategory(categoryId) { 
      this.$emit('delete-item', 'category', categoryId); 
    },
    addAccount() { 
      this.$emit('open-modal', 'accountAdd'); 
    },
    editAccount(account) { 
      this.$emit('open-modal', 'accountEdit', account); 
    },
    deleteAccount(accountCode) {
      const isUsed = Object.values(this.defaultMappings || {}).includes(accountCode);
      if (isUsed) {
        this.$root.showNotification('error', 'Xəta', 'Bu hesab əməliyyat təyinatında istifadə olunur, silmək mümkün deyil.'); 
        return;
      }
      const hasSubAccounts = this.$root.accounts?.some(acc => acc.parentId === accountCode);
      if (hasSubAccounts) {
        this.$root.showDialog({
          title: 'Silmə Mümkün Deyil',
          message: `Bu hesabın (${accountCode}) sub-hesabları var. Əvvəlcə sub-hesabları silin və ya başqa hesaba təyin edin.`,
          confirmText: 'OK',
          showCancelButton: false 
        });
        return;
      }
      this.$emit('delete-item', 'account', accountCode); 
    },
    filteredAccountsByType(generalType = null, specificTypes = null) {
      return this.$root.filteredAccountsByType(generalType, specificTypes);
    },
    getAccountTypeName(type) { 
      const t = this.accountTypes.find(t => t.id === type); 
      return t ? t.name : type; 
    },
    async backupData() {
      this.$root.isLoading = true;
      try {
        const backupObject = {
          settings: await dbService.getSettings(),
          products: await dbService.getAllLocal('products'),
          categories: await dbService.getAllLocal('categories'),
          customers: await dbService.getAllLocal('customers'),
          suppliers: await dbService.getAllLocal('suppliers'),
          sales: await dbService.getAllLocal('sales'),
          purchases: await dbService.getAllLocal('purchases'),
          operations: await dbService.getAllLocal('operations'),
          productions: await dbService.getAllLocal('productions'),
          accounts: await dbService.getAllLocal('accounts'),
          transactions: await dbService.getAllLocal('transactions'),
          users: await dbService.getAllLocal('users'),
          timestamp: new Date().toISOString()
        };
        const backupJson = JSON.stringify(backupObject, null, 2);
        const blob = new Blob([backupJson], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `anbar_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        this.$root.showNotification('success', 'Yedəkləmə Uğurlu', 'Verilənlər bazasının yedəyi endirildi.');
      } catch (error) {
        console.error("Backup error:", error);
        this.$root.showNotification('error', 'Yedəkləmə Xətası', 'Yedək çıxarılarkən xəta baş verdi.');
      } finally {
        this.$root.isLoading = false;
      }
    },
    handleRestore(event) { 
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const backupData = JSON.parse(e.target.result);

          if (!backupData || !backupData.timestamp) {
            throw new Error("Yedək faylı düzgün formatda deyil.");
          }
          this.$root.showDialog({
            title: 'Yedəkdən Bərpa',
            message: `Yedək faylı (${new Date(backupData.timestamp).toLocaleString()}) yükləndi. Cari məlumatları bu yedəklə əvəzləmək istədiyinizə əminsiniz? Bu əməliyyat geri qaytarılmaz! TƏTBİQ YENİLƏNƏCƏK.`,
            confirmText: 'Bəli, Bərpa Et',
            confirmButtonClass: 'btn-danger',
            onConfirm: async () => {
              this.$root.isLoading = true; 
              try {
                await dbService.ensureDB(); 

                for (const storeName of dbService.stores) {
                  if (storeName !== 'sync') { 
                    console.log(`Clearing ${storeName}`);
                    const tx = dbService.db.transaction(storeName, 'readwrite');
                    await tx.objectStore(storeName).clear();
                  }
                }
                localStorage.clear(); 
                console.log("Local stores and localStorage cleared.");

                if (backupData.settings) {
                  for (const section in backupData.settings) {
                    await dbService.saveSettings(section, backupData.settings[section]);
                  }
                  console.log("Settings restored.");
                }

                const storesToRestore = ['products', 'categories', 'customers', 'suppliers', 'sales', 'purchases', 'operations', 'productions', 'accounts', 'transactions', 'users'];
                for (const storeName of storesToRestore) {
                  if (backupData[storeName]) {
                    await dbService.updateLocalStore(storeName, backupData[storeName]);
                    console.log(`Restored ${backupData[storeName].length} items to ${storeName}`);
                  } else {
                    console.log(`No data found for ${storeName} in backup.`);
                  }
                }

                this.$root.showNotification('success', 'Bərpa Uğurlu', 'Məlumatlar bərpa edildi. Səhifə yenilənir...');
                setTimeout(() => window.location.reload(), 2500);

              } catch (restoreError) {
                console.error("Restore error:", restoreError);
                this.$root.showNotification('error', 'Bərpa Xətası', `Bərpa zamanı xəta baş verdi: ${restoreError.message}`);
                this.$root.isLoading = false; 
              }
            }
          });
        } catch (parseError) {
          console.error("Error parsing restore file:", parseError);
          this.$root.showNotification('error', 'Fayl Xətası', 'Yedək faylını oxumaq mümkün olmadı. Format düzgün deyil.');
        } finally {
          event.target.value = null; 
        }
      };
      reader.readAsText(file);
    },
    async testEmailConnection() {
      this.emailTestStatus = null;
      try {
        const response = await fetch('/api/email/test', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(this.emailConfig.smtp)
        });

        if (response.ok) {
          this.emailTestStatus = {
            type: 'success', 
            message: 'SMTP bağlantısı uğurlu oldu!'
          };
        } else {
          const errorData = await response.json();
          this.emailTestStatus = {
            type: 'error', 
            message: errorData.message || 'SMTP bağlantısı uğursuz oldu.'
          };
        }
      } catch (error) {
        this.emailTestStatus = {
          type: 'error', 
          message: 'SMTP bağlantısı zamanı xəta baş verdi.'
        };
        console.error('Email test error:', error);
      }
    },
    async saveEmailSettings() {
      try {
        await this.$emit('settings-updated', {
          section: 'email', 
          data: this.emailConfig
        });
        this.$root.showNotification('success', 'Parametrlər', 'Email parametrləri uğurla saxlanıldı.');
      } catch (error) {
        this.$root.showNotification('error', 'Xəta', 'Email parametrləri saxlanılarkən xəta baş verdi.');
        console.error('Save email settings error:', error);
      }
    },
    toggleEmailSetting(settingKey) {
      this.emailConfig.notifications[settingKey] = !this.emailConfig.notifications[settingKey];
    },
    async sendTestEmail() {
      const testEmail = prompt("Test emaili göndərmək üçün email ünvanını daxil edin:", "");
      if (!testEmail) return; 

      this.$root.isLoading = true; 
      this.emailTestStatus = null; 

      try {
        const response = await fetch(`${config.API_URL}/email/send-test`, { 
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            smtpConfig: this.emailConfig.smtp, 
            to: testEmail
          })
        });

        if (!response.ok) {
            let errorMsg = 'Server xətası';
            try {
                 const errorData = await response.json();
                 errorMsg = errorData.message || `Server xətası: ${response.status}`;
            } catch(e) {
                 errorMsg = `Server xətası: ${response.status}`;
                 console.warn("Could not parse error response from /api/email/send-test");
            }
            throw new Error(errorMsg);
        }

        this.$root.showNotification('success', 'Test Email', `${testEmail} ünvanına test email uğurla göndərildi.`);
      } catch (error) {
        console.error('Test email error:', error);
        this.$root.showNotification('error', 'Xəta', `Test email göndərilmədi: ${error.message}`);
      } finally {
        this.$root.isLoading = false; 
      }
    },
    triggerTestNotification(type) {
      const titleMap = {
        success: 'Uğurlu Test',
        error: 'Xəta Testi',
        warning: 'Xəbərdarlıq Testi',
        info: 'Məlumat Testi'
      };
      this.$root.showNotification(type, titleMap[type], this.testNotificationMessage || `Bu ${type} tipli test bildirişidir.`);
    },
    editAccountProxy(code) {
      const account = this.$root.accounts?.find(acc => acc.code === code);
      if (account) this.editAccount(account);
    },
    deleteAccountProxy(code) {
      this.deleteAccount(code);
    }
  },
  template: `
    <div class="tab-content">
      <h2>Parametrlər</h2>

      <div class="settings-tabs">
        <button :class="{ active: activeSettingsTab === 'general' }" @click="activeSettingsTab = 'general'">Ümumi</button>
        <button :class="{ active: activeSettingsTab === 'invoices' }" @click="activeSettingsTab = 'invoices'">Fakturalar</button>
        <button :class="{ active: activeSettingsTab === 'taxes' }" @click="activeSettingsTab = 'taxes'">Vergilər</button>
        <button :class="{ active: activeSettingsTab === 'categories' }" @click="activeSettingsTab = 'categories'">Kateqoriyalar</button>
        <button :class="{ active: activeSettingsTab === 'accounting' }" @click="activeSettingsTab = 'accounting'">Hesablar Planı/Təyinatlar</button>
        <button :class="{ active: activeSettingsTab === 'backup' }" @click="activeSettingsTab = 'backup'">Yedəkləmə</button>
        <button :class="{ active: activeSettingsTab === 'email' }" @click="activeSettingsTab = 'email'">Email Parametrləri</button>
        <button :class="{ active: activeSettingsTab === 'notifications' }" @click="activeSettingsTab = 'notifications'">Bildiriş Test</button> 
      </div>

      <!-- General Settings -->
      <div v-if="activeSettingsTab === 'general' && localSettings.general" class="settings-section">
        <div class="card">
          <div class="card-header"><h3>Ümumi Parametrlər</h3></div>
          <div class="card-body">
            <!-- Logo Upload -->
            <div class="form-group">
              <label for="companyLogo">Şirkət Loqosu</label>
              <div class="logo-upload-container">
                <div v-if="logoPreview || localSettings.general.logo" class="company-logo-preview">
                  <img :src="logoPreview || localSettings.general.logo" alt="Şirkət Loqosu">
                  <button class="btn-delete" @click="removeLogo">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <input type="file" id="companyLogo" @change="handleLogoUpload" accept="image/*" style="display: none;">
                <button class="btn btn-secondary" @click="triggerLogoUpload">Loqo yüklə</button>
              </div>
            </div>
            <!-- Other General Settings -->
            <div class="form-group"> <label for="companyName">Şirkət Adı</label> <input type="text" id="companyName" v-model="localSettings.general.companyName"> </div>
            <div class="form-row"> <div class="form-group"> <label for="phone">Telefon</label> <input type="text" id="phone" v-model="localSettings.general.phone"> </div> <div class="form-group"> <label for="email">E-mail</label> <input type="email" id="email" v-model="localSettings.general.email"> </div> </div>
            <div class="form-group"> <label for="address">Ünvan</label> <textarea id="address" v-model="localSettings.general.address"></textarea> </div>
            <div class="form-row"> <div class="form-group"> <label for="currency">Valyuta</label> <select id="currency" v-model="localSettings.general.currency"> <option value="AZN">Manat (AZN)</option> <option value="USD">Dollar (USD)</option> <option value="EUR">Avro (EUR)</option> <option value="TRY">Türkiyə Lirası (TRY)</option> </select> </div> <div class="form-group"> <label for="language">Dil</label> <select id="language" v-model="localSettings.general.language"> <option value="az">Azərbaycan dili</option> <option value="en" disabled>İngilis dili (gələcəkdə)</option> <option value="ru" disabled>Rus dili (gələcəkdə)</option> <option value="tr" disabled>Türkiyə dili (gələcəkdə)</option> </select> </div> </div>
            <div class="form-group"> <button class="btn btn-primary" @click="saveSettings('general')">Yadda saxla</button> </div>
          </div>
        </div>
      </div>

      <!-- Invoices Settings -->
      <div v-if="activeSettingsTab === 'invoices' && localSettings.invoices" class="settings-section">
        <div class="card">
          <div class="card-header"><h3>Faktura Parametrləri</h3></div>
          <div class="card-body">
            <div class="form-group"> <label for="invoicePrefix">Faktura Prefiksi</label> <input type="text" id="invoicePrefix" v-model="localSettings.invoices.invoicePrefix"> </div>
            <div class="form-group"> <label><input type="checkbox" v-model="localSettings.invoices.showLogo"> Fakturada loqo göstər</label> </div>
            <div class="form-group"> <label><input type="checkbox" v-model="localSettings.invoices.showTaxes"> Fakturada vergiləri göstər</label> </div>
            <div class="form-group"> <label for="termsAndConditions">Şərtlər və qaydalar</label> <textarea id="termsAndConditions" v-model="localSettings.invoices.termsAndConditions"></textarea> </div>
            <div class="form-group"> <label for="footerText">Altlıq mətni</label> <textarea id="footerText" v-model="localSettings.invoices.footerText"></textarea> </div>
            <div class="form-group"> <button class="btn btn-primary" @click="saveSettings('invoices')">Yadda saxla</button> </div>
          </div>
        </div>
      </div>

      <!-- Taxes Settings -->
      <div v-if="activeSettingsTab === 'taxes' && localSettings.taxes" class="settings-section">
        <div class="card">
          <div class="card-header"><h3>Vergi Parametrləri</h3></div>
          <div class="card-body">
            <h4>1. Aktiv Vergi Növləri</h4>
            <div class="form-group permissions-list">
              <div v-for="tax in taxTypes" :key="tax.id" class="permission-item">
                <input type="checkbox" :id="'tax_' + tax.id" :value="tax.id" v-model="localSettings.taxes.enabledTaxes">
                <label :for="'tax_' + tax.id">{{ tax.name }}</label>
              </div>
            </div>

            <h4>2. Vergi Dərəcələri (%)</h4>
            <div class="form-row">
              <div class="form-group" v-if="localSettings.taxes.enabledTaxes.includes('vat')">
                <label for="taxRateVat">ƏDV Dərəcəsi</label>
                <input type="number" id="taxRateVat" v-model.number="localSettings.taxes.rates.vat" min="0" step="0.1">
              </div>
              <div class="form-group" v-if="localSettings.taxes.enabledTaxes.includes('income_tax')">
                <label for="taxRateIncome">Gəlir Vergisi Dərəcəsi</label>
                <input type="number" id="taxRateIncome" v-model.number="localSettings.taxes.rates.income_tax" min="0" step="0.1">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group" v-if="localSettings.taxes.enabledTaxes.includes('simplified_tax')"> 
                <label for="taxRateSimpTurnover">Sadələşdirilmiş (Dövriyyə)</label> 
                <input type="number" id="taxRateSimpTurnover" v-model.number="localSettings.taxes.rates.simplified_turnover" min="0" step="0.1"> 
              </div>
              <div class="form-group" v-if="localSettings.taxes.enabledTaxes.includes('simplified_tax')"> 
                <label for="taxRateSimpProfit">Sadələşdirilmiş (Mənfəət)</label> 
                <input type="number" id="taxRateSimpProfit" v-model.number="localSettings.taxes.rates.simplified_profit" min="0" step="0.1"> 
              </div>
            </div>
            <div class="form-row">
              <div class="form-group" v-if="localSettings.taxes.enabledTaxes.includes('social_security')"> 
                <label for="taxRateSocialEmployer">Sosial Sığorta (İşəgötürən)</label> 
                <input type="number" id="taxRateSocialEmployer" v-model.number="localSettings.taxes.rates.social_employer" min="0" step="0.1"> 
              </div>
              <div class="form-group" v-if="localSettings.taxes.enabledTaxes.includes('social_security')"> 
                <label for="taxRateSocialEmployee">Sosial Sığorta (İşçi)</label> 
                <input type="number" id="taxRateSocialEmployee" v-model.number="localSettings.taxes.rates.social_employee" min="0" step="0.1"> 
              </div>
            </div>
            <div class="form-group" v-if="localSettings.taxes.enabledTaxes.includes('property_tax')"> 
              <label for="taxRateProperty">Əmlak Vergisi Dərəcəsi</label> 
              <input type="number" id="taxRateProperty" v-model.number="localSettings.taxes.rates.property" min="0" step="0.01"> 
            </div>

            <h4 class="mt-4">3. Avtomatlaşdırma (Gələcəkdə)</h4>
            <div class="form-group"> 
              <label><input type="checkbox" v-model="localSettings.taxes.automation.generateReports" disabled> Vergi hesabatlarını avtomatik hazırla</label> 
            </div>
            <div class="form-group"> 
              <label><input type="checkbox" v-model="localSettings.taxes.automation.calculateLiabilities" disabled> Vergi öhdəliklərini avtomatik hesabla</label> 
            </div>
            <div class="form-group"> 
              <label><input type="checkbox" v-model="localSettings.taxes.automation.createInvoices" disabled> Vergi hesab-fakturalarını avtomatik yarat</label> 
            </div>

            <h4 class="mt-4">4. Bəyannamə Tərtibatı (Gələcəkdə)</h4>
            <div class="form-row">
              <div class="form-group"> 
                <label for="declarationVatFreq">ƏDV Bəyannaməsi Tezliyi</label> 
                <select id="declarationVatFreq" v-model="localSettings.taxes.declarations.vatFrequency"> 
                  <option value="monthly">Aylıq</option> 
                  <option value="quarterly">Rüblük</option> 
                </select> 
              </div>
              <div class="form-group"> 
                <label for="declarationIncomeFreq">Gəlir Vergisi Bəyannaməsi Tezliyi</label> 
                <select id="declarationIncomeFreq" v-model="localSettings.taxes.declarations.incomeFrequency"> 
                  <option value="quarterly">Rüblük</option> 
                  <option value="yearly">İllik</option> 
                </select> 
              </div>
            </div>
            <p class="helper-text">Digər bəyannamə formaları gələcəkdə əlavə olunacaq.</p>

            <h4 class="mt-4">5. Vergi Ödəniş Müddətləri (Ayın günü)</h4>
            <div class="form-row">
              <div class="form-group"> 
                <label for="deadlineVat">ƏDV Son Ödəniş Günü</label> 
                <input type="number" id="deadlineVat" v-model.number="localSettings.taxes.deadlines.vat" min="1" max="31"> 
              </div>
              <div class="form-group"> 
                <label for="deadlineIncome">Gəlir Vergisi Son Ödəniş Günü</label> 
                <input type="number" id="deadlineIncome" v-model.number="localSettings.taxes.deadlines.income" min="1" max="31"> 
              </div>
            </div>
            <p class="helper-text">Xatırlatmalar gələcəkdə əlavə olunacaq.</p>

            <h4 class="mt-4">6. İnteqrasiyalar (Gələcəkdə)</h4>
            <div class="form-group"> 
              <label><input type="checkbox" v-model="localSettings.taxes.integrations.statePortal" disabled> Dövlət Vergi Xidməti portalına inteqrasiya</label> 
            </div>
            <div class="form-group"> 
              <label><input type="checkbox" v-model="localSettings.taxes.integrations.bank" disabled> Bank hesabına inteqrasiya (ödənişlər üçün)</label> 
            </div>

            <div class="form-group mt-4"> 
              <button class="btn btn-primary" @click="saveSettings('taxes')">Vergi Parametrlərini Saxla</button> 
            </div>
          </div>
        </div>
      </div>

      <!-- Categories Settings -->
      <div v-if="activeSettingsTab === 'categories'" class="settings-section">
        <div class="card">
          <div class="card-header">
            <h3>Məhsul Kateqoriyaları</h3>
            <div class="button-group"> 
              <button class="add-btn" @click="addCategory"> 
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg> Kateqoriya əlavə et 
              </button> 
            </div>
          </div>
          <div class="card-body">
            <div v-if="$root.categories && $root.categories.length > 0" class="table-responsive">
              <table>
                <thead><tr><th>Ad</th><th>Təsvir</th><th>Əməliyyatlar</th></tr></thead>
                <tbody>
                  <tr v-for="category in $root.categories" :key="category.id">
                    <td>{{ category.name }}</td> 
                    <td>{{ category.description || '-' }}</td>
                    <td> 
                      <div class="button-group"> 
                        <button class="action-btn edit-btn" title="Düzəliş et" @click="editCategory(category)"><svg width="18" height="18" viewBox="0 0 24 24"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg></button> 
                        <button class="action-btn delete-btn" title="Sil" @click="deleteCategory(category.id)"><svg width="18" height="18" viewBox="0 0 24 24"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6"/></svg></button> 
                      </div> 
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="empty-state" v-else> 
              <p>Heç bir kateqoriya tapılmadı.</p> 
            </div>
          </div>
        </div>
      </div>

      <!-- Accounting Plan Tab -->
      <div v-if="activeSettingsTab === 'accounting'" class="settings-section">
        <div class="card">
          <div class="card-header">
            <h3>Hesablar Planı & Təyinatlar</h3>
            <div class="button-group">
              <button class="add-btn" @click="addAccount">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg> Yeni Hesab Əlavə Et
              </button>
            </div>
          </div>
          <div class="card-body">
            <!-- Accounting Plan Table -->
            <h4>Hesablar Planı</h4>
            <div class="search-input" style="margin-bottom: 1rem;">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input type="text" v-model="accountSearch" placeholder="Hesab axtar (Kod, Ad)..." />
            </div>
            <div v-if="$root.accountTree && $root.accountTree.length > 0" class="table-responsive">
              <table>
                <thead><tr><th>Kod</th><th>Ad</th><th>Tip</th><th>Balans</th><th>Əməliyyatlar</th></tr></thead>
                <tbody>
                  <template v-for="account in $root.filteredAccountTree(accountSearch)" :key="account.code">
                    <tr :data-code="account.code" :data-parent="account.parentId || ''">
                      <td><span class="badge badge-dark">{{ account.code }}</span></td>
                      <td>{{ account.name }}</td>
                      <td>{{ getAccountTypeName(account.type) }}</td>
                      <td>{{ formatCurrency(account.balance) }}</td>
                      <td><div class="button-group"><button class="action-btn edit-btn" title="Düzəliş et" @click="editAccountProxy(account.code)"><svg width="18" height="18" viewBox="0 0 24 24"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg></button><button class="action-btn delete-btn" title="Sil" @click="deleteAccountProxy(account.code)"><svg width="18" height="18" viewBox="0 0 24 24"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6"/></svg></button></div></td>
                    </tr>
                    <template v-for="child in account.children" :key="child.code">
                      <tr :data-code="child.code" :data-parent="child.parentId || ''">
                        <td><span class="badge badge-dark" style="margin-left: 20px;">{{ child.code }}</span></td>
                        <td>{{ child.name }}</td>
                        <td>{{ getAccountTypeName(child.type) }}</td>
                        <td>{{ formatCurrency(child.balance) }}</td>
                        <td><div class="button-group"><button class="action-btn edit-btn" title="Düzəliş et" @click="editAccountProxy(child.code)"><svg width="18" height="18" viewBox="0 0 24 24"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg></button><button class="action-btn delete-btn" title="Sil" @click="deleteAccountProxy(child.code)"><svg width="18" height="18" viewBox="0 0 24 24"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6"/></svg></button></div></td>
                      </tr>
                    </template>
                  </template>
                </tbody>
              </table>
            </div>
            <h4 class="mt-4">Əməliyyat Təyinatları</h4>
            <p class="helper-text">Satış, alış və digər əməliyyatların avtomatik qeydiyyatı üçün defolt hesabları təyin edin.</p>
            <div class="form-row">
              <div class="form-group"><label>Alıcı Borcları (Debitor)</label><select v-model="defaultMappings.customer_receivable"><option value="">Seçin...</option><option v-for="a in filteredAccountsByType('asset')" :value="a.code">{{ a.code }} - {{ a.name }}</option></select></div>
              <div class="form-group"><label>Təchizatçı Borcları (Kreditor)</label><select v-model="defaultMappings.supplier_payable"><option value="">Seçin...</option><option v-for="a in filteredAccountsByType('liability')" :value="a.code">{{ a.code }} - {{ a.name }}</option></select></div>
            </div>
            <div class="form-row">
              <div class="form-group"><label>Anbar (Məhsul Ehtiyatları)</label><select v-model="defaultMappings.inventory"><option value="">Seçin...</option><option v-for="a in filteredAccountsByType('asset')" :value="a.code">{{ a.code }} - {{ a.name }}</option></select></div>
              <div class="form-group"><label>Satışdan Gəlirlər</label><select v-model="defaultMappings.sales_revenue"><option value="">Seçin...</option><option v-for="a in filteredAccountsByType('income')" :value="a.code">{{ a.code }} - {{ a.name }}</option></select></div>
            </div>
            <div class="form-row">
              <div class="form-group"><label>Satılan Məhsulların Maya Dəyəri (Xərc)</label><select v-model="defaultMappings.cost_of_goods"><option value="">Seçin...</option><option v-for="a in filteredAccountsByType('expense')" :value="a.code">{{ a.code }} - {{ a.name }}</option></select></div>
              <div class="form-group"><label>Defolt Kassa Hesabı</label><select v-model="defaultMappings.cash"><option value="">Seçin...</option><option v-for="a in filteredAccountsByType(null, ['cash'])" :value="a.code">{{ a.code }} - {{ a.name }}</option></select></div>
            </div>
            <div class="form-row">
              <div class="form-group"><label>Defolt Bank Hesabı</label><select v-model="defaultMappings.bank"><option value="">Seçin...</option><option v-for="a in filteredAccountsByType(null, ['bank'])" :value="a.code">{{ a.code }} - {{ a.name }}</option></select></div>
              <div class="form-group"><label>Kapital Hesabı</label><select v-model="defaultMappings.capital"><option value="">Seçin...</option><option v-for="a in filteredAccountsByType('equity')" :value="a.code">{{ a.code }} - {{ a.name }}</option></select></div>
            </div>
            <div class="form-group mt-4">
              <button class="btn btn-primary" @click="saveAccountSettings">Hesab Təyinatlarını Saxla</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Email Settings -->
      <div v-if="activeSettingsTab === 'email'" class="settings-section">
        <div class="card">
          <div class="card-header"><h3>Email Parametrləri</h3></div>
          <div class="card-body">
            <h4>SMTP Ayarları</h4>
            <div class="form-row">
              <div class="form-group">
                <label>SMTP Host</label>
                <input type="text" v-model="emailConfig.smtp.host" placeholder="smtp.example.com">
              </div>
              <div class="form-group">
                <label>Port</label>
                <input type="number" v-model.number="emailConfig.smtp.port" placeholder="587">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>İstifadəçi adı</label>
                <input type="text" v-model="emailConfig.smtp.username" placeholder="username">
              </div>
              <div class="form-group">
                <label>Şifrə</label>
                <input type="password" v-model="emailConfig.smtp.password" placeholder="********">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Göndərən Email</label>
                <input type="email" v-model="emailConfig.smtp.fromEmail" placeholder="noreply@example.com">
              </div>
              <div class="form-group">
                <label>Göndərən Ad</label>
                <input type="text" v-model="emailConfig.smtp.fromName" placeholder="Anbar Sistemi">
              </div>
            </div>
            <div class="form-group">
              <label>
                <input type="checkbox" v-model="emailConfig.smtp.secure"> SSL/TLS Təhlükəsiz Bağlantı
              </label>
            </div>
            
            <div v-if="emailTestStatus" :class="['alert', emailTestStatus.type === 'success' ? 'alert-success' : 'alert-danger']">
              {{ emailTestStatus.message }}
            </div>

            <div class="button-group">
              <button class="btn btn-secondary" @click="testEmailConnection">SMTP Bağlantısını Yoxla</button>
              <button class="btn btn-primary" @click="sendTestEmail">Test Email Göndər</button>
            </div>

            <h4 class="mt-4">Email Şablonları</h4>
            <div class="form-group">
              <label>Şifrə Bərpası Şablonu</label>
              <input type="text" v-model="emailConfig.templates.passwordReset.subject" placeholder="Mövzu">
              <textarea v-model="emailConfig.templates.passwordReset.body" rows="3" placeholder="Şablon Mətni"></textarea>
            </div>
            
            <div class="form-group">
              <label>Əməliyyat Qəbzi Şablonu</label>
              <input type="text" v-model="emailConfig.templates.transactionReceipt.subject" placeholder="Mövzu">
              <textarea v-model="emailConfig.templates.transactionReceipt.body" rows="3" placeholder="Şablon Mətni"></textarea>
            </div>

            <h4 class="mt-4">Bildiriş Ayarları</h4>
            <div class="permissions-list">
              <div class="permission-item">
                <input type="checkbox" 
                       :checked="emailConfig.notifications.passwordReset" 
                       @change="toggleEmailSetting('passwordReset')"
                       id="passwordResetNotification">
                <label for="passwordResetNotification">Şifrə Bərpası Bildirişləri</label>
              </div>
              <div class="permission-item">
                <input type="checkbox" 
                       :checked="emailConfig.notifications.transactionReceipt" 
                       @change="toggleEmailSetting('transactionReceipt')"
                       id="transactionReceiptNotification">
                <label for="transactionReceiptNotification">Əməliyyat Qəbzi Bildirişləri</label>
              </div>
              <div class="permission-item">
                <input type="checkbox" 
                       :checked="emailConfig.notifications.lowStock" 
                       @change="toggleEmailSetting('lowStock')"
                       id="lowStockNotification">
                <label for="lowStockNotification">Stok Azalması Bildirişləri</label>
              </div>
              <div class="permission-item">
                <input type="checkbox" 
                       :checked="emailConfig.notifications.dailySummary" 
                       @change="toggleEmailSetting('dailySummary')"
                       id="dailySummaryNotification">
                <label for="dailySummaryNotification">Gündəlik Özət Bildirişləri</label>
              </div>
            </div>

            <div class="button-group mt-3">
              <button class="btn btn-primary" @click="saveEmailSettings">Parametrləri Saxla</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Backup Settings -->
      <div v-if="activeSettingsTab === 'backup'" class="settings-section">
          <div class="card">
            <div class="card-header"><h3>Yedəkləmə və Bərpa</h3></div>
            <div class="card-body">
              <p>Verilənlər bazasının yedəyini çıxarın və ya əvvəlki yedəkdən bərpa edin. Bərpa əməliyyatı bütün mövcud məlumatları siləcək.</p>
              <div class="button-group mt-3">
                  <button class="btn btn-primary" @click="backupData">Yedək Çıxart (.json)</button>
                  <input type="file" ref="restoreFile" @change="handleRestore" accept=".json" style="display: none;">
                  <button class="btn btn-secondary" @click="$refs.restoreFile.click()">Yedəkdən Bərpa Et</button>
              </div>
            </div>
          </div>
        </div>

       <!-- Notification Test Section -->
       <div v-if="activeSettingsTab === 'notifications'" class="settings-section">
         <div class="card">
           <div class="card-header"><h3>Bildiriş Sistemini Yoxla</h3></div>
           <div class="card-body">
             <p>Bildirişlərin görünüşünü və işləməsini yoxlamaq üçün aşağıdakı düymələri istifadə edin.</p>
             <div class="form-group">
                <label for="testNotificationMessage">Bildiriş Mətni:</label>
                <input type="text" id="testNotificationMessage" v-model="testNotificationMessage" placeholder="Test bildirişi üçün mətn daxil edin...">
             </div>
             <div class="button-group mt-3">
               <button class="btn btn-success" @click="triggerTestNotification('success')">Uğurlu Bildiriş</button>
               <button class="btn btn-danger" @click="triggerTestNotification('error')">Xəta Bildirişi</button>
               <button class="btn btn-warning" @click="triggerTestNotification('warning')">Xəbərdarlıq Bildirişi</button>
               <button class="btn btn-info" @click="triggerTestNotification('info')">Məlumat Bildirişi</button>
             </div>
           </div>
         </div>
       </div>

    </div>
  `
};