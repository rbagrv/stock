import { defineAsyncComponent } from 'vue';

// Define all tab components
const DashboardTab = defineAsyncComponent(() => import('./tabs/DashboardTab.js'));
const ProductsTab = defineAsyncComponent(() => import('./tabs/ProductsTab.js'));
const CustomersTab = defineAsyncComponent(() => import('./tabs/CustomersTab.js'));
const SuppliersTab = defineAsyncComponent(() => import('./tabs/SuppliersTab.js'));
const SalesTab = defineAsyncComponent(() => import('./tabs/SalesTab.js'));
const PurchasesTab = defineAsyncComponent(() => import('./tabs/PurchasesTab.js'));
const OperationsTab = defineAsyncComponent(() => import('./tabs/OperationsTab.js'));
const UsersTab = defineAsyncComponent(() => import('./tabs/UsersTab.js'));
const ProductionTab = defineAsyncComponent(() => import('./tabs/ProductionTab.js'));
const CashierTab = defineAsyncComponent(() => import('./tabs/CashierTab.js'));
const ReportsTab = defineAsyncComponent(() => import('./tabs/ReportsTab.js'));
const SettingsTab = defineAsyncComponent(() => import('./tabs/SettingsTab.js'));

// Define all modal components
const ModalContainer = defineAsyncComponent(() => import('./modals/ModalContainer.js'));
const ProductModal = defineAsyncComponent(() => import('./modals/ProductModal.js'));
const CustomerModal = defineAsyncComponent(() => import('./modals/CustomerModal.js'));
const SupplierModal = defineAsyncComponent(() => import('./modals/SupplierModal.js'));
const SaleModal = defineAsyncComponent(() => import('./modals/SaleModal.js'));
const PurchaseModal = defineAsyncComponent(() => import('./modals/PurchaseModal.js'));
const UserModal = defineAsyncComponent(() => import('./modals/UserModal.js'));
const ProductionModal = defineAsyncComponent(() => import('./modals/ProductionModal.js'));
const CategoryModal = defineAsyncComponent(() => import('./modals/CategoryModal.js'));
const AccountModal = defineAsyncComponent(() => import('./modals/AccountModal.js'));
const IncomeModal = defineAsyncComponent(() => import('./modals/IncomeModal.js'));
const ExpenseModal = defineAsyncComponent(() => import('./modals/ExpenseModal.js'));
const TransferModal = defineAsyncComponent(() => import('./modals/TransferModal.js'));
const DetailsModalComponent = defineAsyncComponent(() => import('./modals/DetailsModal.js'));
const CreditModal = defineAsyncComponent(() => import('./modals/CreditModal.js'));

// New components
const NotificationComponent = defineAsyncComponent(() => import('./Notification.js'));
const DialogComponent = defineAsyncComponent(() => import('./Dialog.js'));

export function registerComponents(app) {
    // Register tab components
    app.component('dashboard-tab', DashboardTab);
    app.component('products-tab', ProductsTab);
    app.component('customers-tab', CustomersTab);
    app.component('suppliers-tab', SuppliersTab);
    app.component('sales-tab', SalesTab);
    app.component('purchases-tab', PurchasesTab);
    app.component('operations-tab', OperationsTab);
    app.component('users-tab', UsersTab);
    app.component('production-tab', ProductionTab);
    app.component('cashier-tab', CashierTab);
    app.component('reports-tab', ReportsTab);
    app.component('settings-tab', SettingsTab);

    // Register modal components
    app.component('modal-container', ModalContainer);
    app.component('product-modal', ProductModal);
    app.component('customer-modal', CustomerModal);
    app.component('supplier-modal', SupplierModal);
    app.component('sale-modal', SaleModal);
    app.component('purchase-modal', PurchaseModal);
    app.component('user-modal', UserModal);
    app.component('production-modal', ProductionModal);
    app.component('category-modal', CategoryModal);
    app.component('account-modal', AccountModal);
    app.component('income-modal', IncomeModal);
    app.component('expense-modal', ExpenseModal);
    app.component('transfer-modal', TransferModal);
    app.component('details-modal', DetailsModalComponent);
    app.component('credit-modal', CreditModal);

    // Register utility components
    app.component('notification-component', NotificationComponent);
    app.component('dialog-component', DialogComponent);
}