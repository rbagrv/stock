export default {
  props: ['modalData'],
  data() {
    return {
      purchase: this.initPurchase(),
      suppliers: [],
      products: [],
      items: [],
      paymentMethods: [
        { id: 'cash', name: 'Nağd', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"></rect><circle cx="12" cy="12" r="2"></circle><path d="M6 12h.01M18 12h.01"></path></svg>' },
        { id: 'card', name: 'Kart', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="2" y1="10" x2="22" y2="10"></line></svg>' },
        { id: 'bank', name: 'Bank', icon: '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2"></polygon><line x1="12" y1="22" x2="12" y2="15.5"></line><polyline points="22 8.5 12 15.5 2 8.5"></polyline></svg>' }
      ],
      searchQuery: '',
      filteredProducts: [],
      showProductDropdown: false,
      newProductQuantity: 1,
      totalAmount: 0,
      discount: 0,
      note: '',
      selectedSupplier: null,
      isSubmitting: false,
      formErrors: {
        items: '',
        paymentMethod: ''
      }
    };
  },
  template: `
    <div class="modal-content purchase-modal">
      <div class="modal-header">
        <h3>{{ isEditing ? 'Alış Düzəliş' : 'Yeni Alış' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row mobile-stack">
          <div class="form-group full-width-mobile">
            <label for="supplierSelect">Təchizatçı</label>
            <select id="supplierSelect" v-model="purchase.supplierId" @change="updateSelectedSupplier">
              <option value="">Seçin</option>
              <option v-for="supplier in suppliers" :key="supplier.id" :value="supplier.id">
                {{ supplier.company }}
              </option>
            </select>
          </div>
          
          <div class="form-group full-width-mobile">
            <label>Ödəniş Metodu</label>
            <div class="payment-method-selector">
              <button 
                v-for="method in paymentMethods" 
                :key="method.id" 
                :class="['payment-method-btn', {'active': purchase.paymentMethod === method.id}]"
                @click="purchase.paymentMethod = method.id"
              >
                <span v-html="method.icon"></span>
                <!-- Remove name, icon is enough for mobile? -->
                <span>{{ method.name }}</span>
              </button>
            </div>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="invoiceNumber">Faktura №</label>
            <input type="text" id="invoiceNumber" v-model="purchase.invoiceNumber">
          </div>
          
          <div class="form-group">
            <label for="purchaseDate">Tarix</label>
            <input type="date" id="purchaseDate" v-model="purchase.date">
          </div>
        </div>

        <div class="product-search-container">
          <div class="search-input">
            <input 
              type="text" 
              v-model="searchQuery" 
              @input="searchProducts" 
              @focus="showProductDropdown = true"
              @blur="handleSearchBlur"
              placeholder="Məhsul axtar və ya barkod oxut..."
            >
            <button class="scan-btn" title="Barkod oxut">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2"></path><path d="M17 3h2a2 2 0 0 1 2 2v2"></path><path d="M21 17v2a2 2 0 0 1-2 2h-2"></path><path d="M7 21H5a2 2 0 0 1-2-2v-2"></path><rect x="7" y="7" width="10" height="10"></rect></svg>
            </button>
          </div>
          
          <div class="product-dropdown" v-if="showProductDropdown && filteredProducts.length > 0">
            <div 
              v-for="product in filteredProducts" 
              :key="product.id" 
              class="product-dropdown-item"
              @click="addProductToPurchase(product.id)"
            >
              <div class="product-dropdown-name">{{ product.name }}</div>
              <div class="product-dropdown-details">
                <span class="product-dropdown-code">{{ product.code }}</span>
                <span class="product-dropdown-price">{{ formatCurrency(product.purchasePrice) }}</span>
                <!-- Add tax info if applicable in purchases -->
              </div>
            </div>
          </div>
        </div>
        
        <small v-if="formErrors.items" class="form-error">{{ formErrors.items }}</small>

        <div class="table-responsive mt-3">
          <table>
            <thead>
              <tr>
                <th>Məhsul</th>
                <th>Qiymət</th>
                <th>Miqdar</th>
                <th>Endirim (%)</th>
                <th>Cəmi</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in items" :key="index">
                <td>{{ item.productName }}</td>
                <td>
                  <input type="number" v-model.number="item.price" @input="updateItemTotal(item)" min="0" step="0.01" class="small-input">
                </td>
                <td>
                  <div class="quantity-control">
                    <button @click="decrementQuantity(item)" class="quantity-btn">-</button>
                    <input type="number" v-model.number="item.quantity" @input="updateItemTotal(item)" min="1" class="quantity-input">
                    <button @click="incrementQuantity(item)" class="quantity-btn">+</button>
                  </div>
                </td>
                <td>
                  <input type="number" v-model.number="item.discount" @input="updateItemTotal(item)" min="0" max="100" class="small-input">
                </td>
                <td>{{ formatCurrency(item.total) }}</td>
                <td>
                  <button class="btn-delete" @click="removeItem(index)">
                    <svg width="16" height="16" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr class="total-row">
                <td colspan="4" class="text-right">Ümumi Endirim:</td>
                <td>
                  <input type="number" v-model.number="discount" @input="updateTotalAmount" min="0" max="100" class="small-input"> %
                </td>
                <td></td>
              </tr>
              <tr class="total-row">
                <td colspan="4" class="text-right">Yekun Məbləğ:</td>
                <td colspan="2" class="grand-total">{{ formatCurrency(finalAmount) }}</td>
              </tr>
            </tfoot>
          </table>
          
          <div class="empty-state" v-if="items.length === 0">
            <p>Məhsul əlavə edin</p>
          </div>
        </div>

        <div class="form-group mt-3">
          <label for="purchaseNote">Qeyd</label>
          <textarea id="purchaseNote" v-model="purchase.note" rows="2"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')" :disabled="isSubmitting">Ləğv et</button>
        <button class="btn btn-primary" @click="savePurchase" :disabled="!isFormValid || isSubmitting">
          <span v-if="isSubmitting">
            <svg class="spinner-icon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>
            Saxlanılır...
          </span>
          <span v-else>{{ isEditing ? 'Saxla' : 'Alışı Tamamla' }}</span>
        </button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.purchase.id;
    },
    
    isFormValid() {
      return this.items.length > 0;
    },
    
    subtotal() {
        return this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    },
    
    totalInputTax() {
        // Placeholder: Add logic if input tax needs to be tracked
        return 0;
    },
    
    finalAmount() {
      const discountedSubtotal = this.subtotal * (1 - this.discount / 100);
      // Add tax logic here if purchase prices include/exclude tax
      return discountedSubtotal;
    }
  },
  methods: {
     initPurchase() {
        const basePurchase = this.modalData ? {...this.modalData} : {
         supplierId: '',
         paymentMethod: 'cash',
         date: new Date().toISOString().slice(0, 10),
         invoiceNumber: '',
         note: ''
       };
       this.items = basePurchase.items ? [...basePurchase.items] : [];
       this.discount = basePurchase.discount || 0;
       this.$nextTick(this.updateTotalAmount); // Recalculate totals
       return basePurchase;
     },
     
     updateSelectedSupplier() {
       if (this.purchase.supplierId) {
         this.selectedSupplier = this.suppliers.find(s => s.id === this.purchase.supplierId);
       } else {
         this.selectedSupplier = null;
       }
     },
     
     searchProducts() {
       if (!this.searchQuery || !this.searchQuery.trim()) {
         this.filteredProducts = [];
         return;
       }
       
       const query = this.searchQuery.toLowerCase();
       this.filteredProducts = this.products
         .filter(product => 
           product.name.toLowerCase().includes(query) || 
           product.code.toLowerCase().includes(query) ||
           (product.barcode && product.barcode.includes(query))
         )
         .slice(0, 10); // Limit to 10 results for performance
     },
     
     addProductToPurchase(productId) {
       const selectedProduct = this.products.find(product => product.id === productId);
       if (!selectedProduct) return;
       
       // Check if product is already in the list
       const existingItemIndex = this.items.findIndex(item => item.productId === productId);
       
       if (existingItemIndex !== -1) {
         // Update quantity if product already exists
         this.items[existingItemIndex].quantity += 1;
         this.updateItemTotal(this.items[existingItemIndex]);
       } else {
         // Add new item with validated values
         const newItem = {
           productId: selectedProduct.id,
           productName: selectedProduct.name || 'Adsız məhsul',
           price: parseFloat(selectedProduct.purchasePrice) || 0,
           quantity: 1,
           discount: 0,
           total: parseFloat(selectedProduct.purchasePrice) || 0
         };
         // Add isTaxable field from product if needed for purchases
         this.items.push(newItem);
       }
       
       // Update total and clear search
       this.updateTotalAmount();
       this.searchQuery = '';
       this.filteredProducts = [];
       
       // Clear form error if items were added
       if (this.items.length > 0) {
         this.formErrors.items = '';
       }
     },
     
     incrementQuantity(item) {
       item.quantity++;
       this.updateItemTotal(item);
     },
     
     decrementQuantity(item) {
       if (item.quantity > 1) {
         item.quantity--;
         this.updateItemTotal(item);
       }
     },
     
     updateItemTotal(item) {
       // Recalculate item total based on price, quantity, and item discount
       item.total = item.price * item.quantity * (1 - item.discount / 100);
       this.updateTotalAmount();
     },
     
     removeItem(index) {
       this.items.splice(index, 1);
       this.updateTotalAmount(); // Recalculate overall totals
     },
     
     updateTotalAmount() {
       this.totalAmount = this.items.reduce((total, item) => {
         return total + item.total;
       }, 0);
     },
     
     formatCurrency(amount) {
       if (amount === null || amount === undefined || isNaN(parseFloat(amount))) {
         return '0.00 ₼';
       }
       return parseFloat(amount).toFixed(2) + ' ₼';
     },
     
     savePurchase() {
       if (this.items.length === 0) {
         this.formErrors.items = 'Ən azı bir məhsul əlavə edin';
         return;
       }
       if (!this.purchase.paymentMethod) {
         this.formErrors.paymentMethod = 'Ödəniş metodu seçin';
         return;
       }
       
       this.isSubmitting = true;
       
       const purchaseData = {
         supplierId: this.purchase.supplierId || null,
         items: JSON.parse(JSON.stringify(this.items)), // Deep copy to avoid reference issues
         totalAmount: parseFloat(this.finalAmount.toFixed(2)),
         subtotal: parseFloat(this.subtotal.toFixed(2)), // Sum before discounts/taxes
         discount: parseFloat(this.discount),
         // totalTax: parseFloat(this.totalInputTax.toFixed(2)), // Add if tracking input tax
         paymentMethod: this.purchase.paymentMethod,
         date: this.purchase.date ? new Date(this.purchase.date).toISOString() : new Date().toISOString(),
         invoiceNumber: this.purchase.invoiceNumber,
         note: this.purchase.note
       };
       
       this.$emit('save-item', 'purchase', purchaseData);
     },
     handleSearchBlur() {
       window.setTimeout(() => {
         this.showProductDropdown = false;
       }, 200);
     }
   },
   mounted() {
     this.suppliers = this.$root.suppliers || [];
     this.products = this.$root.products || [];
     // Initialize purchase data
     this.initPurchase();
     
     // Set initial payment method if not editing or missing
     if (!this.isEditing && !this.purchase.paymentMethod) {
     }
     
     // Update selected supplier if supplierId is provided
     this.updateSelectedSupplier();
     
     // Focus the product search input for faster entry
     this.$nextTick(() => {
       const searchInput = document.querySelector('.product-search-container input');
       if (searchInput) searchInput.focus();
     });
   }
};