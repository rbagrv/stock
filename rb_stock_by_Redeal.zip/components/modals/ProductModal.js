export default {
  props: ['modalData'],
  data() {
    return {
      product: this.initProduct(),
      categories: [],
      units: ['ədəd', 'kq', 'litr', 'metr', 'qutu'],
      isTaxable: false // Add tax flag
    };
  },
  template: `
    <div class="modal-content">
      <div class="modal-header">
        <h3>{{ isEditing ? 'Məhsul Düzəliş Et' : 'Yeni Məhsul' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="productName">Məhsul adı *</label>
          <input type="text" id="productName" v-model="product.name" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="productCode">Məhsul kodu</label>
            <input type="text" id="productCode" v-model="product.code" placeholder="Avtomatik">
          </div>
          <div class="form-group">
            <label for="productCategory">Kateqoriya</label>
            <select id="productCategory" v-model="product.categoryId">
              <option value="">Seçin...</option>
              <option v-for="category in categories" :key="category.id" :value="category.id">{{ category.name }}</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="productPurchasePrice">Alış qiyməti *</label>
            <input type="number" id="productPurchasePrice" v-model="product.purchasePrice" required min="0" step="0.01">
          </div>
          <div class="form-group">
            <label for="productSalePrice">Satış qiyməti *</label>
            <input type="number" id="productSalePrice" v-model="product.salePrice" required min="0" step="0.01">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="productQuantity">Stok miqdarı</label>
            <input type="number" id="productQuantity" v-model="product.quantity" min="0">
          </div>
          <div class="form-group">
            <label for="productUnit">Ölçü vahidi</label>
            <select id="productUnit" v-model="product.unit">
              <option v-for="unit in units" :key="unit" :value="unit">{{ unit }}</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label for="productBarcode">Barkod</label>
          <input type="text" id="productBarcode" v-model="product.barcode">
        </div>
        <div class="form-group">
          <label for="productDescription">Əlavə məlumat</label>
          <textarea id="productDescription" v-model="product.description"></textarea>
        </div>
        <div class="form-group">
           <label>
             <input type="checkbox" v-model="product.isTaxable"> ƏDV-yə cəlb olunur
           </label>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveProduct">{{ isEditing ? 'Saxla' : 'Əlavə et' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.product.id;
    }
  },
  methods: {
    initProduct() {
      return this.modalData ? {...this.modalData} : {
        name: '',
        code: '',
        purchasePrice: 0,
        salePrice: 0,
        categoryId: '',
        quantity: 0,
        barcode: '',
        unit: 'ədəd',
        description: '',
        isTaxable: true // Default to taxable, user can uncheck
      };
    },
    saveProduct() {
      // Generate a code if not provided
      if (!this.product.code) {
        this.product.code = 'P' + Date.now().toString().slice(-6);
      }
      
      this.$emit('save-item', 'product', this.product);
    }
  },
  mounted() {
    // Get categories from parent component/store
    this.categories = this.$root.categories || [];
  },
  watch: {
      modalData: { handler(newData) { this.product = this.initProduct(); }, deep: true }
  }
};