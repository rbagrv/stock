export default {
  props: ['modalData'],
  data() {
    return {
      user: this.initUser(),
      roles: ['admin', 'manager', 'sales', 'warehouse'],
      permissions: [
        { id: 'view_dashboard', name: 'Dashboard görüntüləmə' },
        { id: 'manage_products', name: 'Məhsulları idarəetmə' },
        { id: 'manage_sales', name: 'Satışları idarəetmə' },
        { id: 'manage_purchases', name: 'Alışları idarəetmə' },
        { id: 'manage_customers', name: 'Alıcıları idarəetmə' },
        { id: 'manage_suppliers', name: 'Təchizatçıları idarəetmə' },
        { id: 'manage_users', name: 'İstifadəçiləri idarəetmə' },
        { id: 'manage_reports', name: 'Hesabatları idarəetmə' },
        { id: 'manage_settings', name: 'Parametrləri idarəetmə' }
      ],
      isFormValid: false,
      formErrors: {
        fullName: '',
        username: '',
        password: ''
      }
    };
  },
  template: `
    <div class="modal-content">
      <div class="modal-header">
        <h3>{{ isEditing ? 'İstifadəçi Düzəliş' : 'Yeni İstifadəçi' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="fullName" class="required">Tam ad</label>
          <input 
            type="text" 
            id="fullName" 
            v-model="user.fullName" 
            @input="validateField('fullName')" 
            required
          >
          <small v-if="formErrors.fullName" class="form-error">{{ formErrors.fullName }}</small>
        </div>
        
        <div class="form-group">
          <label for="username" class="required">İstifadəçi adı</label>
          <input 
            type="text" 
            id="username" 
            v-model="user.username" 
            @input="validateField('username')" 
            required
          >
          <small v-if="formErrors.username" class="form-error">{{ formErrors.username }}</small>
        </div>
        
        <div class="form-row">
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" v-model="user.email">
          </div>
          
          <div class="form-group">
            <label for="password" :class="{'required': !isEditing}">Şifrə</label>
            <input 
              type="password" 
              id="password" 
              v-model="user.password" 
              @input="validateField('password')" 
              :required="!isEditing"
            >
            <small v-if="formErrors.password" class="form-error">{{ formErrors.password }}</small>
          </div>
        </div>
        
        <div class="form-row">
          <div class="form-group">
            <label for="role" class="required">Rol</label>
            <select id="role" v-model="user.role" required>
              <option v-for="role in roles" :key="role" :value="role">{{ getRoleLabel(role) }}</option>
            </select>
          </div>
          
          <div class="form-group">
            <label for="status">Status</label>
            <select id="status" v-model="user.status">
              <option value="active">Aktiv</option>
              <option value="inactive">Deaktiv</option>
            </select>
          </div>
        </div>
        
        <div class="form-group">
          <label>İcazələr</label>
          <div class="permissions-list">
            <div class="permission-item" v-for="permission in permissions" :key="permission.id">
              <input 
                type="checkbox" 
                :id="permission.id" 
                :value="permission.id" 
                v-model="user.permissions"
              >
              <label :for="permission.id">{{ permission.name }}</label>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveUser" :disabled="!isFormValid">{{ isEditing ? 'Saxla' : 'Əlavə et' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.user.id;
    }
  },
  methods: {
    initUser() {
      return this.modalData ? {...this.modalData} : {
        fullName: '',
        username: '',
        email: '',
        password: '',
        role: 'sales',
        permissions: ['view_dashboard'],
        status: 'active'
      };
    },
    getRoleLabel(role) {
      const labels = {
        'admin': 'Administrator',
        'manager': 'Menecer',
        'sales': 'Satış meneceri',
        'warehouse': 'Anbar meneceri'
      };
      return labels[role] || role;
    },
    validateField(field) {
      switch(field) {
        case 'fullName':
          this.formErrors.fullName = this.user.fullName.trim() ? '' : 'Tam ad tələb olunur';
          break;
        case 'username':
          this.formErrors.username = this.user.username.trim() ? '' : 'İstifadəçi adı tələb olunur';
          break;
        case 'password':
          if (!this.isEditing) {
            this.formErrors.password = this.user.password.length >= 6 ? '' : 'Şifrə ən azı 6 simvol olmalıdır';
          } else {
            this.formErrors.password = this.user.password === '' || this.user.password.length >= 6 ? '' : 'Şifrə ən azı 6 simvol olmalıdır';
          }
          break;
      }
      
      // Check overall form validity
      this.validateForm();
    },
    validateForm() {
      if (this.isEditing) {
        this.isFormValid = 
          this.user.fullName.trim() !== '' && 
          this.user.username.trim() !== '' && 
          (this.user.password === '' || this.user.password.length >= 6);
      } else {
        this.isFormValid = 
          this.user.fullName.trim() !== '' && 
          this.user.username.trim() !== '' && 
          this.user.password.length >= 6;
      }
    },
    saveUser() {
      if (!this.isFormValid) return;
      
      // If no permissions selected, give at least view_dashboard
      if (this.user.permissions.length === 0) {
        this.user.permissions = ['view_dashboard'];
      }
      
      this.$emit('save-item', 'user', this.user);
    }
  },
  mounted() {
    // Validate form initially
    this.validateForm();
  }
};