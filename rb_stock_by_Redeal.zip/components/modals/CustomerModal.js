export default {
  props: ['modalData'],
  data() {
    return {
      customer: this.initCustomer(),
      taxRegimes: [ // Define possible tax regimes
        { id: 'standard', name: 'Standart (ƏDV ödəyicisi)' },
        { id: 'simplified', name: 'Sadələşdirilmiş Vergi' },
        { id: 'none', name: 'Vergi ödəyicisi deyil' }
      ],
      isFormValid: false,
      formErrors: {
        name: ''
      }
    };
  },
  template: `
    <div class="modal-content">
      <div class="modal-header">
        <h3>{{ isEditing ? 'Müştəri Düzəliş' : 'Yeni Müştəri' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="customerName" class="required">Müştəri adı</label>
          <input
            type="text"
            id="customerName"
            v-model="customer.name"
            @input="validateField('name')"
            required
          >
          <small v-if="formErrors.name" class="form-error">{{ formErrors.name }}</small>
        </div>

        <div class="form-group">
          <label for="company">Şirkət</label>
          <input type="text" id="company" v-model="customer.company">
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="phone">Telefon</label>
            <input type="tel" id="phone" v-model="customer.phone">
          </div>

          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" v-model="customer.email">
          </div>
        </div>

        <div class="form-group">
          <label for="address">Ünvan</label>
          <textarea id="address" v-model="customer.address"></textarea>
        </div>

        <div class="form-row">
            <div class="form-group">
              <label for="debt">Borc</label>
              <input type="number" id="debt" v-model.number="customer.debt" min="0" step="0.01">
            </div>
            <div class="form-group">
              <label for="taxRegime">Vergi Rejimi</label>
              <select id="taxRegime" v-model="customer.taxRegime">
                <option v-for="regime in taxRegimes" :key="regime.id" :value="regime.id">{{ regime.name }}</option>
              </select>
            </div>
        </div>

        <div class="form-group">
          <label for="description">Əlavə məlumat</label>
          <textarea id="description" v-model="customer.description"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveCustomer" :disabled="!isFormValid">{{ isEditing ? 'Saxla' : 'Əlavə et' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.customer.id;
    }
  },
  methods: {
    initCustomer() {
      return this.modalData ? {...this.modalData} : {
        name: '',
        company: '',
        phone: '',
        email: '',
        address: '',
        debt: 0,
        taxRegime: 'standard', // Default tax regime
        description: ''
      };
    },
    validateField(field) {
      switch(field) {
        case 'name':
          this.formErrors.name = this.customer.name.trim() ? '' : 'Müştəri adı tələb olunur';
          break;
      }

      // Check overall form validity
      this.validateForm();
    },
    validateForm() {
      this.isFormValid = this.customer.name.trim() !== '';
    },
    saveCustomer() {
      if (!this.isFormValid) return;

      this.$emit('save-item', 'customer', this.customer);
    }
  },
  mounted() {
    // Validate form initially
    this.validateForm();
  }
};