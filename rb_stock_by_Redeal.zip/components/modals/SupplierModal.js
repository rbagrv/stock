export default {
  props: ['modalData'],
  data() {
    return {
      supplier: this.initSupplier(),
      categories: ['Qida', 'Elektron', 'Geyim', 'Mebel', 'Ofis ləvazimatları', 'Digər'],
      isFormValid: false,
      formErrors: {
        company: ''
      }
    };
  },
  template: `
    <div class="modal-content">
      <div class="modal-header">
        <h3>{{ isEditing ? 'Təchizatçı Düzəliş' : 'Yeni Təchizatçı' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="companyName" class="required">Şirkət adı</label>
          <input 
            type="text" 
            id="companyName" 
            v-model="supplier.company" 
            @input="validateField('company')" 
            required
          >
          <small v-if="formErrors.company" class="form-error">{{ formErrors.company }}</small>
        </div>
        
        <div class="form-row">
          <div class="form-group">
            <label for="contactPerson">Əlaqə şəxsi</label>
            <input type="text" id="contactPerson" v-model="supplier.contact">
          </div>
          
          <div class="form-group">
            <label for="phone">Telefon</label>
            <input type="text" id="phone" v-model="supplier.phone">
          </div>
        </div>
        
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" id="email" v-model="supplier.email">
        </div>
        
        <div class="form-group">
          <label for="address">Ünvan</label>
          <textarea id="address" v-model="supplier.address"></textarea>
        </div>
        
        <div class="form-group">
          <label for="category">Kateqoriya</label>
          <select id="category" v-model="supplier.category">
            <option value="">Seçin...</option>
            <option v-for="category in categories" :key="category" :value="category">{{ category }}</option>
          </select>
        </div>
        
        <div class="form-group">
          <label for="description">Əlavə məlumat</label>
          <textarea id="description" v-model="supplier.description"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveSupplier" :disabled="!isFormValid">{{ isEditing ? 'Saxla' : 'Əlavə et' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.supplier.id;
    }
  },
  methods: {
    initSupplier() {
      return this.modalData ? {...this.modalData} : {
        company: '',
        contact: '',
        phone: '',
        email: '',
        address: '',
        category: '',
        description: ''
      };
    },
    validateField(field) {
      switch(field) {
        case 'company':
          this.formErrors.company = this.supplier.company.trim() ? '' : 'Şirkət adı tələb olunur';
          break;
      }
      
      // Check overall form validity
      this.validateForm();
    },
    validateForm() {
      this.isFormValid = this.supplier.company.trim() !== '';
    },
    saveSupplier() {
      if (!this.isFormValid) return;
      
      this.$emit('save-item', 'supplier', this.supplier);
    }
  },
  mounted() {
    // Validate form initially
    this.validateForm();
  }
};