export default {
  props: ['modalData'],
  data() {
    return {
      expense: this.initExpense(),
      accounts: [],
      categories: ['Kommunal', 'Əmək haqqı', 'İcarə', 'Vergi', 'Ofis', 'Reklam', 'Nəqliyyat', 'Digər'],
      isFormValid: false,
      formErrors: {
        amount: '',
        accountId: ''
      }
    };
  },
  template: `
    <div class="modal-content">
      <div class="modal-header">
        <h3>{{ isEditing ? 'Xərc Düzəliş' : 'Yeni Xərc' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row mobile-stack">
          <div class="form-group full-width-mobile">
            <label for="expenseAmount" class="required">Məbləğ</label>
            <input
              type="number"
              id="expenseAmount"
              v-model.number="expense.amount"
              @input="validateField('amount')"
              step="0.01"
              min="0.01"
              required
            >
            <small v-if="formErrors.amount" class="form-error">{{ formErrors.amount }}</small>
          </div>

          <div class="form-group full-width-mobile">
            <label for="expenseAccount" class="required">Hesab</label>
            <select
              id="expenseAccount"
              v-model="expense.accountId"
              @change="validateField('accountId')"
              required
            >
              <option value="">Hesab seçin</option>
              <option v-for="account in accounts" :key="account.code || account.id" :value="account.id || account.code">
                {{ account.name }} ({{ account.code }})
              </option>
            </select>
            <small v-if="formErrors.accountId" class="form-error">{{ formErrors.accountId }}</small>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="expenseCategory">Kateqoriya</label>
            <select id="expenseCategory" v-model="expense.category">
              <option value="">Kateqoriya seçin</option>
              <option v-for="category in categories" :key="category" :value="category">{{ category }}</option>
            </select>
          </div>

          <div class="form-group">
            <label for="expenseDate">Tarix</label>
            <input type="date" id="expenseDate" v-model="expense.date">
          </div>
        </div>

        <div class="form-group">
          <label for="expenseDescription">Təsvir</label>
          <textarea id="expenseDescription" v-model="expense.description"></textarea>
        </div>

        <div class="form-group">
          <label for="expenseReference">Referans</label>
          <input type="text" id="expenseReference" v-model="expense.reference" placeholder="Çek/Qəbz/Faktura nömrəsi">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveExpense" :disabled="!isFormValid">{{ isEditing ? 'Saxla' : 'Əlavə et' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.expense.id;
    }
  },
  methods: {
    initExpense() {
      return this.modalData ? {...this.modalData} : {
        amount: '',
        accountId: '',
        category: '',
        date: new Date().toISOString().slice(0, 10),
        description: '',
        reference: ''
      };
    },
    validateField(field) {
      switch(field) {
        case 'amount':
          this.formErrors.amount = this.expense.amount > 0 ? '' : 'Məbləğ 0-dan böyük olmalıdır';
          break;
        case 'accountId':
          this.formErrors.accountId = this.expense.accountId ? '' : 'Hesab seçilməlidir';
          break;
      }
      this.validateForm();
    },
    validateForm() {
      this.isFormValid =
        this.expense.amount > 0 &&
        this.expense.accountId !== '';
    },
    saveExpense() {
      if (!this.isFormValid) return;
      const dataToSave = {
        ...this.expense,
        type: 'expense'
      };
      this.$emit('save-item', 'expense', dataToSave);
    }
  },
  mounted() {
    this.accounts = this.$root.accounts || [];
    this.validateForm();
  }
};