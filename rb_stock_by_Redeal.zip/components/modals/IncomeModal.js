export default {
  props: ['modalData'],
  data() {
    return {
      income: this.initIncome(),
      accounts: [],
      customers: [], 
      categories: ['Satış', 'Borc', 'İnvestisiya', 'Digər'],
      isFormValid: false,
      formErrors: {
        amount: '',
        accountId: '',
        customerId: '' 
      }
    };
  },
  template: `
    <div class="modal-content">
      <div class="modal-header">
        <h3>{{ isEditing ? 'Gəlir Düzəliş' : 'Yeni Gəlir' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="modal-body">
         <div class="form-group">
            <label for="incomeCategory">Kateqoriya</label>
            <select id="incomeCategory" v-model="income.category" @change="validateField('category')">
              <option value="">Kateqoriya seçin</option>
              <option v-for="category in categories" :key="category" :value="category">{{ category }}</option>
            </select>
          </div>

        <div class="form-row mobile-stack">
          <div class="form-group full-width-mobile">
            <label for="incomeAmount" class="required">Məbləğ</label>
            <input
              type="number"
              id="incomeAmount"
              v-model.number="income.amount"
              @input="validateField('amount')"
              step="0.01"
              min="0.01"
              required
            >
            <small v-if="formErrors.amount" class="form-error">{{ formErrors.amount }}</small>
          </div>

          <div class="form-group full-width-mobile">
            <label for="incomeAccount" class="required">Hesab</label>
            <select
              id="incomeAccount"
              v-model="income.accountId"
              @change="validateField('accountId')"
              required
            >
              <option value="">Hesab seçin</option>
              <option v-for="account in accounts" :key="account.code || account.id" :value="account.id || account.code">
                  {{ account.name }} ({{ account.code }})
              </option>
            </select>
            <small v-if="formErrors.accountId" class="form-error">{{ formErrors.accountId }}</small>
          </div>
        </div>

        <!-- Conditional Customer Select -->
        <div class="form-group" v-if="income.category === 'Borc'">
          <label for="customerSelect" class="required">Müştəri</label>
          <select
            id="customerSelect"
            v-model="income.customerId"
            @change="validateField('customerId')"
            required
          >
            <option value="">Müştəri seçin</option>
            <option v-for="customer in customers" :key="customer.id" :value="customer.id">
              {{ customer.name }} {{ customer.debt > 0 ? '(Borc: ' + formatCurrency(customer.debt) + ')' : '' }}
            </option>
          </select>
          <small v-if="formErrors.customerId" class="form-error">{{ formErrors.customerId }}</small>
        </div>


        <div class="form-row">
          <div class="form-group">
            <label for="incomeDate">Tarix</label>
            <input type="date" id="incomeDate" v-model="income.date">
          </div>
          <div class="form-group">
            <label for="incomeReference">Referans</label>
            <input type="text" id="incomeReference" v-model="income.reference" placeholder="Çek/Qəbz/Faktura nömrəsi">
          </div>
        </div>

        <div class="form-group">
          <label for="incomeDescription">Təsvir</label>
          <textarea id="incomeDescription" v-model="income.description"></textarea>
        </div>

      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveIncome" :disabled="!isFormValid">{{ isEditing ? 'Saxla' : 'Əlavə et' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.income.id;
    }
  },
  methods: {
    initIncome() {
      return this.modalData ? {...this.modalData} : {
        amount: '',
        accountId: '',
        category: '',
        customerId: '', 
        date: new Date().toISOString().slice(0, 10),
        description: '',
        reference: ''
      };
    },
    formatCurrency(amount) {
       if (amount === null || amount === undefined || isNaN(parseFloat(amount))) return '0.00 ₼';
       return parseFloat(amount).toFixed(2) + ' ₼';
    },
    validateField(field) {
      switch(field) {
        case 'amount':
          this.formErrors.amount = this.income.amount > 0 ? '' : 'Məbləğ 0-dan böyük olmalıdır';
          break;
        case 'accountId':
          this.formErrors.accountId = this.income.accountId ? '' : 'Hesab seçilməlidir';
          break;
        case 'category':
          // Reset customerId if category changes from 'Borc'
          if (this.income.category !== 'Borc') {
            this.income.customerId = '';
            this.formErrors.customerId = '';
          }
          this.validateField('customerId'); // Revalidate customer field
          break;
        case 'customerId':
          if (this.income.category === 'Borc') {
            this.formErrors.customerId = this.income.customerId ? '' : 'Borc kateqoriyası üçün müştəri seçilməlidir';
          } else {
            this.formErrors.customerId = ''; // Clear error if category is not 'Borc'
          }
          break;
      }
      this.validateForm();
    },
    validateForm() {
      let isValid = this.income.amount > 0 && this.income.accountId !== '';
      if (this.income.category === 'Borc') {
        isValid = isValid && this.income.customerId !== '';
      }
      this.isFormValid = isValid;
    },
    saveIncome() {
      if (!this.isFormValid) return;

      const isDebtPayment = this.income.category === 'Borc';
      const transactionType = isDebtPayment ? 'credit' : 'income'; // Determine transaction type

      const dataToSave = {
        amount: this.income.amount,
        accountId: this.income.accountId,
        category: this.income.category,
        date: this.income.date,
        description: this.income.description,
        reference: this.income.reference,
        type: transactionType // Use determined type
      };

      // Include customerId only if it's a debt payment
      if (isDebtPayment) {
        dataToSave.customerId = this.income.customerId;
      }

      // If editing, include the ID
      if (this.isEditing) {
          dataToSave.id = this.income.id;
      }


      // Emit with the correct type for backend handling
      this.$emit('save-item', transactionType, dataToSave);
    }
  },
  mounted() {
    this.accounts = this.$root.accounts || [];
    this.customers = this.$root.customers || []; // Load customers
    this.validateForm(); // Initial validation
    // Validate customer field if initially category is 'Borc'
    if (this.income.category === 'Borc') {
        this.validateField('customerId');
    }
  }
};