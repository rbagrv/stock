export default {
  props: ['modalData'],
  data() {
    return {
      transfer: this.initTransfer(),
      accounts: [],
      isFormValid: false,
      formErrors: {
        amount: '',
        fromAccountId: '',
        toAccountId: ''
      }
    };
  },
  template: `
    <div class="modal-content">
      <div class="modal-header">
        <h3>{{ isEditing ? 'Transfer Düzəliş' : 'Yeni Transfer' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row">
          <div class="form-group">
            <label for="fromAccount" class="required">Göndərən hesab</label>
            <select
              id="fromAccount"
              v-model="transfer.fromAccountId"
              @change="validateField('fromAccountId')"
              required
            >
              <option value="">Hesab seçin</option>
              <option v-for="account in accounts" :key="account.code || account.id" :value="account.id || account.code">
                {{ account.name }} ({{ account.code }})
              </option>
            </select>
            <small v-if="formErrors.fromAccountId" class="form-error">{{ formErrors.fromAccountId }}</small>
          </div>

          <div class="form-group">
            <label for="toAccount" class="required">Qəbul edən hesab</label>
            <select
              id="toAccount"
              v-model="transfer.toAccountId"
              @change="validateField('toAccountId')"
              required
            >
              <option value="">Hesab seçin</option>
              <option v-for="account in availableToAccounts" :key="account.code || account.id" :value="account.id || account.code">
                {{ account.name }} ({{ account.code }})
              </option>
            </select>
            <small v-if="formErrors.toAccountId" class="form-error">{{ formErrors.toAccountId }}</small>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="transferAmount" class="required">Məbləğ</label>
            <input
              type="number"
              id="transferAmount"
              v-model.number="transfer.amount"
              @input="validateField('amount')"
              step="0.01"
              min="0.01"
              required
            >
            <small v-if="formErrors.amount" class="form-error">{{ formErrors.amount }}</small>
          </div>

          <div class="form-group">
            <label for="transferDate">Tarix</label>
            <input type="date" id="transferDate" v-model="transfer.date">
          </div>
        </div>

        <div class="form-group">
          <label for="transferDescription">Təsvir</label>
          <textarea id="transferDescription" v-model="transfer.description"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveTransfer" :disabled="!isFormValid">{{ isEditing ? 'Saxla' : 'Keçir' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.transfer.id;
    },
    availableToAccounts() {
      if (!this.transfer.fromAccountId) return this.accounts;
      return this.accounts.filter(account => (account.id || account.code) !== this.transfer.fromAccountId);
    }
  },
  methods: {
    initTransfer() {
      return this.modalData ? {...this.modalData} : {
        fromAccountId: '',
        toAccountId: '',
        amount: '',
        date: new Date().toISOString().slice(0, 10),
        description: ''
      };
    },
    validateField(field) {
      const fromKey = this.transfer.fromAccountId;
      const toKey = this.transfer.toAccountId;

      switch(field) {
        case 'amount':
          this.formErrors.amount = this.transfer.amount > 0 ? '' : 'Məbləğ 0-dan böyük olmalıdır';
          break;
        case 'fromAccountId':
          this.formErrors.fromAccountId = fromKey ? '' : 'Göndərən hesab seçilməlidir';
          if (fromKey && toKey && fromKey === toKey) {
            this.formErrors.fromAccountId = 'Göndərən və qəbul edən hesablar eyni ola bilməz';
            this.transfer.toAccountId = '';
            this.formErrors.toAccountId = '';
          } else if (this.formErrors.toAccountId === 'Göndərən və qəbul edən hesablar eyni ola bilməz') {
            this.formErrors.toAccountId = '';
          }
          break;
        case 'toAccountId':
          this.formErrors.toAccountId = toKey ? '' : 'Qəbul edən hesab seçilməlidir';
          if (fromKey && toKey && fromKey === toKey) {
            this.formErrors.toAccountId = 'Göndərən və qəbul edən hesablar eyni ola bilməz';
          } else if (this.formErrors.fromAccountId === 'Göndərən və qəbul edən hesablar eyni ola bilməz') {
            this.formErrors.fromAccountId = '';
          }
          break;
      }
      this.validateForm();
    },
    validateForm() {
      this.isFormValid =
        this.transfer.amount > 0 &&
        this.transfer.fromAccountId !== '' &&
        this.transfer.toAccountId !== '' &&
        this.transfer.fromAccountId !== this.transfer.toAccountId;
    },
    saveTransfer() {
      if (!this.isFormValid) return;
      const dataToSave = {
        ...this.transfer,
        type: 'transfer'
      };
      this.$emit('save-item', 'transfer', dataToSave);
    }
  },
  mounted() {
    this.accounts = this.$root.accounts || [];
    this.validateForm();
  }
};