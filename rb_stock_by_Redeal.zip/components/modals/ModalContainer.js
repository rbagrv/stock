export default {
  props: ['showModal', 'modalType', 'modalData'],
  watch: {
      showModal(newVal) {
          // Add/remove class to body to prevent background scroll
          if (newVal) {
              document.body.classList.add('modal-open');
          } else {
              document.body.classList.remove('modal-open');
          }
      }
  },
  template: `
    <transition name="modal-fade">
      <div v-if="showModal" class="modal-backdrop" @click.self="handleBackdropClick">
        <component
          :is="modalComponent"
          :modal-data="modalData"
          @close-modal="$emit('close-modal')"
          @save-item="saveItem"
          class="modal-transition">
        </component>
      </div>
    </transition>
  `,
  computed: {
    modalComponent() {
      const modalMap = {
        'productAdd': 'product-modal',
        'productEdit': 'product-modal',
        'productDetails': 'details-modal',
        'customerAdd': 'customer-modal',
        'customerEdit': 'customer-modal',
        'supplierAdd': 'supplier-modal',
        'supplierEdit': 'supplier-modal',
        'saleAdd': 'sale-modal',
        'saleEdit': 'sale-modal',
        'saleDetails': 'details-modal',
        'purchaseAdd': 'purchase-modal',
        'purchaseEdit': 'purchase-modal',
        'purchaseDetails': 'details-modal',
        'userAdd': 'user-modal',
        'userEdit': 'user-modal',
        'productionAdd': 'production-modal',
        'productionEdit': 'production-modal',
        'productionDetails': 'details-modal',
        'categoryAdd': 'category-modal',
        'categoryEdit': 'category-modal',
        'accountAdd': 'account-modal',
        'accountEdit': 'account-modal',
        'incomeAdd': 'income-modal',
        'incomeEdit': 'income-modal',
        'expenseAdd': 'expense-modal',
        'expenseEdit': 'expense-modal',
        'transferAdd': 'transfer-modal',
        'creditAdd': 'credit-modal',
        'transactionDetails': 'details-modal', 
      };

      const componentName = modalMap[this.modalType];
       if (!componentName) {
           console.error(`Modal component not found for type: ${this.modalType}`);
           this.$emit('close-modal'); // Close if component is not found
           return null;
       }
       return componentName;
    }
  },
  methods: {
    saveItem(itemType, itemData) {
      this.$emit('save-item', itemType, itemData);
    },
    handleBackdropClick() {
      this.$emit('close-modal');
    }
  },
  mounted() {
    const handleEscKey = (event) => {
      if (event.key === 'Escape' && this.showModal) {
        this.$emit('close-modal');
      }
    };
    document.addEventListener('keydown', handleEscKey);

    this.$options.beforeUnmount = () => {
      document.removeEventListener('keydown', handleEscKey);
      document.body.classList.remove('modal-open');
    };
  }
};