export default {
  props: ['modalData'],
  data() {
    return {
      account: this.initAccount(),
      accountTypes: [
        { id: 'cash', name: 'Nağd pul' },
        { id: 'bank', name: 'Bank hesabı' },
        { id: 'card', name: 'Kart hesabı' },
        { id: 'asset', name: 'Aktiv' },
        { id: 'liability', name: 'Passiv' },
        { id: 'equity', name: 'Kapital' },
        { id: 'income', name: 'Gəlir' },
        { id: 'expense', name: 'Xərc' }
      ],
      isFormValid: false,
      formErrors: {
        code: '',
        name: '',
        balance: ''
      }
    };
  },
  template: `
    <div class="modal-content">
      <div class="modal-header">
        <h3>{{ isEditing ? 'Hesab Düzəliş' : 'Yeni Hesab' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="accountCode" class="required">Hesab Kodu</label>
          <input
            type="text"
            id="accountCode"
            v-model="account.code"
            @input="validateField('code')"
            :disabled="isEditing"
            required
          >
          <small v-if="formErrors.code" class="form-error">{{ formErrors.code }}</small>
          <small v-if="isEditing" class="helper-text">Hesab kodu dəyişdirilə bilməz.</small>
        </div>

        <div class="form-group">
          <label for="accountName" class="required">Hesab adı</label>
          <input
            type="text"
            id="accountName"
            v-model="account.name"
            @input="validateField('name')"
            required
          >
          <small v-if="formErrors.name" class="form-error">{{ formErrors.name }}</small>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="accountType" class="required">Hesab növü</label>
            <select
              id="accountType"
              v-model="account.type"
              @change="validateField('type')"
              required
            >
              <option v-for="type in accountTypes" :key="type.id" :value="type.id">{{ type.name }}</option>
              <!-- TODO: Consider disabling certain types if editing, based on sub-accounts or transactions -->
            </select>
          </div>

          <div class="form-group">
            <label for="parentAccount">Üst Hesab (Sub-hesab üçün)</label>
            <select id="parentAccount" v-model="account.parentId">
              <option :value="null">Heç biri (Əsas Hesab)</option>
              <!-- Filter out the current account and potentially its children -->
              <option v-for="parent in potentialParentAccounts" :key="parent.code" :value="parent.code">
                {{ parent.name }} ({{ parent.code }})
              </option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="accountBalance" class="required">Başlanğıc Balans</label>
            <input
              type="number"
              id="accountBalance"
              v-model.number="account.balance"
              @input="validateField('balance')"
              step="0.01"
              min="0"
              :disabled="isEditing"
              required
            >
            <small v-if="formErrors.balance" class="form-error">{{ formErrors.balance }}</small>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveAccount" :disabled="!isFormValid">{{ isEditing ? 'Saxla' : 'Əlavə et' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!(this.modalData && this.modalData.code);
    },
    potentialParentAccounts() {
      if (!this.$root.accounts) return [];
      // Filter out the account being edited itself
      return this.$root.accounts.filter(acc => acc.code !== this.account.code);
      // TODO: Add more sophisticated filtering later (e.g., prevent cyclical dependencies)
    }
  },
  methods: {
    initAccount() {
      return this.modalData ? {...this.modalData} : {
        code: '',
        name: '',
        type: 'cash',
        parentId: null,
        balance: 0
      };
    },
    validateField(field) {
      switch(field) {
        case 'code':
          if (!this.isEditing) {
            this.formErrors.code = this.account.code && this.account.code.trim() ? '' : 'Hesab kodu tələb olunur';
            if (this.account.code && /\s/.test(this.account.code)) {
              this.formErrors.code = 'Hesab kodunda boşluq olmamalıdır.';
            } else if (this.account.code && !/^[a-zA-Z0-9_-]+$/.test(this.account.code)) {
              this.formErrors.code = 'Kod yalnız hərflər, rəqəmlər, alt xətt və tire olmalıdır.';
            }
          }
          break;
        case 'name':
          this.formErrors.name = this.account.name && this.account.name.trim() ? '' : 'Hesab adı tələb olunur';
          break;
        case 'balance':
          this.formErrors.balance = this.account.balance !== '' && !isNaN(parseFloat(this.account.balance)) && parseFloat(this.account.balance) >= 0 ? '' : 'Balans düzgün rəqəm olmalı və mənfi olmamalıdır';
          break;
        case 'type':
          // Type is always selected from dropdown, assuming it's valid
          break;
      }

      this.validateForm();
    },
    validateForm() {
      this.isFormValid =
        this.account.code && this.account.code.trim() !== '' && !/\s/.test(this.account.code) && /^[a-zA-Z0-9_-]+$/.test(this.account.code) &&
        this.account.name && this.account.name.trim() !== '' &&
        this.account.type !== '' &&
        // Validate balance only when adding, or make it non-editable when editing in this modal
        (!this.isEditing ? (this.account.balance !== '' && !isNaN(parseFloat(this.account.balance)) && parseFloat(this.account.balance) >= 0) : true) &&
        // Basic check to prevent setting itself as parent
        this.account.parentId !== this.account.code;
    },
    saveAccount() {
      if (!this.isFormValid) {
        // Highlight first invalid field
        if (this.formErrors.code) document.getElementById('accountCode')?.focus();
        else if (this.formErrors.name) document.getElementById('accountName')?.focus();
        else if (this.formErrors.balance) document.getElementById('accountBalance')?.focus();
        this.$root.showNotification('error', 'Xəta', 'Zəhmət olmasa bütün tələb olunan sahələri düzgün doldurun');
        return;
      }

      const accountData = {
        code: this.account.code.trim(),
        name: this.account.name.trim(),
        type: this.account.type,
        parentId: this.account.parentId || null,
        balance: this.isEditing ? this.modalData.balance : (parseFloat(this.account.balance) || 0) // Only set balance on creation
      };

      try {
        this.$emit('save-item', 'account', accountData);
      } catch (error) {
        console.error('Error saving account:', error);
        this.$root.showNotification('error', 'Xəta', `Hesab saxlanılarkən xəta baş verdi: ${error.message || error}`);
      }
    }
  },
  mounted() {
    // Initial validation on mount
    this.validateField('code');
    this.validateField('name');
    this.validateField('balance');
  }
};