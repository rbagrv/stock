export default {
  props: ['modalData'],
  data() {
    return {
      category: this.initCategory(),
      isFormValid: false,
      formErrors: {
        name: ''
      }
    };
  },
  template: `
    <div class="modal-content">
      <div class="modal-header">
        <h3>{{ isEditing ? 'Kateqoriya Düzəliş' : 'Yeni Kateqoriya' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="categoryName" class="required">Kateqoriya adı</label>
          <input 
            type="text" 
            id="categoryName" 
            v-model="category.name" 
            @input="validateField('name')" 
            required
          >
          <small v-if="formErrors.name" class="form-error">{{ formErrors.name }}</small>
        </div>
        
        <div class="form-group">
          <label for="categoryDescription">Təsvir</label>
          <textarea id="categoryDescription" v-model="category.description"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveCategory" :disabled="!isFormValid">{{ isEditing ? 'Saxla' : 'Əlavə et' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.category.id;
    }
  },
  methods: {
    initCategory() {
      return this.modalData ? {...this.modalData} : {
        name: '',
        description: ''
      };
    },
    validateField(field) {
      switch(field) {
        case 'name':
          this.formErrors.name = this.category.name.trim() ? '' : 'Kateqoriya adı tələb olunur';
          break;
      }
      
      // Check overall form validity
      this.validateForm();
    },
    validateForm() {
      this.isFormValid = this.category.name.trim() !== '';
    },
    saveCategory() {
      if (!this.isFormValid) return;
      
      this.$emit('save-item', 'category', this.category);
    }
  },
  mounted() {
    // Validate form initially
    this.validateForm();
  }
};