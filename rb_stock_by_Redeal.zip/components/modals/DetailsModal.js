export default {
  props: ['modalData'],
  computed: {
    // Determine the type based on presence of certain fields
    itemType() {
      if (!this.modalData) return 'unknown';
      if (this.modalData?.items && this.modalData?.customerId !== undefined && this.modalData?.paymentMethod) return 'sale'; // Added paymentMethod check for sale
      if (this.modalData?.items && this.modalData?.supplierId !== undefined && this.modalData?.paymentMethod) return 'purchase'; // Added paymentMethod check for purchase
      if (this.modalData?.items && this.modalData?.output) return 'production';
      if (this.modalData?.type && ['income', 'expense', 'transfer', 'credit'].includes(this.modalData.type)) return 'transaction';
      if (this.modalData?.salePrice !== undefined) return 'product';
      return 'unknown';
    },
    title() {
      switch(this.itemType) {
        case 'sale': return `Satış Detalları (Kod: ${this.modalData.code || this.modalData.id || 'N/A'})`;
        case 'purchase': return `Alış Detalları (Kod: ${this.modalData.code || this.modalData.id || 'N/A'})`;
        case 'production': return `İstehsal Detalları (ID: ${this.modalData.id || 'N/A'})`;
        case 'transaction': return `${this.$root.getItemTypeLabel(this.modalData.type)} Detalları (ID: ${this.modalData.id || 'N/A'})`;
        case 'product': return `Məhsul Detalları (Kod: ${this.modalData.code || 'N/A'})`;
        default: return 'Detallar';
      }
    },
    customerAfterCredit() {
        // Calculate remaining debt for display on credit transaction receipt
        if (this.itemType !== 'transaction' || this.modalData.type !== 'credit' || !this.modalData.customerId || !this.$root.customers) {
          return null; // Return null if not a credit transaction or customer data is unavailable
        }
        const customer = this.$root.customers.find(c => c.id === this.modalData.customerId);
        if (!customer) return null; // Return null if customer not found
        // Calculate debt *after* this transaction. The stored debt is before.
        const remainingDebt = (parseFloat(customer.debt) || 0) - (parseFloat(this.modalData.amount) || 0);
        return remainingDebt;
    },
    // Control visibility of Print and Share buttons
    isPrintable() {
        return ['sale', 'purchase', 'transaction'].includes(this.itemType);
    },
    isSharable() {
        return ['sale', 'purchase', 'transaction'].includes(this.itemType);
    }
  },
  methods: {
    // Use root methods for formatting and names to ensure consistency
    formatCurrency(amount) { return this.$root.formatCurrency(amount); },
    formatDateTime(dateString) { return this.$root.formatDateTime(dateString); },
    getCustomerName(id) { return this.$root.getCustomerName(id); },
    getSupplierName(id) { return this.$root.getSupplierName(id); },
    getProductName(id) {
      const product = this.$root?.products?.find(p => p.id === id);
      return product ? product.name : 'Naməlum';
    },
    getProductUnit(id) {
      const product = this.$root?.products?.find(p => p.id === id);
      return product ? product.unit : '';
    },
    getAccountName(id) { return this.$root.getAccountName(id); },
    getPaymentMethodLabel(method) { return this.$root.getPaymentMethodLabel(method); },
    getItemTypeLabel(type) { return this.$root.getItemTypeLabel(type); },
    getTransactionTypeClass(type) { return this.$root.getTransactionTypeClass(type); },

    // Enhanced Print Method with improved styling and company info
    printDetails() {
        if (!this.isPrintable) {
            this.$root.showNotification('info', 'Çap edilə bilmir', 'Bu element üçün çap funksiyası mövcud deyil.');
            return;
        }

        const printWindow = window.open('', '_blank', 'height=600,width=800'); // Specify window size
        if (!printWindow) {
            this.$root.showNotification('warning', 'Popup Bloklandı', 'Zəhmət olmasa popup blokerini söndürün.');
            return;
        }

        // Get settings safely
        const companySettings = this.$root.settings?.general || {};
        const invoiceSettings = this.$root.settings?.invoices || {};
        const item = this.modalData;
        const itemTypeCode = item.code || item.id || 'N/A';
        const itemDate = this.formatDateTime(item.date);

        // --- CSS Styles for Print ---
        const styles = `
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 15px; font-size: 10pt; color: #333; }
            .receipt-container { max-width: 750px; margin: auto; padding: 20px; border: 1px solid #eee; background: #fff; }
            .receipt-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #ccc; }
            .receipt-title { font-size: 16pt; font-weight: bold; color: #2e5bff; margin-bottom: 5px; }
            .receipt-code { font-size: 10pt; color: #555; }
            .company-info { text-align: right; font-size: 9pt; line-height: 1.4; max-width: 40%; }
            .company-info strong { font-size: 10pt; display: block; margin-bottom: 3px; }
            .company-logo { max-width: 150px; max-height: 60px; margin-bottom: 5px; }
            .receipt-details, .party-info { margin-bottom: 15px; line-height: 1.6; font-size: 10pt; }
            .receipt-details strong, .party-info strong { display: inline-block; min-width: 90px; font-weight: 600; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 9pt; }
            th, td { padding: 6px 8px; text-align: left; border-bottom: 1px solid #eee; }
            th { background-color: #f8f9fa; font-weight: 600; border-bottom-width: 1px; border-bottom-color: #ddd; }
            td { vertical-align: top; }
            .text-right { text-align: right; }
            .total-section { margin-top: 20px; padding-top: 10px; border-top: 1px solid #ccc; text-align: right; float: right; width: 40%; } /* Float right */
            .total-section div { margin-bottom: 4px; font-size: 10pt; display: flex; justify-content: space-between; }
            .total-section div span:first-child { text-align: left; font-weight: 500; margin-right: 15px; }
            .total-section div span:last-child { text-align: right; font-weight: 600; }
            .grand-total span { font-weight: bold !important; font-size: 11pt !important; color: #2e5bff; }
            .notes { clear: both; margin-top: 30px; padding-top: 15px; border-top: 1px dashed #ddd; font-size: 9pt; color: #555; }
            .notes strong { display: block; margin-bottom: 3px; }
            .footer { clear: both; margin-top: 40px; text-align: center; font-size: 8pt; color: #888; }
            .print-button { display: block; margin: 20px auto; padding: 8px 16px; background: #2e5bff; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; }
            @media print {
                @page { size: A4; margin: 15mm; } /* Control print margins */
                body { margin: 0; padding: 0; font-size: 10pt; -webkit-print-color-adjust: exact; print-color-adjust: exact; } /* Ensure colors print */
                .receipt-container { border: none; box-shadow: none; padding: 0; width: 100%; max-width: 100%; }
                .print-button { display: none; }
                .total-section { width: 50%; } /* Adjust width for print */
            }
        `;

        // --- HTML Content Generation ---
        let content = `<!DOCTYPE html><html lang="az"><head><meta charset="UTF-8"><title>${this.title}</title><style>${styles}</style></head><body><div class="receipt-container">`;

        // Header: Title, Code, Company Info & Logo
        content += `<div class="receipt-header">
                        <div>
                            <div class="receipt-title">${this.itemType === 'transaction' ? this.getItemTypeLabel(item.type) : (this.itemType === 'sale' ? 'Satış Qəbzi' : 'Alış Qəbzi')}</div>
                            <div class="receipt-code">№: ${itemTypeCode}</div>
                        </div>
                        <div class="company-info">`;
        // Add logo if available and enabled in settings
        if (companySettings.logo && invoiceSettings.showLogo) {
            content += `<img src="${companySettings.logo}" class="company-logo" alt="Logo"><br>`;
        }
        // Add company details
        content += `<strong>${companySettings.companyName || 'Şirkət Adı'}</strong>`;
        if (companySettings.address) content += `${companySettings.address}<br>`;
        if (companySettings.phone) content += `Tel: ${companySettings.phone}<br>`;
        if (companySettings.email) content += `Email: ${companySettings.email}`;
        content += `</div></div>`;

        // Details Section: Date, Payment Method, Accounts, etc.
        content += `<div class="receipt-details">
                      <div><strong>Tarix:</strong> <span>${itemDate}</span></div>`;
        if (this.itemType === 'sale' || this.itemType === 'purchase') {
            content += `<div><strong>Ödəniş Metodu:</strong> <span>${this.getPaymentMethodLabel(item.paymentMethod)}</span></div>`;
        }
        if (item.invoiceNumber) content += `<div><strong>Faktura №:</strong> <span>${item.invoiceNumber}</span></div>`;
        // Transaction specific details
        if (this.itemType === 'transaction') {
            if (item.type !== 'transfer') content += `<div><strong>Hesab:</strong> <span>${this.getAccountName(item.accountId)}</span></div>`;
            if (item.type === 'transfer') {
                content += `<div><strong>Göndərən Hesab:</strong> <span>${this.getAccountName(item.fromAccountId)}</span></div>`;
                content += `<div><strong>Qəbul Edən Hesab:</strong> <span>${this.getAccountName(item.toAccountId)}</span></div>`;
            }
            if (item.category) content += `<div><strong>Kateqoriya:</strong> <span>${item.category}</span></div>`;
            if (item.reference) content += `<div><strong>Referans:</strong> <span>${item.reference}</span></div>`;
        }
        content += `</div>`;

        // Party Info: Customer or Supplier Details
        content += `<div class="party-info">`;
        if (this.itemType === 'sale' || (this.itemType === 'transaction' && item.customerId)) {
            content += `<div><strong>Müştəri:</strong> <span>${this.getCustomerName(item.customerId)}</span></div>`;
        }
        if (this.itemType === 'purchase') {
            content += `<div><strong>Təchizatçı:</strong> <span>${this.getSupplierName(item.supplierId)}</span></div>`;
        }
        content += `</div>`;

        // Items Table (for Sale/Purchase/Production)
        if (['sale', 'purchase', 'production'].includes(this.itemType) && item.items?.length > 0) {
            content += `<h4>${this.itemType === 'production' ? 'Giriş Məhsulları' : 'Məhsullar'}:</h4><table><thead><tr>`;
            if (this.itemType === 'production') {
                content += `<th>Məhsul</th><th>Miqdar</th>`;
            } else {
                // Added '№' column
                content += `<th style="width: 5%;">№</th><th>Məhsul</th><th>Qiymət</th><th>Miqdar</th><th>Endirim (%)</th><th class="text-right">Cəmi</th>`;
            }
            content += `</tr></thead><tbody>`;
            item.items.forEach((i, index) => {
                content += `<tr>`;
                if (this.itemType === 'production') {
                    content += `<td>${this.getProductName(i.productId)}</td><td>${i.quantity} ${this.getProductUnit(i.productId)}</td>`;
                } else {
                    content += `<td>${index + 1}</td>
                                <td>${i.productName || this.getProductName(i.productId)}</td>
                                <td>${this.formatCurrency(i.price)}</td>
                                <td>${i.quantity} ${this.getProductUnit(i.productId) || ''}</td>
                                <td>${i.discount || 0}</td>
                                <td class="text-right">${this.formatCurrency(i.total)}</td>`;
                }
                content += `</tr>`;
            });
            content += `</tbody></table>`;

            // Production Output Table
            if (this.itemType === 'production' && item.output?.length > 0) {
                 content += `<h4 class="mt-3">Çıxış Məhsulları:</h4><table><thead><tr><th>Məhsul</th><th>Miqdar</th></tr></thead><tbody>`;
                 item.output.forEach(o => {
                     content += `<tr><td>${this.getProductName(o.productId)}</td><td>${o.quantity} ${this.getProductUnit(o.productId)}</td></tr>`;
                 });
                 content += `</tbody></table>`;
            }
        }

        // Total Section: Subtotal, Discounts, Taxes, Grand Total
        if (['sale', 'purchase', 'transaction'].includes(this.itemType)) {
            content += `<div class="total-section">`;
            const baseAmount = item.subtotal !== undefined ? item.subtotal : (item.amount || item.totalAmount || 0);
            const discountPercent = item.discount || 0;
            const discountAmount = baseAmount * (discountPercent / 100);
            const totalTax = item.totalTax || 0;
            const finalAmount = item.amount !== undefined ? item.amount : (item.totalAmount || 0);

            // Show subtotal only if different from final amount AND not a simple transaction
            if (item.subtotal !== undefined && item.subtotal !== finalAmount && this.itemType !== 'transaction') {
                 content += `<div><span>Ara Cəm:</span> <span>${this.formatCurrency(item.subtotal)}</span></div>`;
            }
            // Show overall discount if applicable
            if (discountPercent > 0) {
                 content += `<div><span>Ümumi Endirim (${discountPercent}%):</span> <span>-${this.formatCurrency(discountAmount)}</span></div>`;
            }
            // Show total tax if applicable and enabled in settings
            if (totalTax > 0 && (invoiceSettings.showTaxes ?? true)) { // Default to showing taxes if setting is missing
                 content += `<div><span>Cəmi ƏDV:</span> <span>${this.formatCurrency(totalTax)}</span></div>`;
            }
            // Grand Total / Amount
             const finalAmountLabel = this.itemType === 'transaction' ? this.getItemTypeLabel(item.type) : 'Yekun Məbləğ';
            content += `<div class="grand-total"><span>${finalAmountLabel}:</span> <span>${this.formatCurrency(finalAmount)}</span></div>`;

            // Show remaining debt for credit transactions after the payment
             if (this.itemType === 'transaction' && item.type === 'credit' && this.customerAfterCredit !== null) {
                 content += `<div style="margin-top: 10px; font-style: italic;"><span>Qalıq Borc:</span> <span>${this.formatCurrency(this.customerAfterCredit)}</span></div>`;
             }
            content += `</div>`;
        }

        // Notes section
        content += `<div class="notes">`;
        if (item.description || item.note || item.notes) {
            content += `<strong>Qeyd:</strong><br>${item.description || item.note || item.notes}<br><br>`;
        }
        if (invoiceSettings.termsAndConditions) {
             content += `<strong>Şərtlər:</strong><br>${invoiceSettings.termsAndConditions}`;
        }
        content += `</div>`;

        // Footer
        content += `<div class="footer">${invoiceSettings.footerText || `© ${new Date().getFullYear()} ${companySettings.companyName || 'Anbar İdarəetmə Sistemi'}`}</div>`;

        // End container and add print button for the preview window
        content += `</div><button class="print-button" onclick="window.print();">Çap et</button></body></html>`;

        printWindow.document.open();
        printWindow.document.write(content);
        printWindow.document.close();
        // Optional: Add focus to the new window for immediate printing
        // printWindow.focus();
        // printWindow.print(); // Automatically trigger print dialog (can be blocked by browser)
    },

    // Share Method using Web Share API and WhatsApp fallback
    shareDetails() {
        if (!this.isSharable) {
            this.$root.showNotification('info', 'Paylaşma Mümkün Deyil', 'Bu element üçün paylaşma funksiyası mövcud deyil.');
            return;
        }

        const item = this.modalData;
        const itemTypeCode = item.code || item.id || 'N/A';
        const itemDate = this.formatDateTime(item.date);
        const companyName = this.$root.settings?.general?.companyName || 'Anbar Sistemi';
        const amountFormatted = this.formatCurrency(item.amount || item.totalAmount);
        let shareTitle = '';
        let shareText = `*${companyName}*\n--------------------\n`; // Base text with company name

        // Build share text based on item type
        if (this.itemType === 'sale') {
            shareTitle = `Satış Qəbzi: ${itemTypeCode}`;
            shareText += `*Satış Qəbzi*\n№: ${itemTypeCode}\nMüştəri: ${this.getCustomerName(item.customerId)}\nTarix: ${itemDate}\nÖdəniş: ${this.getPaymentMethodLabel(item.paymentMethod)}\n\n*Məhsullar:*\n`;
            item.items.forEach(i => {
                shareText += `- ${i.productName}: ${i.quantity} x ${this.formatCurrency(i.price)} ${i.discount > 0 ? `(${i.discount}% endirim)` : ''} = ${this.formatCurrency(i.total)}\n`;
            });
            shareText += `\n`;
             if (item.discount) shareText += `Ümumi Endirim: ${item.discount}%\n`;
             if (item.totalTax > 0 && (this.$root.settings?.invoices?.showTaxes ?? true)) {
                  shareText += `Cəmi ƏDV: ${this.formatCurrency(item.totalTax)}\n`;
             }
            shareText += `*Yekun Məbləğ: ${amountFormatted}*\n`;
        } else if (this.itemType === 'purchase') {
            shareTitle = `Alış Qəbzi: ${itemTypeCode}`;
            shareText += `*Alış Qəbzi*\n№: ${itemTypeCode}\nTəchizatçı: ${this.getSupplierName(item.supplierId)}\nTarix: ${itemDate}\n`;
             if (item.invoiceNumber) shareText += `Faktura №: ${item.invoiceNumber}\n`;
             shareText += `\n*Məhsullar:*\n`;
             item.items.forEach(i => {
                 shareText += `- ${i.productName}: ${i.quantity} x ${this.formatCurrency(i.price)} ${i.discount > 0 ? `(${i.discount}% endirim)` : ''} = ${this.formatCurrency(i.total)}\n`;
             });
             shareText += `\n`;
             if (item.discount) shareText += `Ümumi Endirim: ${item.discount}%\n`;
            shareText += `*Yekun Məbləğ: ${amountFormatted}*\n`;
        } else if (this.itemType === 'transaction') {
            const typeLabel = this.getItemTypeLabel(item.type);
            shareTitle = `${typeLabel} Qəbzi: ${itemTypeCode}`;
            shareText += `*${typeLabel} Qəbzi*\nID: ${itemTypeCode}\nTarix: ${itemDate}\n`;
             if (item.type !== 'transfer') shareText += `Hesab: ${this.getAccountName(item.accountId)}\n`;
             if (item.type === 'transfer') shareText += `Göndərən: ${this.getAccountName(item.fromAccountId)}\nQəbul Edən: ${this.getAccountName(item.toAccountId)}\n`;
             if (item.customerId) shareText += `Müştəri: ${this.getCustomerName(item.customerId)}\n`;
             if (item.category) shareText += `Kateqoriya: ${item.category}\n`;
             if (item.reference) shareText += `Referans: ${item.reference}\n`;
            shareText += `*Məbləğ: ${amountFormatted}*\n`;
             // Add remaining debt for credit payments
             if (item.type === 'credit' && this.customerAfterCredit !== null) {
                 shareText += `_(Qalıq Borc: ${this.formatCurrency(this.customerAfterCredit)})_\n`; // Use italics for note
             }
        }

        // Add notes/description if available
        if (item.description || item.note || item.notes) {
            shareText += `\nQeyd: ${item.description || item.note || item.notes}`;
        }

        // Try using Web Share API first
        if (navigator.share) {
            navigator.share({
                title: shareTitle,
                text: shareText,
            }).then(() => {
                console.log('Details shared successfully!');
            }).catch((error) => console.error('Error sharing:', error));
        } else {
            // Fallback for browsers without Web Share API (e.g., desktop)
            // Offer WhatsApp link and Copy to Clipboard
            console.log("Web Share API not supported, using fallback.");
            const whatsappLink = `https://wa.me/?text=${encodeURIComponent(shareText)}`;

            this.$root.showDialog({
                title: 'Paylaş',
                message: 'Mətni kopyalayın və ya WhatsApp vasitəsilə göndərin.',
                confirmText: 'Kopyala',
                cancelText: 'WhatsApp',
                confirmButtonClass: 'btn-secondary',
                cancelButtonClass: 'btn-success', // Custom class for WhatsApp button
                onConfirm: () => { // Copy action
                    try {
                        navigator.clipboard.writeText(shareText).then(() => {
                            this.$root.showNotification('success', 'Kopyalandı', 'Mətn müvəffəqiyyətlə kopyalandı.');
                        }, (err) => {
                            console.error('Could not copy text: ', err);
                             this.$root.showNotification('error', 'Xəta', 'Mətni kopyalamaq mümkün olmadı.');
                        });
                    } catch (err) {
                        console.error('Clipboard API error:', err);
                         this.$root.showNotification('error', 'Xəta', 'Mətni kopyalamaq mümkün olmadı.');
                    }
                },
                onCancel: () => { // WhatsApp action
                    window.open(whatsappLink, '_blank');
                }
            });
        }
    }
  },
  template: `
    <div class="modal-content details-modal">
      <div class="modal-header">
        <h3>{{ title }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="modal-body">

        <!-- Sale Details -->
        <div v-if="itemType === 'sale' && modalData">
          <p><strong>Müştəri:</strong> {{ getCustomerName(modalData.customerId) }}</p>
          <p><strong>Tarix:</strong> {{ formatDateTime(modalData.date) }}</p>
          <p><strong>Ödəniş Metodu:</strong> {{ getPaymentMethodLabel(modalData.paymentMethod) }}</p>
          <p><strong>Ümumi Məbləğ:</strong> {{ formatCurrency(modalData.totalAmount) }}</p>
           <p><strong>Ümumi Endirim:</strong> {{ modalData.discount || 0 }}%</p>
           <p v-if="modalData.totalTax > 0"><strong>Cəmi ƏDV:</strong> {{ formatCurrency(modalData.totalTax) }}</p>
          <p v-if="modalData.note"><strong>Qeyd:</strong> {{ modalData.note }}</p>
          <h4 class="mt-3">Məhsullar:</h4>
          <div class="table-responsive">
            <table>
              <thead><tr><th>№</th><th>Məhsul</th><th>Qiymət</th><th>Miqdar</th><th>Endirim (%)</th><th class="text-right">Cəmi</th></tr></thead>
              <tbody>
                <tr v-for="(item, index) in modalData.items" :key="index">
                  <td>{{ index + 1 }}</td>
                  <td>{{ item.productName || getProductName(item.productId) }}</td>
                  <td>{{ formatCurrency(item.price) }}</td>
                  <td>{{ item.quantity }} {{ getProductUnit(item.productId) }}</td>
                  <td>{{ item.discount || 0 }}</td>
                  <td class="text-right">{{ formatCurrency(item.total) }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Purchase Details -->
        <div v-else-if="itemType === 'purchase' && modalData">
          <p><strong>Təchizatçı:</strong> {{ getSupplierName(modalData.supplierId) }}</p>
          <p><strong>Tarix:</strong> {{ formatDateTime(modalData.date) }}</p>
           <p><strong>Faktura №:</strong> {{ modalData.invoiceNumber || '-' }}</p>
          <p><strong>Ödəniş Metodu:</strong> {{ getPaymentMethodLabel(modalData.paymentMethod) }}</p>
          <p><strong>Ümumi Məbləğ:</strong> {{ formatCurrency(modalData.totalAmount) }}</p>
          <p><strong>Ümumi Endirim:</strong> {{ modalData.discount || 0 }}%</p>
          <p v-if="modalData.note"><strong>Qeyd:</strong> {{ modalData.note }}</p>
          <h4 class="mt-3">Məhsullar:</h4>
          <div class="table-responsive">
            <table>
               <thead><tr><th>№</th><th>Məhsul</th><th>Qiymət</th><th>Miqdar</th><th>Endirim (%)</th><th class="text-right">Cəmi</th></tr></thead>
              <tbody>
                <tr v-for="(item, index) in modalData.items" :key="index">
                  <td>{{ index + 1 }}</td>
                  <td>{{ item.productName || getProductName(item.productId) }}</td>
                  <td>{{ formatCurrency(item.price) }}</td>
                  <td>{{ item.quantity }} {{ getProductUnit(item.productId) }}</td>
                  <td>{{ item.discount || 0 }}</td>
                  <td class="text-right">{{ formatCurrency(item.total) }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Production Details -->
        <div v-else-if="itemType === 'production' && modalData">
           <p><strong>İstehsal Adı:</strong> {{ modalData.name }}</p>
           <p><strong>Status:</strong> {{ modalData.status }}</p>
           <p><strong>Başlama Tarixi:</strong> {{ formatDateTime(modalData.startDate) }}</p>
           <p><strong>Bitmə Tarixi:</strong> {{ modalData.endDate ? formatDateTime(modalData.endDate) : '-' }}</p>
           <p v-if="modalData.notes"><strong>Qeydlər:</strong> {{ modalData.notes }}</p>
           <h4 class="mt-3">Giriş Məhsulları:</h4>
           <div class="table-responsive">
             <table>
               <thead><tr><th>Məhsul</th><th>Miqdar</th></tr></thead>
               <tbody>
                 <tr v-for="(item, index) in modalData.items" :key="'in-'+index">
                   <td>{{ getProductName(item.productId) }}</td>
                   <td>{{ item.quantity }} {{ getProductUnit(item.productId) }}</td>
                 </tr>
               </tbody>
             </table>
           </div>
           <h4 class="mt-3">Çıxış Məhsulları:</h4>
           <div class="table-responsive" v-if="modalData.output && modalData.output.length > 0">
             <table>
               <thead><tr><th>Məhsul</th><th>Miqdar</th></tr></thead>
               <tbody>
                 <tr v-for="(item, index) in modalData.output" :key="'out-'+index">
                   <td>{{ getProductName(item.productId) }}</td>
                   <td>{{ item.quantity }} {{ getProductUnit(item.productId) }}</td>
                 </tr>
               </tbody>
             </table>
           </div>
            <div class="empty-state" v-else>
                <p>Çıxış məhsulu təyin edilməyib.</p>
            </div>
        </div>

        <!-- Transaction Details -->
        <div v-else-if="itemType === 'transaction' && modalData">
          <p><strong>Tip:</strong> <span :class="getTransactionTypeClass(modalData.type)">{{ getItemTypeLabel(modalData.type) }}</span></p>
          <p><strong>Tarix:</strong> {{ formatDateTime(modalData.date) }}</p>
          <p><strong>Məbləğ:</strong> {{ formatCurrency(modalData.amount) }}</p>
          <p v-if="modalData.type !== 'transfer'"><strong>Hesab:</strong> {{ getAccountName(modalData.accountId) }}</p>
          <p v-if="modalData.type === 'transfer'"><strong>Göndərən Hesab:</strong> {{ getAccountName(modalData.fromAccountId) }}</p>
          <p v-if="modalData.type === 'transfer'"><strong>Qəbul Edən Hesab:</strong> {{ getAccountName(modalData.toAccountId) }}</p>
          <p v-if="modalData.customerId"><strong>Müştəri:</strong> {{ getCustomerName(modalData.customerId) }}</p>
          <!-- Display remaining debt only for credit transactions -->
          <p v-if="modalData.type === 'credit' && customerAfterCredit !== null"><strong>Qalıq Borc:</strong> {{ formatCurrency(customerAfterCredit) }}</p>
          <p v-if="modalData.category"><strong>Kateqoriya:</strong> {{ modalData.category }}</p>
          <p v-if="modalData.reference"><strong>Referans:</strong> {{ modalData.reference }}</p>
          <p v-if="modalData.description"><strong>Təsvir:</strong> {{ modalData.description }}</p>
        </div>

        <!-- Product Details -->
        <div v-else-if="itemType === 'product' && modalData">
          <p><strong>Məhsul Adı:</strong> {{ modalData.name }}</p>
          <p><strong>Kod:</strong> <span class="badge badge-primary">{{ modalData.code }}</span></p>
          <p><strong>Kateqoriya:</strong> {{ $root.categories?.find(c=>c.id === modalData.categoryId)?.name || 'Təyin edilməyib' }}</p>
          <p><strong>Alış Qiyməti:</strong> {{ formatCurrency(modalData.purchasePrice) }}</p>
          <p><strong>Satış Qiyməti:</strong> {{ formatCurrency(modalData.salePrice) }}</p>
          <p><strong>Stok Miqdarı:</strong> {{ modalData.quantity }} {{ modalData.unit }}</p>
          <p><strong>Ölçü Vahidi:</strong> {{ modalData.unit }}</p>
          <p><strong>Barkod:</strong> {{ modalData.barcode || '-' }}</p>
          <p><strong>ƏDV-yə cəlb olunur:</strong> {{ modalData.isTaxable ? 'Bəli' : 'Xeyr' }}</p>
          <p v-if="modalData.description"><strong>Əlavə Məlumat:</strong> {{ modalData.description }}</p>
        </div>

        <!-- Unknown Type or No Data -->
        <div v-else>
          <p>Göstəriləcək detallar tapılmadı.</p>
          <pre v-if="modalData">{{ JSON.stringify(modalData, null, 2) }}</pre>
        </div>
      </div>
      <div class="modal-footer">
        <!-- Share Button -->
        <button v-if="isSharable" class="btn btn-secondary" @click="shareDetails">
           <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
            Paylaş
        </button>
        <!-- Print Button -->
        <button v-if="isPrintable" class="btn btn-secondary" @click="printDetails">
           <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
            Çap et
        </button>
        <!-- Close Button -->
        <button class="btn btn-primary" @click="$emit('close-modal')">Bağla</button>
      </div>
    </div>
  `
};