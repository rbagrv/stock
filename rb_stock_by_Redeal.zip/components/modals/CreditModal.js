export default {
  props: ['modalData'],
  data() {
    return {
      credit: this.initCredit(),
      customers: [],
      accounts: [], 
      paymentMethods: ['cash', 'card', 'bank'], 
      isSubmitting: false
    };
  },
  template: `
    <div class="modal-content credit-modal">
      <div class="modal-header">
        <h3>Kredit Ödəməsi Qeydi</h3> 
        <button class="btn-close" @click="$emit('close-modal')">
           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="customerSelect" class="required">Müştəri</label>
          <select id="customerSelect" v-model="credit.customerId" required>
            <option value="">Müştəri seçin</option>
            <option v-for="customer in customers" :key="customer.id" :value="customer.id">
              {{ customer.name }} {{ customer.debt > 0 ? `(Borc: ${formatCurrency(customer.debt)})` : '' }}
            </option>
          </select>
          <small v-if="!credit.customerId" class="form-error">Müştəri seçimi vacibdir</small>
        </div>

         <div class="form-row">
             <div class="form-group">
               <label for="creditAmount" class="required">Məbləğ</label>
               <input type="number" id="creditAmount" v-model.number="credit.amount" min="0.01" step="0.01" required>
               <small v-if="credit.amount <= 0" class="form-error">Məbləğ müsbət olmalıdır</small>
             </div>
              <div class="form-group">
                <label for="creditDate">Tarix</label>
                <input type="date" id="creditDate" v-model="credit.date">
              </div>
         </div>

         <div class="form-group">
            <label for="accountSelect" class="required">Hesab</label> 
            <select id="accountSelect" v-model="credit.accountId" required>
              <option value="">Hesab seçin</option>
              <option v-for="account in accounts" :key="account.code || account.id" :value="account.id || account.code">
                 {{ account.name }} ({{ account.code }})
              </option>
            </select>
            <small v-if="!credit.accountId" class="form-error">Hesab seçimi vacibdir</small>
          </div>


         <!-- Remove Payment Method - handled by account selection -->


        <div class="form-group">
          <label for="creditNote">Qeyd</label>
          <textarea id="creditNote" v-model="credit.description" rows="3"></textarea> 
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')" :disabled="isSubmitting">Ləğv et</button>
        <button class="btn btn-primary" @click="saveCredit" :disabled="!isValid || isSubmitting">
          <span v-if="isSubmitting">
            <svg class="spinner-icon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/></svg>
            Saxlanılır...
          </span>
          <span v-else>Yadda saxla</span>
        </button>
      </div>
    </div>
  `,
  computed: {
    isValid() {
      return this.credit.customerId && this.credit.accountId && this.credit.amount > 0; 
    }
  },
  methods: {
    initCredit() {
      return this.modalData ? {...this.modalData} : {
        customerId: '',
        accountId: '', 
        amount: '',
        date: new Date().toISOString().slice(0, 10),
        description: '' 
      };
    },
     formatCurrency(amount) {
       if (amount === null || amount === undefined || isNaN(parseFloat(amount))) return '0.00 ₼';
       return parseFloat(amount).toFixed(2) + ' ₼';
     },
    async saveCredit() {
      if (!this.isValid) return;

      this.isSubmitting = true;

      try {
        const creditData = {
          customerId: this.credit.customerId,
          accountId: this.credit.accountId,
          amount: this.credit.amount,
          date: this.credit.date || new Date().toISOString(),
          description: this.credit.description,
          type: 'credit' 
        };

        this.$emit('save-item', 'credit', creditData);
      } catch (error) {
        console.error('Error saving credit:', error);
         this.$root.showNotification('error', 'Xəta', `Kredit ödəməsi saxlanılarkən xəta baş verdi: ${error.message || error}`);
      } finally {
        this.isSubmitting = false;
      }
    }
  },
  mounted() {
    this.customers = this.$root.customers || [];
    this.accounts = this.$root.accounts || []; 
  }
};