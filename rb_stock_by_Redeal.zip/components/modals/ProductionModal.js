export default {
  props: ['modalData'],
  data() {
    return {
      production: this.initProduction(),
      products: [],
      statuses: [
        { id: 'planned', name: 'Planlaşdırılmış' },
        { id: 'in-progress', name: 'İcra edilir' },
        { id: 'completed', name: 'Tamamlanmış' },
        { id: 'canceled', name: 'Ləğv edilmiş' }
      ],
      inputItems: [],
      outputItems: [],
      newInputProduct: '',
      newInputQuantity: 1,
      newOutputProduct: '',
      newOutputQuantity: 1,
      isFormValid: false,
      formErrors: {
        name: '',
        items: '',
        output: ''
      }
    };
  },
  template: `
    <div class="modal-content production-modal">
      <div class="modal-header">
        <h3>{{ isEditing ? 'İstehsal Düzəliş' : 'Yeni İstehsal' }}</h3>
        <button class="btn-close" @click="$emit('close-modal')">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="productionName" class="required">İstehsal adı</label>
          <input 
            type="text" 
            id="productionName" 
            v-model="production.name" 
            @input="validateField('name')" 
            required
          >
          <small v-if="formErrors.name" class="form-error">{{ formErrors.name }}</small>
        </div>
        
        <div class="form-row">
          <div class="form-group">
            <label for="productionStatus">Status</label>
            <select id="productionStatus" v-model="production.status">
              <option v-for="status in statuses" :key="status.id" :value="status.id">{{ status.name }}</option>
            </select>
          </div>
          
          <div class="form-group">
            <label for="startDate">Başlama tarixi</label>
            <input type="date" id="startDate" v-model="production.startDate">
          </div>
          
          <div class="form-group">
            <label for="endDate">Bitmə tarixi</label>
            <input type="date" id="endDate" v-model="production.endDate">
          </div>
        </div>
        
        <h4>Giriş məhsulları</h4>
        <small v-if="formErrors.items" class="form-error">{{ formErrors.items }}</small>
        <div class="input-with-button">
          <select v-model="newInputProduct">
            <option value="">Məhsul seçin</option>
            <option v-for="product in products" :key="product.id" :value="product.id">
              {{ product.name }} ({{ product.code }}) - Stok: {{ product.quantity }} {{ product.unit }}
            </option>
          </select>
          <input type="number" v-model.number="newInputQuantity" min="1" placeholder="Miqdar">
          <button class="add-btn" @click="addInputProduct">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
          </button>
        </div>
        
        <div class="table-responsive" v-if="inputItems.length > 0">
          <table>
            <thead>
              <tr>
                <th>Məhsul</th>
                <th>Miqdar</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in inputItems" :key="index">
                <td>{{ getProductName(item.productId) }}</td>
                <td>{{ item.quantity }} {{ getProductUnit(item.productId) }}</td>
                <td>
                  <button class="btn-delete" @click="removeInputItem(index)">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <h4 class="mt-4">Çıxış məhsulları</h4>
        <small v-if="formErrors.output" class="form-error">{{ formErrors.output }}</small>
        <div class="input-with-button">
          <select v-model="newOutputProduct">
            <option value="">Məhsul seçin</option>
            <option v-for="product in products" :key="product.id" :value="product.id">
              {{ product.name }} ({{ product.code }})
            </option>
          </select>
          <input type="number" v-model.number="newOutputQuantity" min="1" placeholder="Miqdar">
          <button class="add-btn" @click="addOutputProduct">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
          </button>
        </div>
        
        <div class="table-responsive" v-if="outputItems.length > 0">
          <table>
            <thead>
              <tr>
                <th>Məhsul</th>
                <th>Miqdar</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in outputItems" :key="index">
                <td>{{ getProductName(item.productId) }}</td>
                <td>{{ item.quantity }} {{ getProductUnit(item.productId) }}</td>
                <td>
                  <button class="btn-delete" @click="removeOutputItem(index)">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div class="form-group mt-4">
          <label for="notes">Qeydlər</label>
          <textarea id="notes" v-model="production.notes"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" @click="$emit('close-modal')">Ləğv et</button>
        <button class="btn btn-primary" @click="saveProduction" :disabled="!isFormValid">{{ isEditing ? 'Saxla' : 'Əlavə et' }}</button>
      </div>
    </div>
  `,
  computed: {
    isEditing() {
      return !!this.production.id;
    }
  },
  methods: {
    initProduction() {
      if (this.modalData) {
        // Clone the modal data
        const production = {...this.modalData};
        
        // Set input and output items
        this.inputItems = production.items ? [...production.items] : [];
        this.outputItems = production.output ? [...production.output] : [];
        
        return production;
      } else {
        return {
          name: '',
          status: 'planned',
          startDate: new Date().toISOString().slice(0, 10),
          endDate: '',
          notes: ''
        };
      }
    },
    getProductName(productId) {
      const product = this.products.find(p => p.id === productId);
      return product ? product.name : 'Naməlum məhsul';
    },
    getProductUnit(productId) {
      const product = this.products.find(p => p.id === productId);
      return product ? product.unit : '';
    },
    addInputProduct() {
      if (!this.newInputProduct || this.newInputQuantity <= 0) return;
      
      const productId = this.newInputProduct;
      const existingItemIndex = this.inputItems.findIndex(item => item.productId === productId);
      const product = this.products.find(p => p.id === productId);
      
      // Check if product has enough stock
      if (product && this.newInputQuantity > product.quantity) {
        this.$root.showNotification('warning', 'Stok xətası', `${product.name} məhsulundan stokda yalnız ${product.quantity} ədəd var`, 3000);
        return;
      }
      
      if (existingItemIndex >= 0) {
        // Check if there's enough stock for additional quantity
        const totalRequestedQuantity = this.inputItems[existingItemIndex].quantity + this.newInputQuantity;
        if (product && totalRequestedQuantity > product.quantity) {
          this.$root.showNotification('warning', 'Stok xətası', `${product.name} məhsulundan stokda yalnız ${product.quantity} ədəd var`, 3000);
          return;
        }
        
        // Update quantity if product already exists
        this.inputItems[existingItemIndex].quantity += this.newInputQuantity;
      } else {
        // Add new item
        this.inputItems.push({
          productId,
          quantity: this.newInputQuantity
        });
      }
      
      // Reset form
      this.newInputProduct = '';
      this.newInputQuantity = 1;
      
      // Validate
      this.validateField('items');
    },
    removeInputItem(index) {
      this.inputItems.splice(index, 1);
      this.validateField('items');
    },
    addOutputProduct() {
      if (!this.newOutputProduct || this.newOutputQuantity <= 0) return;
      
      const productId = this.newOutputProduct;
      const existingItemIndex = this.outputItems.findIndex(item => item.productId === productId);
      
      if (existingItemIndex >= 0) {
        // Update quantity if product already exists
        this.outputItems[existingItemIndex].quantity += this.newOutputQuantity;
      } else {
        // Add new item
        this.outputItems.push({
          productId,
          quantity: this.newOutputQuantity
        });
      }
      
      // Reset form
      this.newOutputProduct = '';
      this.newOutputQuantity = 1;
      
      // Validate
      this.validateField('output');
    },
    removeOutputItem(index) {
      this.outputItems.splice(index, 1);
      this.validateField('output');
    },
    validateField(field) {
      switch(field) {
        case 'name':
          this.formErrors.name = this.production.name.trim() ? '' : 'İstehsal adı tələb olunur';
          break;
        case 'items':
          this.formErrors.items = this.inputItems.length > 0 ? '' : 'Ən azı bir giriş məhsulu əlavə edilməlidir';
          break;
        case 'output':
          this.formErrors.output = this.outputItems.length > 0 ? '' : 'Ən azı bir çıxış məhsulu əlavə edilməlidir';
          break;
      }
      
      // Check overall form validity
      this.validateForm();
    },
    validateForm() {
      this.isFormValid = 
        this.production.name.trim() !== '' && 
        this.inputItems.length > 0 &&
        this.outputItems.length > 0;
    },
    saveProduction() {
      if (!this.isFormValid) return;
      
      // Check if there's enough stock for all input items
      let insufficientStock = false;
      this.inputItems.forEach(item => {
        const product = this.products.find(p => p.id === item.productId);
        if (product && item.quantity > product.quantity) {
          insufficientStock = true;
          this.$root.showNotification('warning', 'Stok xətası', 
            `${this.getProductName(item.productId)} məhsulundan stokda yalnız ${product.quantity} ədəd var`, 3000);
        }
      });
      
      if (insufficientStock) return;
      
      // Prepare production data with deep copying to avoid reference issues
      const productionData = {
        ...this.production,
        items: JSON.parse(JSON.stringify(this.inputItems)),
        output: JSON.parse(JSON.stringify(this.outputItems))
      };
      
      this.$emit('save-item', 'production', productionData);
    }
  },
  mounted() {
    // Get products from parent component/store
    this.products = this.$root.products || [];
    
    // Validate form initially
    this.validateForm();
  }
};