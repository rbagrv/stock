// Configuration settings for the application
export const config = {
  menuItems: [
    { id: 'dashboard', name: 'Əsas Səhifə', icon: 'dashboard' },
    { id: 'products', name: 'Məhsullar', icon: 'products' },
    { id: 'sales', name: 'Satışlar', icon: 'sales' },
    { id: 'purchases', name: 'Alışlar', icon: 'purchases' },
    { id: 'production', name: 'İstehsal', icon: 'production' },
    { id: 'operations', name: 'Əməliyyatlar', icon: 'operations' },
    { id: 'customers', name: 'Alıcılar', icon: 'customers' },
    { id: 'suppliers', name: 'Təchizatçılar', icon: 'suppliers' },
    { id: 'users', name: 'İstifadəçilər', icon: 'users' },
    { id: 'cashier', name: 'Kassa', icon: 'cashier' },
    { id: 'reports', name: 'Hesabatlar', icon: 'reports' },
    { id: 'settings', name: 'Parametrlər', icon: 'settings' }
  ],
  API_URL: window.location.protocol === 'file:' || window.location.hostname === 'localhost'
            ? 'http://localhost:3000/api'
            : '/api'
};

// Export getIconSvg:
export function getIconSvg(name) {
  const icons = {
    dashboard: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9"></rect><rect x="14" y="3" width="7" height="5"></rect><rect x="14" y="12" width="7" height="9"></rect><rect x="3" y="16" width="7" height="5"></rect></svg>`,
    products: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4a2 2 0 0 0 1-1.73z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22" x2="12" y2="12"></line></svg>`,
    sales: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 7h-4a2 2 0 0 1-2-2V1l-5 4-5-4v4a2 2 0 0 1-2 2H2"/><path d="M12 22V7"/><path d="M5 14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7H5z"/></svg>`,
    purchases: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 17.929H6c-1.105 0-2-.895-2-2V7c0-1.105.895-2 2-2h12c1.105 0 2 .895 2 2v8.929c0 1.105-.895 2-2 2H16"/><path d="M16 14h-2a2 2 0 1 0-4 0H8"/><path d="M12 14v7"/><path d="M12 5v2"/><path d="M16 7h.01"/><path d="M8 7h.01"/></svg>`,
    production: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 2H4v10h6V2zm10 12H14v8h6v-8zm-8-6v2H8v-2h4zm0 6v2H8v-2h4zm10-2h-2v4h2v-4zm-4-6h-2v4h2V8zM6 14H4v2h2v-2zm0 4H4v2h2v-2zm8-4h-2v2h2v-2z"/></svg>`,
    operations: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v4"/><path d="M9 3H5a2 2 0 0 0-2 2v4"/><path d="M21 9v6"/><path d="M3 9v6"/><path d="M9 21H5a2 2 0 0 1-2-2v-4"/><path d="M15 21h4a2 2 0 0 0 2-2v-4"/><path d="M12 17l-2-2 2-2"/><path d="M10 15h4"/></svg>`,
    customers: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
    suppliers: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 18a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2"/><rect x="3" y="4" width="18" height="18" rx="2"/><circle cx="12" cy="10" r="2"/><line x1="12" y1="2" x2="12" y2="4"/><line x1="12" y1="14" x2="12" y2="22"/></svg>`,
    users: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
    cashier: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M6 8h.01M6 16h.01M18 8h.01M18 16h.01"/><path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/></svg>`,
    reports: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3h18V5a2 2 0 0 0-2-2h-3"/><path d="M12 12h4"/><path d="M12 16h4"/><path d="M8 12h.01"/><path d="M8 16h.01"/><rect x="3" y="10" width="18" height="12" rx="2"/></svg>`,
    settings: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.09a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.09a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.09a1.65 1.65 0 0 0 1.51 1z"></path></svg>`
  };
  // Ensure width/height are set for FAB menu icons if needed
  return icons[name]?.replace('<svg ', '<svg width="20" height="20" ') || ''; // Default size 20x20
}